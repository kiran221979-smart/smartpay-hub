import { useEffect, useMemo, useState } from "react";
import { Lock, Zap, CreditCard, Radio, ShieldAlert, X, Radar } from "lucide-react";

type SavedCard = { id: string; label: string; bank: string; last4: string };

const SAVED_CARDS: SavedCard[] = [
  { id: "sbi-8851", label: "SBI Elite — **** 8851", bank: "SBI", last4: "8851" },
  { id: "hdfc-2204", label: "HDFC Diners Black — **** 2204", bank: "HDFC", last4: "2204" },
  { id: "icici-7710", label: "ICICI Sapphiro — **** 7710", bank: "ICICI", last4: "7710" },
  { id: "axis-3382", label: "Axis Magnus — **** 3382", bank: "AXIS", last4: "3382" },
];

const MIN_TXN = 100;
const MAX_TXN = 10000000;

const MILESTONES = [
  { at: 10, label: "Optimizing Route" },
  { at: 25, label: "Neural Node Verification" },
  { at: 45, label: "Settlement Complete" },
];

function NeuralRadar({ running }: { running: boolean }) {
  const [t, setT] = useState(0);
  const [ms, setMs] = useState(0);
  useEffect(() => {
    if (!running) {
      setT(0);
      setMs(0);
      return;
    }
    if (t >= 45) return;
    const id = setTimeout(() => setT((s) => s + 1), 1000);
    return () => clearTimeout(id);
  }, [running, t]);
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setMs((m) => (m + 1) % 100), 80);
    return () => clearInterval(id);
  }, [running]);


  const pct = (t / 45) * 100;
  const radius = 78;
  const circ = 2 * Math.PI * radius;
  const offset = circ - (pct / 100) * circ;
  const current = [...MILESTONES].reverse().find((m) => t >= m.at);

  return (
    <div className="flex h-full w-full flex-col items-center justify-center p-6 text-center">
      <div
        className="relative grid place-items-center"
        style={{
          filter: running
            ? "drop-shadow(0 0 22px color-mix(in oklab, var(--color-mint) 80%, transparent))"
            : "none",
        }}
      >
        <svg width="220" height="220" viewBox="0 0 220 220" className="-rotate-90">
          <defs>
            <radialGradient id="radarFill" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="var(--color-mint)" stopOpacity="0.25" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
          </defs>
          <circle cx="110" cy="110" r="92" fill="url(#radarFill)" />
          {[30, 55, 80].map((r) => (
            <circle
              key={r}
              cx="110"
              cy="110"
              r={r}
              stroke="color-mix(in oklab, var(--color-mint) 22%, transparent)"
              strokeWidth="1"
              fill="none"
            />
          ))}
          <circle
            cx="110"
            cy="110"
            r={radius}
            stroke="color-mix(in oklab, var(--color-mint) 18%, transparent)"
            strokeWidth="10"
            fill="none"
          />
          <circle
            cx="110"
            cy="110"
            r={radius}
            stroke="var(--color-mint)"
            strokeWidth="10"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{ transition: "stroke-dashoffset 1s linear" }}
          />
        </svg>
        {running && (
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "conic-gradient(from 0deg, transparent 0deg, color-mix(in oklab, var(--color-mint) 55%, transparent) 30deg, transparent 60deg)",
              borderRadius: "9999px",
              animation: "radarSweep 2.2s linear infinite",
              maskImage: "radial-gradient(circle, black 60%, transparent 70%)",
            }}
          />
        )}
        <div className="absolute inset-0 grid place-items-center">
          <div className="text-center">
            <div className="font-display font-black tabular-nums text-mint">
              <span className="text-4xl sm:text-5xl">00:{String(Math.max(0, 45 - t)).padStart(2, "0")}</span>
              <span className={`ml-1 align-top text-base sm:text-lg ${running ? "opacity-100" : "opacity-40"}`}>
                :{String(running ? ms : 0).padStart(2, "0")}
              </span>
            </div>
            <div className="mt-1 text-[10px] font-bold uppercase tracking-[0.3em] text-mint/80">
              {running ? "AI Fast-Routing" : "Awaiting CVV"}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-5 inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-mint">
        <Radio className="h-3 w-3 animate-pulse" /> Neural Radar · Live Server Hops
      </div>
      <div className="mt-3 grid w-full max-w-xs gap-1.5">
        {MILESTONES.map((m) => {
          const done = t >= m.at;
          return (
            <div
              key={m.at}
              className={`flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition ${
                done
                  ? "border-mint/50 bg-mint/10 text-mint"
                  : "border-border bg-slate-elevated text-muted-foreground"
              }`}
            >
              <span>{String(m.at).padStart(2, "0")}s · {m.label}</span>
              {done && <span>✓</span>}
            </div>
          );
        })}
      </div>
      <p className="mt-3 max-w-xs text-[11px] leading-relaxed text-foreground/85">
        {running
          ? current?.label ?? "Initializing neural payout grid..."
          : "Press Authorize to engage the AI Fast-Routing Neural Radar."}
      </p>
      <style>{`@keyframes radarSweep{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

function LiveSettlementPulseClock({ active }: { active: boolean }) {
  const [t, setT] = useState(45);
  const [ms, setMs] = useState(0);

  useEffect(() => {
    if (!active) {
      setT(45);
      setMs(0);
      return;
    }
    if (t <= 0) return;
    const id = window.setTimeout(() => setT((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearTimeout(id);
  }, [active, t]);

  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setMs((m) => (m + 1) % 100), 80);
    return () => window.clearInterval(id);
  }, [active]);

  const mm = "00";
  const ss = String(t).padStart(2, "0");
  const cc = String(ms).padStart(2, "0");

  return (
    <div
      className="pointer-events-none z-10 flex items-center gap-2.5 rounded-lg border border-mint/50 bg-slate-deep/90 px-4 py-2 shadow-mint backdrop-blur-sm"
      style={{ height: "48px" }}
    >
      <span
        className={`inline-block h-2.5 w-2.5 rounded-full ${active ? "bg-mint animate-pulse" : "bg-mint/30"}`}
      />
      <div className="flex items-baseline gap-[2px] font-mono font-bold">
        <span className="text-[13px] text-mint/60 tabular-nums tracking-tight">{mm}</span>
        <span className="text-[13px] text-mint/60">:</span>
        <span
          className="text-[22px] leading-none text-mint tabular-nums tracking-tight"
          style={{
            textShadow:
              "0 0 10px color-mix(in oklab, var(--color-mint) 55%, transparent), 0 0 22px color-mix(in oklab, var(--color-mint) 30%, transparent)",
          }}
        >
          {ss}
        </span>
        <span className="text-[10px] text-mint/40">.</span>
        <span className="text-[13px] text-mint/70 tabular-nums tracking-tight">{cc}</span>
      </div>
    </div>
  );
}

function OddOnlyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-deep/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-3xl border border-mint/40 bg-slate-elevated p-6 shadow-elevated">
        <button
          onClick={onClose}
          aria-label="Close"
          className="press press-on absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-mint text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2 text-mint">
          <ShieldAlert className="h-5 w-5" />
          <div className="text-xs font-bold uppercase tracking-widest">Security Protocol</div>
        </div>
        <h3 className="mt-3 font-display text-xl font-bold">
          ⚠️ Please input <span className="text-mint">odd figures</span> only
        </h3>
        <p className="mt-2 text-sm text-foreground/85">
          For transaction safety, even-numbered amounts are not allowed. Use any amount ending in
          an odd digit.
        </p>
        <div className="mt-4 rounded-2xl border border-mint/30 bg-slate-deep p-3">
          <div className="text-[10px] font-bold uppercase tracking-widest text-mint">
            Recommended Examples
          </div>
          <div className="mt-2 flex flex-wrap gap-2 font-mono text-xs">
            {["₹54,870", "₹67,930", "₹79,150", "₹83,690", "₹91,430", "₹99,850"].map((v) => (
              <span
                key={v}
                className="rounded-lg border border-mint/40 bg-mint/10 px-2 py-1 text-mint"
              >
                {v}
              </span>
            ))}
          </div>
        </div>
        <button
          onClick={onClose}
          className="press press-on mt-5 w-full rounded-xl gradient-mint py-2.5 text-sm font-bold text-primary-foreground shadow-mint"
        >
          Got it · Re-enter amount
        </button>
      </div>
    </div>
  );
}

export function WithdrawalSplit() {
  const [cardId, setCardId] = useState(SAVED_CARDS[0].id);
  const [amount, setAmount] = useState("");
  const [cvv, setCvv] = useState("");
  const [running, setRunning] = useState(false);
  const [oddOpen, setOddOpen] = useState(false);

  const selected = SAVED_CARDS.find((c) => c.id === cardId)!;
  const num = Number(amount || 0);
  const rangeError =
    amount && (num < MIN_TXN || num > MAX_TXN)
      ? `Amount must be between ₹${MIN_TXN} and ₹${MAX_TXN.toLocaleString()}`
      : "";
  const isEven = num > 0 && num % 2 === 0;
  const canAuthorize = useMemo(
    () => num >= MIN_TXN && num <= MAX_TXN && num % 2 !== 0 && cvv.length === 3 && !running,
    [num, cvv, running],
  );

  const handleAmount = (raw: string) => {
    const v = raw.replace(/\D/g, "");
    setAmount(v);
    const n = Number(v || 0);
    if (n > 0 && n % 2 === 0) setOddOpen(true);
  };

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-12 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Zap className="h-3 w-3" /> Repeat Customer · Express Withdrawal
        </div>
        <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">
          One-Tap Authorize · 45-Second AI Payout
        </h2>
      </div>

      <div className="mt-6 grid grid-cols-1 items-stretch gap-8 md:grid-cols-2">
        {/* LEFT 50% */}
        <div className="relative overflow-hidden rounded-3xl border border-mint/30 bg-slate-elevated p-6 shadow-elevated sm:p-8">
          <div className="absolute left-4 top-4 z-10 inline-flex items-center gap-1.5 rounded-full border border-mint/50 bg-slate-deep px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint shadow-mint">
            <ShieldAlert className="h-3 w-3" /> Txn Limit: ₹100 – ₹1,00,00,000
          </div>
          <div className="absolute right-4 top-4 z-10">
            <LiveSettlementPulseClock active={running || (cvv.length === 3 && num >= MIN_TXN && num <= MAX_TXN && num % 2 !== 0)} />
          </div>

          <div className="mt-8 flex items-center gap-2 text-mint">
            <CreditCard className="h-5 w-5" />
            <div className="text-sm font-bold uppercase tracking-widest">Saved Card Vault</div>
          </div>

          <label className="mt-5 block">
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Choose a previously configured card
            </div>
            <select
              className="input"
              value={cardId}
              onChange={(e) => setCardId(e.target.value)}
            >
              {SAVED_CARDS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>

          <div className="mt-4 rounded-2xl border border-mint/25 bg-slate-deep p-4">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-widest text-mint">
                {selected.bank}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full border border-mint/40 bg-mint/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-mint">
                <Lock className="h-3 w-3" /> Card Frozen
              </span>
            </div>
            <div className="mt-2 font-mono text-lg tracking-widest text-foreground/70">
              •••• •••• •••• {selected.last4}
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">
              All card detail fields locked — only Amount + CVV required.
            </div>
          </div>

          <div className="mt-5 grid gap-4">
            <label className="block">
              <div className="mb-1.5 flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                <span>Enter Amount (₹)</span>
                <span className="text-[10px] normal-case text-mint">Odd figures only</span>
              </div>
              <input
                className="input"
                inputMode="numeric"
                placeholder="e.g. 9,481"
                value={amount}
                onChange={(e) => handleAmount(e.target.value)}
              />
              {rangeError && (
                <div className="mt-1 text-[11px] font-semibold text-red-400">{rangeError}</div>
              )}
              {isEven && !rangeError && (
                <div className="mt-1 text-[11px] font-semibold text-red-400">
                  Even number detected — please use an odd figure.
                </div>
              )}
            </label>
            <label className="block">
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                🔒 Enter 3-Digit CVV to Authorize
              </div>
              <input
                className="input font-mono tracking-widest"
                type="password"
                inputMode="numeric"
                maxLength={3}
                placeholder="•••"
                value={cvv}
                onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
              />
            </label>
            <button
              type="button"
              disabled={!canAuthorize}
              onClick={() => setRunning(true)}
              className="press press-on rounded-xl gradient-mint py-3 font-display text-sm font-bold text-primary-foreground shadow-mint disabled:opacity-60"
            >
              <Radar className="mr-1 inline h-4 w-4" /> Authorize Express Withdrawal
            </button>
          </div>
        </div>

        {/* RIGHT 50% */}
        <div className="overflow-hidden rounded-3xl border border-mint/30 bg-slate-deep shadow-elevated">
          <NeuralRadar running={running || (cvv.length === 3 && num >= MIN_TXN && num <= MAX_TXN && num % 2 !== 0)} />
        </div>
      </div>

      <OddOnlyModal open={oddOpen} onClose={() => setOddOpen(false)} />
    </section>
  );
}
