import { useEffect, useState } from "react";
import { CreditCard, Zap, Atom, Activity, Radio } from "lucide-react";

function useTicker(min: number, max: number, ms = 600, fixed = 2) {
  const [v, setV] = useState(((min + max) / 2).toFixed(fixed));
  useEffect(() => {
    const id = window.setInterval(() => {
      const n = min + Math.random() * (max - min);
      setV(n.toFixed(fixed));
    }, ms);
    return () => window.clearInterval(id);
  }, [min, max, ms, fixed]);
  return v;
}

function useCountdown() {
  const [t, setT] = useState(45);
  const [ms, setMs] = useState(0);
  useEffect(() => {
    const a = window.setInterval(() => setT((s) => (s <= 0 ? 45 : s - 1)), 1000);
    const b = window.setInterval(() => setMs((m) => (m + 1) % 100), 70);
    return () => {
      window.clearInterval(a);
      window.clearInterval(b);
    };
  }, []);
  return { t, ms };
}

function SignalLine({ delay }: { delay: number }) {
  const [pts, setPts] = useState<string>("");
  useEffect(() => {
    const build = () => {
      const arr: string[] = [];
      for (let i = 0; i <= 40; i++) {
        const x = (i / 40) * 100;
        const y = 50 + Math.sin(i / 3 + Math.random() * 2) * (8 + Math.random() * 12);
        arr.push(`${x.toFixed(1)},${y.toFixed(1)}`);
      }
      setPts(arr.join(" "));
    };
    build();
    const id = window.setInterval(build, 700 + delay);
    return () => window.clearInterval(id);
  }, [delay]);
  return (
    <polyline
      points={pts}
      fill="none"
      stroke="var(--color-mint)"
      strokeWidth="0.8"
      strokeLinecap="round"
      style={{ filter: "drop-shadow(0 0 4px color-mix(in oklab, var(--color-mint) 70%, transparent))" }}
    />
  );
}

export function SettlementConsole({ onLaunch }: { onLaunch?: () => void }) {
  const { t, ms } = useCountdown();
  const throughput = useTicker(8200, 9420, 500, 0);
  const latency = useTicker(38, 49, 700, 1);
  const trust = useTicker(99.21, 99.84, 900, 2);
  const nodes = useTicker(178, 196, 1100, 0);
  const load = useTicker(58, 74, 600, 1);

  return (
    <div
      onClick={onLaunch}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onLaunch?.()}
      className="press group relative cursor-pointer overflow-hidden rounded-3xl border border-mint/50 bg-slate-deep"
      style={{
        boxShadow:
          "0 0 0 1px color-mix(in oklab, var(--color-mint) 25%, transparent), 0 0 40px color-mix(in oklab, var(--color-mint) 18%, transparent), inset 0 0 60px color-mix(in oklab, #6FB7C9 8%, transparent)",
      }}
    >
      {/* Wireframe corner brackets */}
      {[
        "left-2 top-2 border-l-2 border-t-2",
        "right-2 top-2 border-r-2 border-t-2",
        "left-2 bottom-2 border-l-2 border-b-2",
        "right-2 bottom-2 border-r-2 border-b-2",
      ].map((p, i) => (
        <div key={i} className={`pointer-events-none absolute h-5 w-5 border-mint/70 ${p}`} />
      ))}

      {/* Top bar */}
      <div className="relative flex items-center justify-between border-b border-mint/25 bg-slate-deep/80 px-5 py-3 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="h-2 w-2 rounded-full bg-mint shadow-[0_0_8px_var(--color-mint)]" />
            <span className="h-2 w-2 rounded-full bg-sapphire/80" />
            <span className="h-2 w-2 rounded-full bg-burnt/80" />
          </div>
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-mint/80">
            SP-CORE / SETTLEMENT.CONSOLE / v45.2
          </div>
        </div>
        <div className="inline-flex items-center gap-1.5 rounded-full border border-mint/50 bg-mint/10 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest text-mint">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" /> LIVE · ENCRYPTED
        </div>
      </div>

      {/* Body */}
      <div className="relative grid gap-0 lg:grid-cols-[1fr_280px]">
        {/* Frame 1: Holographic card */}
        <div className="relative aspect-video w-full overflow-hidden border-mint/15 lg:border-r">
          {/* Grid bg */}
          <div
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage:
                "linear-gradient(color-mix(in oklab, var(--color-mint) 14%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in oklab, var(--color-mint) 14%, transparent) 1px, transparent 1px)",
              backgroundSize: "32px 32px",
            }}
          />
          {/* Scanlines */}
          <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(transparent_0%,transparent_50%,color-mix(in_oklab,var(--color-mint)_8%,transparent)_50%,transparent_51%)] bg-[length:100%_4px] opacity-50" />
          {/* Radial glow */}
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,color-mix(in_oklab,var(--color-mint)_22%,transparent),transparent_60%)]" />

          {/* Background signal lines */}
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full opacity-60">
            <SignalLine delay={0} />
            <SignalLine delay={120} />
            <SignalLine delay={240} />
          </svg>

          {/* Holographic card */}
          <div className="relative z-10 grid h-full w-full place-items-center p-6">
            <div className="relative">
              {/* Orbit rings */}
              <svg width="320" height="200" viewBox="0 0 320 200" className="absolute inset-0">
                <ellipse cx="160" cy="100" rx="150" ry="55" fill="none" stroke="var(--color-mint)" strokeOpacity="0.35" strokeWidth="0.7" strokeDasharray="3 4" />
                <ellipse cx="160" cy="100" rx="120" ry="40" fill="none" stroke="#6FB7C9" strokeOpacity="0.4" strokeWidth="0.7" strokeDasharray="2 5" style={{ transformOrigin: "160px 100px", animation: "spConsoleSpin 8s linear infinite" }} />
                <ellipse cx="160" cy="100" rx="90" ry="28" fill="none" stroke="var(--color-mint)" strokeOpacity="0.5" strokeWidth="0.7" style={{ transformOrigin: "160px 100px", animation: "spConsoleSpinRev 6s linear infinite" }} />
              </svg>

              <div
                className="relative h-[170px] w-[290px] rounded-2xl border border-mint/60 p-4"
                style={{
                  background:
                    "linear-gradient(135deg, color-mix(in oklab, var(--color-mint) 18%, #0B1220) 0%, #0B1220 55%, color-mix(in oklab, #6FB7C9 14%, #0B1220) 100%)",
                  boxShadow:
                    "0 0 30px color-mix(in oklab, var(--color-mint) 45%, transparent), inset 0 0 30px color-mix(in oklab, var(--color-mint) 15%, transparent)",
                  animation: "spCardFloat 4s ease-in-out infinite",
                }}
              >
                <div className="flex items-center justify-between">
                  <CreditCard className="h-6 w-6 text-mint" />
                  <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-mint/80">LINK · VERIFIED</span>
                </div>
                <div className="mt-6 font-mono text-base tracking-[0.35em] text-mint" style={{ textShadow: "0 0 10px var(--color-mint)" }}>
                  4565  ••••  ••••  2356
                </div>
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <div className="font-mono text-[8px] uppercase tracking-widest text-mint/60">Holder</div>
                    <div className="font-mono text-[11px] text-foreground/90">AGENTIC · NODE</div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-[8px] uppercase tracking-widest text-mint/60">SLA</div>
                    <div className="font-mono text-sm font-bold text-mint tabular-nums">
                      00:{String(t).padStart(2, "0")}<span className="text-[10px] text-mint/70">.{String(ms).padStart(2, "0")}</span>
                    </div>
                  </div>
                </div>
                {/* Scanning bar */}
                <div
                  className="pointer-events-none absolute inset-x-3 top-0 h-[2px] rounded-full bg-mint"
                  style={{
                    boxShadow: "0 0 12px var(--color-mint)",
                    animation: "spScanBar 2.2s ease-in-out infinite",
                  }}
                />
              </div>
            </div>
          </div>

          {/* Bottom overlay strings */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-deep via-slate-deep/85 to-transparent p-5">
            <div className="font-display text-xl font-black leading-tight text-foreground sm:text-2xl" style={{ letterSpacing: "-0.01em" }}>
              The Heartbeat of India's <span className="text-mint" style={{ textShadow: "0 0 14px color-mix(in oklab, var(--color-mint) 60%, transparent)" }}>45-Second Payout Grid</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-md border border-mint/50 bg-mint/10 px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-mint">
                <Zap className="h-3 w-3" /> JET-SPEED ENGINE: ONLINE
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-md border border-[#6FB7C9]/50 bg-[#6FB7C9]/10 px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-[#9FDCE9]">
                <Atom className="h-3 w-3" /> ATOMIC SYNC: 45S SLA
              </span>
            </div>
          </div>
        </div>

        {/* Right metrics rail */}
        <div className="relative flex flex-col gap-3 border-t border-mint/15 bg-slate-deep/60 p-4 lg:border-l-0 lg:border-t-0">
          <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-[#9FDCE9]">// LIVE TELEMETRY</div>

          <Metric label="Throughput" unit="tps" value={throughput} accent="mint" />
          <Metric label="Latency" unit="ms" value={latency} accent="teal" />
          <Metric label="Trust Index" unit="%" value={trust} accent="mint" />
          <Metric label="Active Nodes" unit="" value={nodes} accent="teal" />
          <Metric label="Core Load" unit="%" value={load} accent="mint" />

          <div className="mt-auto rounded-lg border border-mint/30 bg-slate-elevated p-2.5">
            <div className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.25em] text-[#9FDCE9]">
              <Radio className="h-2.5 w-2.5 animate-pulse text-mint" /> Tap to launch
            </div>
            <div className="mt-1 font-display text-[11px] font-bold leading-tight text-mint">
              45-Second Step-by-Step OTP &amp; Tier Process Demo
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spConsoleSpin { to { transform: rotate(360deg); } }
        @keyframes spConsoleSpinRev { to { transform: rotate(-360deg); } }
        @keyframes spScanBar {
          0%, 100% { transform: translateY(0); opacity: 0.9; }
          50% { transform: translateY(150px); opacity: 0.6; }
        }
        @keyframes spCardFloat {
          0%, 100% { transform: translateY(0) rotateX(0deg); }
          50% { transform: translateY(-6px) rotateX(4deg); }
        }
      `}</style>
    </div>
  );
}

function Metric({ label, unit, value, accent }: { label: string; unit: string; value: string; accent: "mint" | "teal" }) {
  const color = accent === "mint" ? "text-mint" : "text-[#9FDCE9]";
  const border = accent === "mint" ? "border-mint/30" : "border-[#6FB7C9]/30";
  return (
    <div className={`rounded-lg border ${border} bg-slate-elevated/70 px-3 py-2`}>
      <div className="flex items-center justify-between">
        <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#9FDCE9]">{label}</span>
        <Activity className="h-2.5 w-2.5 text-mint/60" />
      </div>
      <div className={`mt-0.5 font-mono text-lg font-black tabular-nums ${color}`} style={{ textShadow: "0 0 8px color-mix(in oklab, var(--color-mint) 35%, transparent)" }}>
        {value}<span className="ml-1 text-[10px] opacity-70">{unit}</span>
      </div>
    </div>
  );
}
