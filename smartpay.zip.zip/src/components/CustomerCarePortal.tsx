import { useState } from "react";
import { Headphones, Radio, X, PhoneCall } from "lucide-react";

type Agent = {
  name: string;
  role: string;
  team: string;
  photo: string;
  gender: "m" | "f";
};

const TEAMS: { label: string; agents: [Agent, Agent] }[] = [
  {
    label: "Credit Card Services Experts",
    agents: [
      {
        name: "Aarav Mehta",
        role: "Senior Card Settlement Lead",
        team: "Credit Card Services",
        gender: "m",
        photo:
          "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=600&q=70",
      },
      {
        name: "Isha Kapoor",
        role: "Card Network Specialist",
        team: "Credit Card Services",
        gender: "f",
        photo:
          "https://images.unsplash.com/photo-1573497019418-b400bb3ab074?auto=format&fit=crop&w=600&q=70",
      },
    ],
  },
  {
    label: "FinTech Product Consultants",
    agents: [
      {
        name: "Rohan Sharma",
        role: "FinTech Blueprint Consultant",
        team: "FinTech Product",
        gender: "m",
        photo:
          "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=600&q=70",
      },
      {
        name: "Meera Iyer",
        role: "Product Architecture Advisor",
        team: "FinTech Product",
        gender: "f",
        photo:
          "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=70",
      },
    ],
  },
  {
    label: "AI Money Hub Engineers",
    agents: [
      {
        name: "Karthik Rao",
        role: "Agentic AI Routing Engineer",
        team: "AI Money Hub",
        gender: "m",
        photo:
          "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=70",
      },
      {
        name: "Ananya Verma",
        role: "ML Risk & Limits Engineer",
        team: "AI Money Hub",
        gender: "f",
        photo:
          "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=70",
      },
    ],
  },
  {
    label: "Institutional Alliance Specialists",
    agents: [
      {
        name: "Vikram Joshi",
        role: "Bank Alliance Director",
        team: "Institutional Alliance",
        gender: "m",
        photo:
          "https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=600&q=70",
      },
      {
        name: "Priya Nair",
        role: "Regulatory Partnerships Lead",
        team: "Institutional Alliance",
        gender: "f",
        photo:
          "https://images.unsplash.com/photo-1554151228-14d9def656e4?auto=format&fit=crop&w=600&q=70",
      },
    ],
  },
];

function AgentCard({ agent, onOpen }: { agent: Agent; onOpen: () => void }) {
  return (
    <button
      onClick={onOpen}
      className="press press-on group relative overflow-hidden rounded-3xl border border-border bg-slate-elevated text-left shadow-elevated transition hover:border-mint hover:shadow-mint"
      style={{ minHeight: "clamp(280px, 32vw, 380px)" }}
    >
      <img
        src={agent.photo}
        alt={`${agent.name}, ${agent.role}`}
        loading="lazy"
        decoding="async"
        className="absolute inset-0 h-full w-full object-cover opacity-90 transition group-hover:scale-[1.03] group-hover:opacity-100"
        style={{ transform: "translateZ(0)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-deep via-slate-deep/55 to-transparent" />
      <div className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-mint/40 bg-slate-deep/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint backdrop-blur">
        <Headphones className="h-3 w-3" /> Live Agent
      </div>
      <div className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full border border-mint/30 bg-slate-deep/80 px-2 py-1 text-[9px] font-bold uppercase tracking-widest text-mint/90 backdrop-blur">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" /> Online
      </div>
      <div className="absolute inset-x-0 bottom-0 p-5">
        <div className="text-[10px] uppercase tracking-widest text-mint">{agent.team}</div>
        <div className="font-display text-lg font-black">{agent.name}</div>
        <div className="text-xs text-foreground/80">{agent.role}</div>
        <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-mint px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-mint-foreground shadow-mint">
          <PhoneCall className="h-3 w-3" /> Tap to Connect Live
        </div>
      </div>
    </button>
  );
}

function LiveDialogueOverlay({ agent, onClose }: { agent: Agent; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-[120] grid place-items-center bg-slate-deep/85 p-4 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl overflow-hidden rounded-3xl border border-mint/40 bg-slate-elevated shadow-mint"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="End live dialogue"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-mint/40 bg-slate-deep/80 text-mint hover:bg-mint hover:text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="relative aspect-video w-full bg-black">
          <img
            src={agent.photo}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover opacity-95"
            style={{ transform: "translateZ(0)" }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-deep/80 via-transparent to-transparent" />
          {/* simulated live HUD */}
          <div className="pointer-events-none absolute inset-0 opacity-25 [background-image:linear-gradient(transparent_50%,rgba(255,255,255,0.05)_50%)] [background-size:100%_4px]" />
          <div className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-red-400/60 bg-red-500/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-red-200 backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" /> Live · Encrypted
          </div>
          <div className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full border border-mint/40 bg-slate-deep/80 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-mint backdrop-blur">
            <Radio className="h-3 w-3" /> Lady AI Relay
          </div>
          <div className="absolute inset-x-0 bottom-0 p-5">
            <div className="text-[10px] uppercase tracking-widest text-mint">{agent.team}</div>
            <div className="font-display text-2xl font-black">{agent.name}</div>
            <div className="text-sm text-foreground/85">{agent.role}</div>
          </div>
        </div>
        <div className="grid gap-2 p-5 text-sm">
          <div className="rounded-xl border border-mint/25 bg-slate-deep/60 px-4 py-3 text-foreground/85">
            <span className="mr-2 text-[10px] font-bold uppercase tracking-widest text-mint">Agent</span>
            Hello, I'm {agent.name.split(" ")[0]} from the {agent.team} desk. How can I assist you today?
          </div>
          <div className="rounded-xl border border-border bg-slate-elevated px-4 py-3 text-foreground/80">
            <span className="mr-2 text-[10px] font-bold uppercase tracking-widest text-mint/80">You</span>
            Connecting your secure dialogue channel...
          </div>
        </div>
      </div>
    </div>
  );
}

export function CustomerCarePortal() {
  const [active, setActive] = useState<Agent | null>(null);
  return (
    <section
      id="customer-care"
      className="mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-10"
      style={{ contentVisibility: "auto", containIntrinsicSize: "1200px" }}
    >
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Headphones className="h-3 w-3" /> Customer Care Portal
        </div>
        <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">
          Talk to a Live Specialist
        </h2>
        <p className="mt-2 text-sm text-muted-foreground sm:text-base">
          Eight dedicated experts across four desks. Tap any agent to open a secure live dialogue stream.
        </p>
      </div>

      <div className="mt-12 grid gap-8">
        {TEAMS.map((team) => (
          <div key={team.label}>
            <div className="mb-3 flex items-center justify-between">
              <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">
                {team.label}
              </div>
              <div className="hidden text-[10px] uppercase tracking-widest text-muted-foreground sm:block">
                2 Live Agents · Online
              </div>
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {team.agents.map((a) => (
                <AgentCard key={a.name} agent={a} onOpen={() => setActive(a)} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {active && <LiveDialogueOverlay agent={active} onClose={() => setActive(null)} />}
    </section>
  );
}
