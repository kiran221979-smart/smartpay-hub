import { useEffect, useState } from "react";
import { MapPin, Radio, IndianRupee } from "lucide-react";

const REGIONS = [
  "DELHI NCR", "MUMBAI", "HYDERABAD", "BANGALORE", "CHENNAI",
  "KOLKATA", "PUNE", "AHMEDABAD", "JAIPUR", "LUCKNOW", "GUJARAT",
  "VIZAG", "INDORE", "CHANDIGARH", "KOCHI", "BHOPAL", "SURAT", "NAGPUR",
];

function amount(seed: number, i: number) {
  // strictly above ₹50,000 and below ₹1,00,000
  const v = 50001 + ((seed * 9301 + i * 49297) % 49998);
  return v;
}

function row(seed: number) {
  return REGIONS.map((r, i) => {
    const latency = 28 + ((seed + i * 7) % 18);
    const amt = amount(seed, i).toLocaleString("en-IN");
    return (
      <span key={`${seed}-${r}`} className="inline-flex items-center gap-1.5">
        <MapPin className="h-3 w-3 text-mint" />
        <strong className="text-mint">{r}</strong>
        <span className="text-foreground/80 inline-flex items-center">
          · <IndianRupee className="mx-0.5 h-3 w-3" />
          <span className="font-mono tabular-nums">{amt}</span>
        </span>
        <span className="text-muted-foreground">· {latency}s · LIVE</span>
        <span className="ticker-sep mx-3">◆</span>
      </span>
    );
  });
}

export function GeoTicker() {
  const [seed, setSeed] = useState(1);
  useEffect(() => {
    const t = window.setInterval(() => setSeed((s) => s + 1), 1600);
    return () => window.clearInterval(t);
  }, []);
  return (
    <div className="border-y border-mint/20 bg-slate-deep/60 backdrop-blur-md">
      <div className="mx-auto w-full max-w-7xl px-4 pt-2 sm:px-6 lg:px-10">
        <div
          className="mx-auto w-fit rounded-full border border-mint/50 bg-mint/10 px-4 py-1 text-center text-[11px] font-black uppercase tracking-[0.32em] text-mint"
          style={{
            animation: "pulse-mint 1.6s ease-in-out infinite",
            textShadow: "0 0 8px color-mix(in oklab, var(--color-mint) 60%, transparent)",
          }}
        >
          🟢 PAN INDIA AI SERVICE
        </div>
      </div>
      <div className="mx-auto flex w-full max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-10">
        <div className="hidden shrink-0 items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint sm:flex">
          <Radio className="h-3 w-3 animate-pulse" /> Live City Routing
        </div>
        <div className="market-ticker flex-1" aria-label="Live city transactions">
          <div className="market-ticker-track">
            <div className="market-ticker-copy text-[11px] font-semibold tracking-wide">{row(seed)}</div>
            <div className="market-ticker-copy text-[11px] font-semibold tracking-wide" aria-hidden="true">{row(seed + 11)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
