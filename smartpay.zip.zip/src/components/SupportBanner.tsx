import { useState } from "react";
import { Globe, Headphones } from "lucide-react";

const TELUGU =
  "💬 మన సపోర్ట్ టీమ్ లోని ఏ సర్వీస్ ఎగ్జిక్యూటివ్‌తోనైనా మీకు ఏ చిన్న సమస్య వచ్చినా.. మా సీనియర్ ఎక్స్‌పర్ట్ స్టాఫ్‌కు 24/7 ఎప్పుడైనా వెంటనే కనెక్ట్ అయి మీ సమస్యను పూర్తిగా పరిష్కరించుకోవచ్చు.";
const ENGLISH =
  "💬 No matter which service expert you connect with, if you face any issue, you can instantly connect to our Senior Expert Staff 24/7 to resolve your problem completely.";

export function SupportBanner() {
  const [en, setEn] = useState(false);
  return (
    <div className="mx-auto my-6 w-full max-w-5xl px-4">
      <div className="relative overflow-hidden rounded-2xl border border-mint/40 bg-gradient-to-br from-slate-deep via-slate-elevated to-slate-deep p-5 shadow-mint">
        <div className="pointer-events-none absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 10%, var(--color-mint) 0%, transparent 50%)" }} />
        <div className="relative flex flex-col items-center gap-3 text-center sm:flex-row sm:items-start sm:text-left">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-mint/15 text-mint ring-1 ring-mint/40">
            <Headphones className="h-5 w-5" />
          </div>
          <p className="flex-1 text-sm leading-relaxed text-foreground/90" lang={en ? "en" : "te"}>
            {en ? ENGLISH : TELUGU}
          </p>
          <button
            type="button"
            onClick={() => setEn((v) => !v)}
            className="press press-on inline-flex shrink-0 items-center gap-1.5 rounded-full border border-mint/50 bg-mint/10 px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-mint hover:bg-mint hover:text-mint-foreground"
          >
            <Globe className="h-3.5 w-3.5" /> 🌐 Translate to {en ? "తెలుగు" : "English"}
          </button>
        </div>
      </div>
    </div>
  );
}
