import { Sparkles, ShieldCheck, Clock, Zap } from "lucide-react";

export function WhyChooseUs() {
  return (
    <section className="relative overflow-hidden border-y border-border/60 bg-slate-elevated/50 py-20">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,var(--color-mint)/0.08,transparent_60%)]" />
      <div className="relative mx-auto max-w-5xl px-4 sm:px-6">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-burnt/40 bg-burnt/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-burnt">
            <Sparkles className="h-3 w-3" /> Why Choose Smart Pay
          </div>
          <h2 className="mt-4 font-display text-3xl font-bold sm:text-5xl">
            <span className="shimmer-text">Your time is your true wealth.</span>
          </h2>
        </div>

        <p className="mx-auto mt-8 max-w-3xl text-balance text-base leading-relaxed text-foreground/90 sm:text-lg">
          Why waste your irreplaceable, precious hours waiting on manual transfers or stressfully texting credit card details over unsecured WhatsApp chats? Your time belongs to your dreams, your business, and the smiles of your family who depend on you. At <span className="font-semibold text-mint">Smart Pay</span>, we engineered India's first fully autonomous <span className="font-semibold text-burnt">Agentic AI Payout System</span> to deliver credit-to-bank settlements in <span className="font-semibold text-mint">under 45 seconds</span>. We don't view this as just a transactional business&mdash;our core mission is to wipe away the financial burden of high interest fees by offering the market's absolute lowest pricing tier. <span className="font-semibold">Zero third-party intervention, 100% bank loyalty retention, and ultimate data privacy.</span> Because your peace of mind is our true ledger of success.
        </p>

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {[
            { i: ShieldCheck, t: "Bank-grade Secure", s: "PCI-DSS encrypted rails" },
            { i: Clock, t: "Under 45s Settlement", s: "Real, not theoretical" },
            { i: Zap, t: "Agentic AI Payout", s: "Zero human touch" },
          ].map(({ i: Icon, t, s }) => (
            <div key={t} className="press rounded-2xl border border-border bg-slate-deep p-5 text-left">
              <Icon className="h-6 w-6 text-mint" />
              <div className="mt-3 font-display font-bold">{t}</div>
              <div className="text-sm text-muted-foreground">{s}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
