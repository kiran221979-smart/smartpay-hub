import { Wifi } from "lucide-react";

type Variant = "VISA" | "Mastercard" | "RuPay" | "Business" | "Corporate";

const banks: { name: string; tint: string; accent: string }[] = [
  { name: "HDFC BANK", tint: "from-[#0b2d54] via-[#0a1f3a] to-[#02060f]", accent: "#ed232a" },
  { name: "ICICI BANK", tint: "from-[#5a1417] via-[#27090b] to-[#050102]", accent: "#f59e0b" },
  { name: "STATE BANK", tint: "from-[#0d3a73] via-[#072245] to-[#01060f]", accent: "#22c55e" },
  { name: "AXIS BANK", tint: "from-[#5a0f3a] via-[#27071a] to-[#070103]", accent: "#e11d48" },
];

const variants: Variant[] = ["VISA", "Mastercard", "RuPay", "Business", "Corporate"];

function VariantBadge({ v }: { v: Variant }) {
  if (v === "VISA")
    return <span className="font-display text-lg font-black italic tracking-tight text-white">VISA</span>;
  if (v === "Mastercard")
    return (
      <div className="flex items-center">
        <span className="block h-6 w-6 rounded-full bg-[#eb001b] opacity-95" />
        <span className="-ml-2.5 block h-6 w-6 rounded-full bg-[#f79e1b] opacity-95 mix-blend-screen" />
      </div>
    );
  if (v === "RuPay")
    return (
      <span className="font-display text-sm font-black tracking-wide">
        <span className="text-[#0b6bcb]">Ru</span>
        <span className="text-[#16a34a]">Pay</span>
      </span>
    );
  if (v === "Business")
    return (
      <span className="rounded-md border border-white/30 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-white/90">
        Business
      </span>
    );
  return (
    <span className="rounded-md bg-white/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-mint">
      Corporate
    </span>
  );
}

function MockCard({ bank, variant }: { bank: (typeof banks)[number]; variant: Variant }) {
  return (
    <div
      className={`relative h-[170px] w-[280px] shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br ${bank.tint} p-4 shadow-[0_18px_40px_-20px_rgba(0,0,0,0.9)] ring-1 ring-white/10`}
    >
      {/* sheen */}
      <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
      <div
        className="pointer-events-none absolute -right-8 bottom-0 h-24 w-24 rounded-full blur-2xl"
        style={{ background: `${bank.accent}55` }}
      />

      <div className="flex items-start justify-between">
        <div>
          <div className="text-[9px] font-bold uppercase tracking-[0.25em] text-white/70">{bank.name}</div>
          <div className="mt-0.5 text-[10px] font-semibold tracking-widest text-mint">SmartPay · AI</div>
        </div>
        <Wifi className="h-4 w-4 -rotate-90 text-white/80" />
      </div>

      {/* chip */}
      <div className="mt-4 flex items-center gap-3">
        <div className="grid h-8 w-11 grid-cols-3 gap-px overflow-hidden rounded-md bg-gradient-to-br from-[#f1d27a] via-[#c69a3b] to-[#8a6622] p-[2px]">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-[#7a5a1c]/60" />
          ))}
        </div>
        <span className="text-[10px] font-semibold tracking-widest text-white/60">DEBIT · CREDIT</span>
      </div>

      <div className="mt-3 font-mono text-[13px] font-semibold tracking-[0.18em] text-white/95">
        4565 •••• •••• 2356
      </div>

      <div className="mt-3 flex items-end justify-between">
        <div>
          <div className="text-[8px] uppercase tracking-widest text-white/55">Card Holder</div>
          <div className="font-display text-[11px] font-bold uppercase tracking-wide text-white/95">
            Ravi Kumar
          </div>
        </div>
        <div className="text-right">
          <div className="text-[8px] uppercase tracking-widest text-white/55">Valid Thru</div>
          <div className="font-mono text-[11px] font-semibold text-white/95">11/29</div>
        </div>
        <VariantBadge v={variant} />
      </div>
    </div>
  );
}

export function CardMarquee() {
  const cards = banks.flatMap((b) => variants.map((v) => ({ bank: b, variant: v })));
  // duplicate enough times so the track is always wider than any viewport
  const loop = [...cards, ...cards, ...cards, ...cards];
  return (
    <div className="card-marquee mt-5">
      <div className="mb-3 text-center text-[10px] font-bold uppercase tracking-[0.3em] text-mint">
        Supported Card Networks · Live Preview
      </div>
      <div className="card-marquee-mask">
        <div className="card-marquee-track">
          {loop.map((c, i) => (
            <MockCard key={i} bank={c.bank} variant={c.variant} />
          ))}
        </div>
      </div>
    </div>
  );
}
