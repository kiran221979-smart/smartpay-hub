import { Play } from "lucide-react";

const demos = [
  { title: "Instant Card → Bank", sub: "End-to-end in 30 seconds", tint: "from-mint/30 via-sapphire/20 to-transparent" },
  { title: "Bill Pay Autopilot", sub: "5-day pre-due alert", tint: "from-sapphire/30 via-mint/15 to-transparent" },
  { title: "Lady AI OTP Agent", sub: "Voice-verified credit", tint: "from-mint/25 via-burnt/15 to-transparent" },
  { title: "Agentic Withdrawal", sub: "24/7 autonomous", tint: "from-sapphire/25 via-mint/20 to-transparent" },
  { title: "AI CIBIL Booster", sub: "Smart score optimization", tint: "from-mint/20 via-sapphire/25 to-transparent" },
  { title: "Multi-Bank Sync", sub: "Unified dashboard view", tint: "from-sapphire/20 via-mint/25 to-transparent" },
];

export function VideoDemoHub() {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          Live Demo Hub
        </div>
        <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">See it work, end-to-end</h2>
        <p className="mt-2 text-sm text-muted-foreground sm:text-base">
          Six cinematic walkthroughs of the platform's core rails.
        </p>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {demos.map((d, i) => (
          <button
            key={d.title}
            className="press press-on group relative overflow-hidden rounded-3xl border border-border bg-slate-elevated shadow-elevated transition hover:border-mint hover:shadow-mint"
            style={{ animationDelay: `${i * 80}ms`, minHeight: "clamp(280px, 32vw, 420px)" }}
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${d.tint}`} />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,var(--color-mint)/0.22,transparent_60%)] opacity-80 transition group-hover:opacity-100" />
            {/* scanline ambience */}
            <div className="pointer-events-none absolute inset-0 opacity-20 [background-image:linear-gradient(transparent_50%,rgba(255,255,255,0.04)_50%)] [background-size:100%_4px]" />
            <div className="absolute inset-0 grid place-items-center">
              <div className="grid h-20 w-20 place-items-center rounded-full bg-mint text-mint-foreground shadow-mint transition group-hover:scale-110 sm:h-24 sm:w-24">
                <Play className="h-9 w-9 fill-current sm:h-10 sm:w-10" />
              </div>
            </div>
            <div className="absolute left-5 top-5 inline-flex items-center gap-1 rounded-full bg-slate-deep/85 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-mint backdrop-blur">
              ▶ Cinematic Demo · 4K
            </div>
            <div className="absolute right-5 top-5 inline-flex items-center gap-1 rounded-full bg-slate-deep/85 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-mint/90 backdrop-blur">
              {String(i + 1).padStart(2, "0")} / 06
            </div>
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-deep via-slate-deep/90 to-transparent p-6 text-left sm:p-8">
              <div className="font-display text-xl font-bold sm:text-2xl">{d.title}</div>
              <div className="mt-1 text-sm text-mint">{d.sub}</div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
