import { useState } from "react";
import { Play, Sparkles } from "lucide-react";
import { useAdmin, type Product } from "@/lib/admin-store";
import { Modal } from "./BillPaymentFlow";
import walletExpert from "@/assets/wallet-os-expert.jpg";
import ledgerExpert from "@/assets/ledger-core-expert.jpg";
import payoutExpert from "@/assets/payout-rails-expert.jpg";

const fintechExperts: Record<string, string> = {
  p1: walletExpert,
  p2: ledgerExpert,
  p3: payoutExpert,
};

export function ProductGrid({ category, title }: { category: Product["category"]; title: string }) {
  const { products } = useAdmin();
  const items = products.filter((p) => p.category === category);
  const [open, setOpen] = useState<Product | null>(null);

  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
            <Sparkles className="h-3 w-3" /> Marketplace
          </div>
          <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">{title}</h2>
        </div>
        <div className="hidden text-sm text-muted-foreground sm:block">{items.length} products</div>
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <article key={p.id} className="press group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-slate-elevated shadow-elevated transition hover:-translate-y-1 hover:border-mint hover:shadow-mint">
            <div className="relative aspect-[4/3] overflow-hidden">
              <img
                src={category === "fintech" ? fintechExperts[p.id] ?? walletExpert : p.cover}
                alt={`Smart Pay human fintech specialist presenting ${p.title}`}
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                loading="lazy"
                width={1024}
                height={768}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-deep via-slate-deep/40 to-transparent" />
              <button className="press press-on absolute right-3 top-3 grid h-12 w-12 place-items-center rounded-full bg-mint text-mint-foreground shadow-mint">
                <Play className="h-5 w-5 fill-current" />
              </button>
              <div className="absolute left-3 top-3 rounded-full bg-slate-deep/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint backdrop-blur">
                10s preview
              </div>
            </div>
            <div className="flex flex-1 flex-col p-5">
              <h3 className="font-display text-lg font-bold">{p.title}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.shortDesc}</p>
              <div className="mt-4 flex items-center justify-between">
                <div className="font-display text-2xl font-black text-mint">₹{p.price.toLocaleString()}</div>
                <button onClick={() => setOpen(p)} className="press press-on rounded-xl border border-mint/50 bg-mint/10 px-4 py-2 text-xs font-bold uppercase tracking-widest text-mint hover:bg-mint hover:text-mint-foreground">
                  View Details & Benefits
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {open && (
        <Modal onClose={() => setOpen(null)} wide>
          <div className="grid gap-5 sm:grid-cols-2">
            <img src={category === "fintech" ? fintechExperts[open.id] ?? walletExpert : open.cover} alt={`Human specialist for ${open.title}`} className="aspect-square w-full rounded-2xl object-cover" loading="lazy" width={1024} height={768} />
            <div>
              <h3 className="font-display text-2xl font-bold">{open.title}</h3>
              <div className="mt-1 font-display text-3xl font-black text-mint">₹{open.price.toLocaleString()}</div>
              <p className="mt-4 text-sm text-foreground/90">{open.longDesc}</p>
              <div className="mt-4 rounded-xl border border-border bg-slate-deep p-3">
                <div className="text-xs font-bold uppercase tracking-widest text-mint">15-Page Cinematic Blueprint</div>
                <ul className="mt-2 space-y-1.5 text-sm">
                  {open.benefits.map((b) => (
                    <li key={b} className="flex gap-2"><span className="text-mint">✓</span>{b}</li>
                  ))}
                </ul>
              </div>
              <button className="press press-on mt-5 w-full rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint">
                Purchase Now
              </button>
            </div>
          </div>
        </Modal>
      )}
    </section>
  );
}
