import { useEffect, useRef, useState } from "react";
import {
  ShieldCheck,
  CreditCard,
  Upload,
  QrCode,
  UserCheck,
  UserPlus,
  Brain,
  Activity,
  Zap,
  CheckCircle2,
  Wallet,
  BellRing,
  FileText,
  Lock,
} from "lucide-react";

import { toast } from "sonner";

import { ServerDownGate } from "./ServerStatusBanner";
import { INDIAN_BANKS } from "@/lib/banks";

function formatCard(v: string) {
  return v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
}
function formatExpiry(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
}

/* ────────────────────────── UTILITY DESK ────────────────────────── */

type UtilityBox = {
  id: string;
  title: string;
  desc: string;
  Icon: typeof Wallet;
  meta: string;
};

const UTILITY_BOXES: UtilityBox[] = [
  {
    id: "vault",
    title: "Saved Cards Vault",
    desc: "Securely dashboard and view all tracked cards with active outstanding limits.",
    Icon: Wallet,
    meta: "Manage My Cards",
  },
  {
    id: "alerts",
    title: "Card Due Alerts Engine",
    desc: "Interactive automated 5, 4, 3, 2, 1-day decrementing countdown notification grid.",
    Icon: BellRing,
    meta: "T-5 → T-1 Decrementing",
  },
  {
    id: "invoice",
    title: "Monthly Statement & Auto Invoice Hub",
    desc: "Compile monthly transaction data and auto-download secure PDF invoice receipts upon successful checkout.",
    Icon: FileText,
    meta: "PDF · Encrypted",
  },
];

function UtilityDesk() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {UTILITY_BOXES.map(({ id, title, desc, Icon, meta }) => (
        <div
          key={id}
          className="group relative overflow-hidden rounded-2xl border border-mint/40 bg-slate-deep p-5 shadow-mint transition hover:border-mint hover:shadow-[0_0_40px_-10px_color-mix(in_oklab,var(--color-mint)_60%,transparent)]"
        >
          <div
            className="pointer-events-none absolute inset-0 bg-[linear-gradient(135deg,transparent_40%,color-mix(in_oklab,var(--color-mint)_8%,transparent)_50%,transparent_60%)] opacity-0 transition group-hover:opacity-100"
            aria-hidden
          />
          <div className="flex items-start justify-between">
            <div className="grid h-11 w-11 place-items-center rounded-xl border border-mint/50 bg-mint/10 text-mint">
              <Icon className="h-5 w-5" />
            </div>
            <span className="rounded-full border border-mint/30 bg-slate-elevated px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-mint/80">
              {meta}
            </span>
          </div>
          <div className="mt-4 font-display text-base font-black text-foreground">{title}</div>
          <p className="mt-1.5 text-[12px] leading-relaxed text-muted-foreground">{desc}</p>
        </div>
      ))}
    </div>
  );
}

/* ────────────────────────── EXISTING FORM PARTS ────────────────────────── */

function QrPaymentBox({ amount }: { amount: string }) {
  const upi = `upi://pay?pa=smartpay@hdfc&pn=SmartPay&am=${amount || "0"}&cu=INR`;
  const qr = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&bgcolor=0F1729&color=4FD1C5&data=${encodeURIComponent(upi)}`;
  return (
    <div className="rounded-2xl border border-mint/40 bg-slate-deep p-5 shadow-mint">
      <div className="flex items-center gap-2 text-mint">
        <QrCode className="h-5 w-5" />
        <div className="text-sm font-bold uppercase tracking-widest">Dynamic QR · Payment Link</div>
      </div>
      <div className="mt-4 grid items-center gap-5 sm:grid-cols-[180px_1fr]">
        <div className="mx-auto grid h-[200px] w-[200px] place-items-center rounded-xl border border-mint/40 bg-white/5 p-2">
          <img src={qr} alt="Dynamic UPI QR" className="h-full w-full rounded-lg object-contain" loading="lazy" />
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-mint">UPI Link</div>
          <div className="mt-1 break-all rounded-lg border border-mint/25 bg-slate-elevated p-2 font-mono text-[11px] text-foreground/85">
            {upi}
          </div>
          <p className="mt-2 text-[11px] leading-snug text-muted-foreground">
            Scan the QR or tap the link to settle. After payment, upload the receipt below for instant verification.
          </p>
          <label className="press press-on mt-3 inline-flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-mint/50 bg-mint/10 px-4 py-2.5 text-sm font-bold text-mint hover:bg-mint/15">
            <Upload className="h-4 w-4" /> Upload Receipt Screenshot
            <input type="file" accept="image/*" className="hidden" />
          </label>
        </div>
      </div>
    </div>
  );
}

type CibilStatus = "idle" | "running" | "approved" | "rejected";

function CibilScanGrid({
  status,
  setStatus,
}: {
  status: CibilStatus;
  setStatus: (s: CibilStatus) => void;
}) {
  const handleRun = () => {
    setStatus("running");
    const verdict: CibilStatus = Math.random() < 0.7 ? "approved" : "rejected";
    window.setTimeout(() => setStatus(verdict), 2500);
  };

  return (
    <div className="rounded-2xl border border-mint/30 bg-slate-deep p-5 shadow-mint">
      <div className="flex items-center gap-2 text-mint">
        <Brain className="h-5 w-5" />
        <div className="text-sm font-bold uppercase tracking-widest">Free AI CIBIL Scan Grid</div>
      </div>
      <p className="mt-2 text-xs leading-relaxed text-foreground/85">
        Our Smart AI will instantly analyze your credit report and route your eligibility verdict.
      </p>

      {status === "idle" && (
        <button
          type="button"
          onClick={handleRun}
          className="press press-on mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-mint/50 bg-mint/10 px-4 py-3 text-sm font-bold text-mint hover:bg-mint/15"
        >
          <Activity className="h-4 w-4" /> Run Free AI CIBIL Scan
        </button>
      )}

      {status === "running" && (
        <div className="mt-4 flex items-center gap-3 rounded-xl border border-mint/25 bg-slate-elevated px-4 py-3">
          <Zap className="h-4 w-4 animate-pulse text-mint" />
          <span className="text-xs font-semibold text-mint">Analyzing credit report with AI… please wait</span>
        </div>
      )}

      {status === "approved" && (
        <div className="mt-4 grid gap-2 rounded-xl border border-mint/40 bg-slate-elevated p-4 shadow-mint">
          <div className="flex items-center gap-2 text-sm font-bold text-mint">
            <CheckCircle2 className="h-4 w-4 animate-pulse" /> AI Status: Approved
          </div>
          <div className="mt-1 grid grid-cols-3 gap-2 text-center">
            {[
              { k: "Score", v: "782" },
              { k: "Status", v: "Excellent" },
              { k: "Cards", v: "3 Matched" },
            ].map((s) => (
              <div key={s.k} className="rounded-lg border border-mint/15 bg-slate-deep px-2 py-2">
                <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{s.k}</div>
                <div className="mt-0.5 font-display text-sm font-black text-mint">{s.v}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 text-[11px] text-muted-foreground">
            Unlocking secure bill payment form below…
          </div>
        </div>
      )}

      {status === "rejected" && (
        <div className="mt-4 rounded-xl border-2 border-amber-400/60 bg-amber-500/10 p-4 shadow-[0_0_30px_-8px_rgba(251,191,36,0.5)]">
          <div className="flex items-start gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-amber-400/60 bg-amber-500/20 text-amber-300">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-black uppercase tracking-wider text-amber-300">
                Transaction Terminated by AI Risk Engine
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-foreground/90">
                Please contact our official technical support matrix immediately at:{" "}
                <span className="font-mono font-bold text-amber-200">+91 XXXXXXXXXX</span>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ────────────────────────── MAIN ────────────────────────── */

export function SmartPortal() {
  const ref = useRef<HTMLDivElement>(null);
  const [submitted, setSubmitted] = useState(false);
  const [customerType, setCustomerType] = useState<"existing" | "new">("existing");
  const [cibilStatus, setCibilStatus] = useState<CibilStatus>("idle");
  const paymentBlockRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handler = () => ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    window.addEventListener("launch-smart-portal", handler);
    return () => window.removeEventListener("launch-smart-portal", handler);
  }, []);

  useEffect(() => {
    if (cibilStatus === "approved") {
      window.setTimeout(() => {
        paymentBlockRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 400);
    }
  }, [cibilStatus]);

  const [form, setForm] = useState({
    name: "",
    mobile: "",
    bank: INDIAN_BANKS[0],
    amount: "",
    card: "",
    expiry: "",
    cvv: "",
  });

  const numericAmount = Number(form.amount || 0);
  const processingCharges = Math.round(numericAmount * 0.015);
  const totalPayable = numericAmount + processingCharges;

  return (
    <section ref={ref} id="smart-portal" className="mx-auto w-full max-w-7xl scroll-mt-24 px-4 py-16 sm:px-6 lg:px-10">
      {/* TOP UTILITY DESK */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
          ◈ Utility Desk · Core Modules
        </div>
        <h2 className="mt-3 font-display text-2xl font-black sm:text-3xl">Command Center</h2>
      </div>
      <div className="mt-6">
        <UtilityDesk />
      </div>

      {/* CONDITIONAL FORM */}
      <div className="mt-14 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
          ◈ Secure Checkout Terminal
        </div>
        <h2 className="mt-3 font-display text-2xl font-black sm:text-3xl">Credit Card Bill Payment</h2>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground">
          Choose your customer profile, enter card details, and settle securely in under 45 seconds.
        </p>
      </div>

      <div className="mt-8">
        <ServerDownGate>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (customerType === "existing") {
                // Intentionally empty — message is shown via the submitted confirmation block below
              }
              setSubmitted(true);
            }}
            className="mx-auto w-full max-w-4xl rounded-3xl border border-border bg-slate-elevated p-6 shadow-elevated sm:p-8"
          >
            {/* Customer type toggle */}
            <div className="mb-6 grid grid-cols-2 gap-2 rounded-2xl border border-mint/30 bg-slate-deep p-1.5">
              {[
                { id: "existing" as const, label: "Existing Customer", Icon: UserCheck },
                { id: "new" as const, label: "New Customer", Icon: UserPlus },
              ].map(({ id, label, Icon }) => {
                const active = customerType === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      setCustomerType(id);
                      setCibilStatus("idle");
                      setSubmitted(false);
                    }}
                    className={`press press-on inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition ${
                      active
                        ? "gradient-mint text-primary-foreground shadow-mint"
                        : "text-foreground/70 hover:text-mint"
                    }`}
                  >
                    <Icon className="h-4 w-4" /> {label}
                  </button>
                );
              })}
            </div>

            {/* CIBIL scan — required ONLY for New Customers */}
            {customerType === "new" && (
              <CibilScanGrid status={cibilStatus} setStatus={setCibilStatus} />
            )}

            {/* Payment block — always visible for Existing; locked for New until AI approval */}
            {(() => {
              const locked = customerType === "new" && cibilStatus !== "approved";
              const rejected = customerType === "new" && cibilStatus === "rejected";

              return (
                <div ref={paymentBlockRef} className="relative mt-6">
                  <fieldset
                    disabled={locked}
                    aria-disabled={locked}
                    className={`transition-all duration-500 ${
                      locked ? "pointer-events-none select-none opacity-40 blur-[1.5px]" : "opacity-100 blur-0"
                    }`}
                  >
                    {/* Payment details header */}
                    <div className="flex items-center gap-2 text-mint">
                      <CreditCard className="h-5 w-5" />
                      <div className="text-sm font-bold uppercase tracking-widest">
                        {customerType === "existing" ? "Welcome Back · Confirm Card Details" : "Enter Billing Details"}
                      </div>
                    </div>

                    {/* Shared form fields */}
                    <div className="mt-5 grid gap-4 sm:grid-cols-2">
                      <Field label="Customer Full Name">
                        <input
                          required={!locked}
                          value={form.name}
                          onChange={(e) => setForm({ ...form, name: e.target.value })}
                          className="input"
                          placeholder="Ravi Kumar"
                        />
                      </Field>
                      <Field label="Contact Mobile Number">
                        <input
                          required={!locked}
                          value={form.mobile}
                          onChange={(e) => setForm({ ...form, mobile: e.target.value.replace(/\D/g, "").slice(0, 10) })}
                          className="input"
                          placeholder="98xxxxxxxx"
                          inputMode="numeric"
                        />
                      </Field>
                      <div className="sm:col-span-2">
                        <Field label="Credit Card Number (16 digits)">
                          <input
                            required={!locked}
                            value={form.card}
                            onChange={(e) => setForm({ ...form, card: formatCard(e.target.value) })}
                            className="input font-mono tracking-[0.25em]"
                            placeholder="1111 2222 3333 4444"
                            inputMode="numeric"
                            maxLength={19}
                          />
                        </Field>
                      </div>
                      <Field label="Expiry Date (MM/YY)">
                        <input
                          required={!locked}
                          value={form.expiry}
                          onChange={(e) => setForm({ ...form, expiry: formatExpiry(e.target.value) })}
                          className="input font-mono"
                          placeholder="MM/YY"
                          inputMode="numeric"
                          maxLength={5}
                        />
                      </Field>
                      <Field label="CVV (3 digits)">
                        <input
                          required={!locked}
                          type="password"
                          value={form.cvv}
                          onChange={(e) => setForm({ ...form, cvv: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                          className="input font-mono tracking-widest"
                          placeholder="•••"
                          inputMode="numeric"
                          maxLength={3}
                        />
                      </Field>
                      <div className="sm:col-span-2">
                        <Field label="Total Bill Amount (₹)">
                          <input
                            required={!locked}
                            value={form.amount}
                            onChange={(e) => setForm({ ...form, amount: e.target.value.replace(/\D/g, "") })}
                            className="input"
                            placeholder="25000"
                            inputMode="numeric"
                          />
                        </Field>
                      </div>
                    </div>

                    <div className="mt-6">
                      <QrPaymentBox amount={form.amount} />
                    </div>

                    {numericAmount > 0 && (
                      <div className="mt-5 rounded-2xl border border-mint/30 bg-slate-deep p-5">
                        <div className="text-[10px] font-bold uppercase tracking-widest text-mint/70">Payment Breakdown</div>
                        <div className="mt-3 flex items-center justify-between border-b border-mint/10 pb-2">
                          <span className="text-sm text-muted-foreground">Processing Charges (1.5%)</span>
                          <span className="font-mono text-sm font-semibold text-mint">₹{processingCharges.toLocaleString("en-IN")}</span>
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                          <span className="text-sm font-bold text-foreground">Total Payable</span>
                          <span className="font-mono text-base font-black text-mint">₹{totalPayable.toLocaleString("en-IN")}</span>
                        </div>
                      </div>
                    )}

                    <div className="mt-5 flex items-start gap-3 rounded-xl border border-mint/40 bg-mint/10 p-3">
                      <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-mint" />
                      <p className="text-xs leading-relaxed text-foreground/90">
                        🛡️ Your card details are 100% secure with PCI-DSS bank-grade encryption. We never store CVV.
                      </p>
                    </div>

                    <div
                      className="mt-5 flex items-center justify-between rounded-xl border border-mint/40 bg-slate-deep px-4 py-3 shadow-mint"
                      aria-live="polite"
                    >
                      <span className="text-[11px] font-bold uppercase tracking-widest text-mint/80">
                        AI Route Processing Charges
                      </span>
                      <span className="font-mono text-base font-black text-mint">
                        ₹{processingCharges.toLocaleString("en-IN")}
                      </span>
                    </div>

                    <button
                      type="submit"
                      className="press press-on mt-4 w-full rounded-xl gradient-mint py-3.5 font-display text-base font-bold text-primary-foreground shadow-mint"
                    >
                      Initiate Bill Payment
                    </button>
                  </fieldset>

                  {/* LOCK OVERLAY */}
                  {locked && (
                    <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-slate-deep/55 backdrop-blur-[2px] transition-opacity duration-500">
                      <div
                        className={`mx-4 max-w-md rounded-2xl border-2 px-6 py-5 text-center shadow-mint ${
                          rejected
                            ? "border-amber-400/60 bg-amber-500/10"
                            : "border-mint/50 bg-slate-deep/90"
                        }`}
                      >
                        <div
                          className={`mx-auto grid h-14 w-14 place-items-center rounded-full border-2 ${
                            rejected
                              ? "border-amber-400/70 bg-amber-500/20 text-amber-300"
                              : "border-mint/60 bg-mint/15 text-mint animate-pulse"
                          }`}
                        >
                          <Lock className="h-7 w-7" />
                        </div>
                        <div className={`mt-3 font-display text-sm font-black uppercase tracking-widest ${rejected ? "text-amber-300" : "text-mint"}`}>
                          {rejected ? "Payment Form Frozen" : "Bill Payment Form Locked"}
                        </div>
                        <p className="mt-2 text-xs leading-relaxed text-foreground/85">
                          {rejected
                            ? "AI Risk Engine terminated this session. See the warning above and contact support to proceed."
                            : "Complete the Free AI CIBIL Scan above. The form unlocks instantly on AI approval."}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}


            {submitted && (
              <div className="mt-5 rounded-2xl border border-mint/40 bg-slate-deep p-4 text-center text-sm text-mint">
                Charges Amount Received. Our staff will connect with you shortly to process your total bill amount settlement.
              </div>
            )}
          </form>
        </ServerDownGate>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      {children}
    </label>
  );
}
