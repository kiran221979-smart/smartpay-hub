import { useState } from "react";
import {
  Bot,
  Phone,
  QrCode,
  Upload,
  CheckCircle2,
  X,
  Calendar,
  MessageCircle,
  UserCheck,
  ShieldCheck,
} from "lucide-react";
import { useAdmin } from "@/lib/admin-store";
import { ServerDownGate } from "./ServerStatusBanner";
import { INDIAN_BANKS } from "@/lib/banks";

type CustomerType = "new" | "existing";

export function BillPaymentFlow() {
  const { agentMode } = useAdmin();
  const [customerType, setCustomerType] = useState<CustomerType>("new");
  const [step, setStep] = useState(0);
  const [ladyOpen, setLadyOpen] = useState(false);
  const [success, setSuccess] = useState(false);
  const [fee, setFee] = useState<number | null>(null);
  const [amount, setAmount] = useState("");
  const [bank, setBank] = useState(INDIAN_BANKS[0]);

  const steps = ["Input", "CIBIL Scan", "Calculation", "QR Pay", "Receipt Upload"];

  const advanceFromInput = () => {
    const calcFee = amount ? Math.round(Number(amount) * 0.022) : 0;
    setFee(calcFee);
    // Existing customer skips CIBIL scan and jumps directly to calc / QR
    setStep(customerType === "existing" ? 2 : 1);
    if (customerType === "new") {
      // simulate AI CIBIL completion → fee calc
      setTimeout(() => setStep(2), 1500);
    }
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-burnt/40 bg-burnt/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-burnt">
          Bill Payment Workflow
        </div>
        <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">5-Step Smart Bill Pay</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          <span className="font-semibold text-mint">Withdrawal: 24/7 Support</span> ·{" "}
          <span className="font-semibold text-burnt">Bill Pay: 09:00 AM to 09:00 PM</span>
        </p>
      </div>

      {/* Customer type toggle */}
      <div className="mx-auto mt-6 flex max-w-md items-center gap-2 rounded-full border border-border bg-slate-elevated p-1">
        {(["new", "existing"] as CustomerType[]).map((c) => (
          <button
            key={c}
            onClick={() => {
              setCustomerType(c);
              setStep(0);
              setFee(null);
            }}
            className={`press press-on flex-1 rounded-full py-2 text-sm font-bold capitalize transition ${
              customerType === c
                ? "gradient-mint text-primary-foreground shadow-mint"
                : "text-foreground/80"
            }`}
          >
            <UserCheck className="mr-1 inline h-3.5 w-3.5" /> {c} Customer
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-3 sm:grid-cols-5">
        {steps.map((s, i) => {
          const skipped = customerType === "existing" && i === 1;
          return (
            <div
              key={s}
              className={`press rounded-xl border p-3 text-center text-xs font-semibold ${
                skipped
                  ? "border-dashed border-border/60 bg-slate-elevated text-muted-foreground line-through"
                  : i <= step
                    ? "border-mint bg-mint/10 text-mint"
                    : "border-border bg-slate-elevated text-muted-foreground"
              }`}
            >
              <div className="font-display text-lg">{i + 1}</div>
              {s}
            </div>
          );
        })}
      </div>

      <ServerDownGate>
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-slate-elevated p-6">
            <div className="text-sm font-bold uppercase tracking-widest text-mint">
              1. Bill Details
            </div>
            <div className="mt-4 grid gap-3">
              <input className="input" placeholder="Card / Biller Name" />
              <select className="input" value={bank} onChange={(e) => setBank(e.target.value)}>
                {INDIAN_BANKS.map((b) => (
                  <option key={b}>{b}</option>
                ))}
              </select>
              <input
                className="input"
                placeholder="Bill Amount (₹)"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/\D/g, ""))}
              />
              <button
                onClick={advanceFromInput}
                className="press press-on rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint"
              >
                {customerType === "existing" ? "Skip Scan → Get Fee & QR" : "Run AI CIBIL Scan"}
              </button>
            </div>
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-mint/40 bg-mint/10 p-3">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-mint" />
              <p className="text-[11px] leading-relaxed text-foreground/90">
                🛡️ Your card details are 100% secure with PCI-DSS bank-grade encryption. Preventing
                fraud and protecting your data is our ultimate responsibility.
              </p>
            </div>

            {customerType === "new" && step === 1 && (
              <div className="mt-5 rounded-xl border border-mint/40 bg-mint/10 p-4 animate-fade-up">
                <div className="text-xs uppercase tracking-widest text-mint">AI CIBIL Scan</div>
                <div className="mt-1 font-display text-lg font-bold">
                  Validating bureau signals…
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full w-2/3 animate-pulse gradient-mint" />
                </div>
              </div>
            )}

            {fee !== null && step >= 2 && (
              <div className="mt-5 rounded-xl border border-burnt/40 bg-burnt/10 p-4 animate-fade-up">
                <div className="text-xs uppercase tracking-widest text-burnt">
                  Auto Fee Calculation
                </div>
                <div className="mt-1 font-display text-2xl font-bold">Service charge: ₹{fee}</div>
                <div className="text-xs text-muted-foreground">
                  Dynamic processing fee applied automatically.
                </div>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-slate-elevated p-6">
            <div className="text-sm font-bold uppercase tracking-widest text-mint">
              2. Pay & Upload
            </div>
            <div className="mt-4 grid place-items-center rounded-xl border-2 border-dashed border-mint/40 bg-slate-deep p-6">
              <div className="grid h-32 w-32 place-items-center rounded-xl bg-white text-slate-deep">
                <QrCode className="h-24 w-24" />
              </div>
              <div className="mt-2 text-xs text-muted-foreground">UPI QR · Static settlement</div>
            </div>
            <label className="press press-on mt-4 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-border bg-slate-deep py-3 text-sm font-semibold hover:border-mint">
              <Upload className="h-4 w-4" /> Upload Receipt Screenshot
              <input type="file" className="hidden" onChange={() => setStep(4)} />
            </label>

            <button
              onClick={() => {
                if (agentMode === "lady-ai") setLadyOpen(true);
                else setSuccess(true);
              }}
              className="press press-on mt-3 flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint"
            >
              {agentMode === "lady-ai" ? (
                <>
                  <Bot className="h-4 w-4" /> Run Lady AI Agent
                </>
              ) : (
                <>
                  <Phone className="h-4 w-4" /> Trigger Manual Call
                </>
              )}
            </button>
          </div>
        </div>
      </ServerDownGate>

      <div className="mt-10 rounded-2xl border border-mint/40 bg-mint/5 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-mint">
            <MessageCircle className="h-5 w-5" />
            <div className="font-display text-base font-bold">
              Proactive Payment Protection Engine — Daily Countdown Matrix
              <div className="text-[10px] font-semibold uppercase tracking-widest text-mint/80">
                Linked to per-card due dates from Unified Ledger
              </div>
            </div>
          </div>
          <span className="rounded-full border border-mint/40 bg-mint/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-mint">
            Multi-Channel · WhatsApp · SMS · Email · Push
          </span>
        </div>

        <div className="mt-4 grid gap-2.5 sm:grid-cols-5">
          {[
            { d: "5", emoji: "🚨", title: "First Payment Check Trigger", tone: "ring-mint/60 bg-mint/10" },
            { d: "4", emoji: "⏳", title: "Daily Multi-Channel Alert", tone: "ring-mint/40 bg-mint/5" },
            { d: "3", emoji: "⏳", title: "Daily Multi-Channel Alert", tone: "ring-burnt/40 bg-burnt/5" },
            { d: "2", emoji: "⏳", title: "Daily Multi-Channel Alert", tone: "ring-burnt/50 bg-burnt/10" },
            { d: "1", emoji: "⏳", title: "Final Day Countdown Alert", tone: "ring-red-500/60 bg-red-500/10" },
          ].map((s) => (
            <div key={s.d} className={`rounded-xl p-3 text-center ring-1 ${s.tone}`}>
              <div className="text-2xl">{s.emoji}</div>
              <div className="mt-1 font-display text-lg font-black">
                {s.d} {s.d === "1" ? "Day" : "Days"}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Before Due Date
              </div>
              <div className="mt-1.5 text-[11px] font-semibold text-foreground/85">{s.title}</div>
            </div>
          ))}
        </div>


        <div className="mt-4 flex items-center gap-2 rounded-xl border border-burnt/40 bg-burnt/5 p-3 text-xs text-muted-foreground">
          <Calendar className="h-4 w-4 text-burnt" />
          <span>
            <span className="font-bold text-burnt">Service Timings:</span> Withdrawal 24/7 Support · Bill Pay 09:00 AM – 09:00 PM
          </span>
        </div>
      </div>

      {ladyOpen && (
        <Modal onClose={() => setLadyOpen(false)}>
          <div className="text-center">
            <div className="mx-auto grid h-28 w-28 place-items-center rounded-full gradient-mint shadow-mint animate-float">
              <Bot className="h-14 w-14 text-primary-foreground" />
            </div>
            <h3 className="mt-5 font-display text-2xl font-bold">Lady AI Voice Agent</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              "Hello, please share the OTP sent to your registered mobile."
            </p>
            <div className="mt-5 flex justify-center gap-2">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <input
                  key={i}
                  className="input h-12 w-10 text-center text-lg font-mono"
                  maxLength={1}
                />
              ))}
            </div>
            <button
              onClick={() => {
                setLadyOpen(false);
                setSuccess(true);
              }}
              className="press press-on mt-6 w-full rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint"
            >
              Verify & Push Wallet Credit
            </button>
          </div>
        </Modal>
      )}

      {success && (
        <Modal onClose={() => setSuccess(false)} wide>
          <div className="text-center">
            <CheckCircle2 className="mx-auto h-20 w-20 text-mint" />
            <h3 className="mt-4 font-display text-3xl font-bold">Transaction Successful!</h3>
            <p className="mt-1 text-muted-foreground">Thank you for choosing Smart Pay</p>
            <div className="mt-6 rounded-2xl border border-border bg-slate-deep p-5 text-left text-sm">
              <Row k="Transaction ID" v={`SMP-${Date.now()}`} />
              <Row k="Amount" v={amount ? `₹${Number(amount).toLocaleString()}` : "—"} />
              <Row k="Service Charge" v={fee !== null ? `₹${fee}` : "—"} />
              <Row k="Status" v="Credited" mint />
            </div>
            <button
              type="button"
              onClick={() => {
                const blob = new Blob([
                  `Smart Pay · Automated Digital Invoice\nTxn ID: SMP-${Date.now()}\nAmount: ₹${amount || "—"}\nFee: ₹${fee ?? "—"}\nStatus: Credited\n`,
                ], { type: "application/pdf" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `SmartPay-Invoice-${Date.now()}.pdf`;
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="press press-on mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint"
            >
              ⬇ Download Automated Digital Invoice
            </button>
            <div
              className="mt-4 relative overflow-hidden rounded-2xl border-2 border-mint/60 bg-slate-deep p-4 text-left"
              style={{ boxShadow: "0 0 30px color-mix(in oklab, var(--color-mint) 35%, transparent), inset 0 0 18px color-mix(in oklab, var(--color-mint) 18%, transparent)" }}
            >
              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(transparent_0%,transparent_50%,color-mix(in_oklab,var(--color-mint)_10%,transparent)_50%,transparent_51%)] bg-[length:100%_4px] opacity-50" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="inline-flex items-center gap-1.5 rounded-full border border-mint/50 bg-mint/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-mint">
                    ◈ AI · Smart Digital Ledger
                  </div>
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-mint">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" /> Live · Indexed
                  </span>
                </div>
                <h4 className="mt-2 font-display text-base font-black text-mint">
                  AI-Powered Smart Digital Ledger &amp; Automated Invoice Tracker
                </h4>
                <p className="mt-1 text-[11px] leading-relaxed text-foreground/85">
                  ⟁ Txn hashed → ⟁ Ledger sealed → ⟁ Invoice mirrored to WhatsApp / Email → ⟁ Month-end PDF auto-dispatch at 00:00 IST.
                </p>
                <div className="mt-3 grid grid-cols-3 gap-1.5 text-center">
                  {[
                    { k: "Ledger ID", v: `LDG-${Date.now().toString().slice(-6)}` },
                    { k: "Hash", v: "0x9F·c4e2" },
                    { k: "Auto-Cycle", v: "Month-End" },
                  ].map((m) => (
                    <div key={m.k} className="rounded-lg border border-mint/30 bg-slate-elevated px-2 py-1.5">
                      <div className="text-[8px] uppercase tracking-widest text-muted-foreground">{m.k}</div>
                      <div className="mt-0.5 font-mono text-[10px] font-bold text-mint">{m.v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-3 rounded-xl border border-mint/30 bg-mint/5 p-3 text-left text-[11px] leading-relaxed text-foreground/85" lang="te">
              📲 5-Day WhatsApp / Email Countdown Sequence Armed:
              <div className="mt-1 font-mono text-[10px] text-mint">
                ఇంకా మీ బిల్ గడువు తేదీ [5 | 4 | 3 | 2 | 1] రోజులే ఉన్నది. Please settle your due via Smart Pay. (If already paid, please ignore this message.)
              </div>
            </div>
            <button
              onClick={() => setSuccess(false)}
              className="press press-on mt-4 w-full rounded-xl border border-border bg-slate-deep py-3 font-bold text-foreground/85 hover:border-mint"
            >
              Close Invoice
            </button>
          </div>
        </Modal>
      )}
    </section>
  );
}

function Row({ k, v, mint }: { k: string; v: string; mint?: boolean }) {
  return (
    <div className="flex items-center justify-between border-b border-border/60 py-2 last:border-0">
      <span className="text-muted-foreground">{k}</span>
      <span className={`font-mono font-semibold ${mint ? "text-mint" : ""}`}>{v}</span>
    </div>
  );
}

export function Modal({
  children,
  onClose,
  wide,
}: {
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-deep/80 p-4 backdrop-blur-md animate-fade-up">
      <div
        className={`relative w-full rounded-3xl border border-border bg-slate-elevated p-6 shadow-elevated ${wide ? "max-w-2xl" : "max-w-md"}`}
      >
        <button
          onClick={onClose}
          className="press press-on absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-mint text-mint-foreground shadow-mint"
          aria-label="Close dialog"
        >
          <X className="h-4 w-4" />
        </button>
        {children}
      </div>
    </div>
  );
}
