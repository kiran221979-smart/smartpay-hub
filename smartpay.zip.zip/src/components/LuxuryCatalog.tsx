import { useMemo, useState } from "react";
import { Play, X, Sparkles, BadgePercent, Gift, FileText, ShieldCheck, CalendarClock, CreditCard, Lock, QrCode } from "lucide-react";
import { toast } from "sonner";

type PriceBlock =
  | { kind: "standard"; mrp: number; intro: number; discount: number }
  | { kind: "shield"; sub: { label: string; price: number }[]; note: string };

type CatalogItem = {
  id: string;
  title: string;
  shortDesc: string;
  longDesc: string;
  benefits: string[];
  poster: string;
  category: "fintech" | "ai";
  price: PriceBlock;
};

const FINTECH_POSTERS = [
  "https://images.unsplash.com/photo-1556742400-b5b7c5121f6c?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1565514020179-026b92b84bb6?auto=format&fit=crop&w=1200&q=70",
];
const AI_POSTERS = [
  "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1535378917042-10a22c95931a?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=1200&q=70",
  "https://images.unsplash.com/photo-1633412802994-5c058f151b66?auto=format&fit=crop&w=1200&q=70",
];

const P = (mrp: number, discount: number, intro: number): PriceBlock => ({ kind: "standard", mrp, discount, intro });

// 21 FinTech Blueprints — hardcoded master config
const FINTECH: CatalogItem[] = [
  { id: "f1", category: "fintech", price: P(499, 70, 149),
    title: "The Ultimate Multi-Card Maximizer & Strategic Statement Hack Blueprint",
    shortDesc: "Orchestrate 6+ cards with a strategic statement-cycle hack engine.",
    longDesc: "The ultimate multi-card maximizer blueprint — engineer strategic statement-cycle hacks, compound rewards, and preserve every bank-side benefit across 6+ active credit cards.",
    benefits: ["Up to 6 card stacking", "Statement cycle hacks", "Bank loyalty preserved", "Auto rotation logic"], poster: FINTECH_POSTERS[0] },
  { id: "f2", category: "fintech", price: P(499, 70, 149),
    title: "Credit Score Build Strategy (No CIBIL to 780+)",
    shortDesc: "Zero history to 780+ CIBIL — full engineered roadmap.",
    longDesc: "A complete credit-score build strategy that takes a No-CIBIL profile to 780+ using engineered utilisation, age-of-credit shaping and bureau-side optimisation.",
    benefits: ["No-CIBIL to 780+ path", "90-day roadmap", "Utilisation balancer", "Monthly tracking"], poster: FINTECH_POSTERS[1] },
  { id: "f3", category: "fintech", price: P(399, 62, 149),
    title: "Business Loan & Mudra Loan Project Report Making Guide",
    shortDesc: "Bank-ready project report kit for Business & Mudra loans.",
    longDesc: "A step-by-step project report making guide for Business and Mudra loans — Shishu, Kishor and Tarun tiers — with bank-ready financials and document checklists.",
    benefits: ["Bank-ready project report", "Doc checklist", "Tier eligibility map", "Sample sanctions"], poster: FINTECH_POSTERS[2] },
  { id: "f4", category: "fintech", price: P(299, 66, 99),
    title: "IT Notice Reply Template & Guide",
    shortDesc: "Drafted reply templates for common IT notices.",
    longDesc: "Vetted reply templates and a guided framework for 139(9), 143(1), 148 and other common Income Tax notices, including deadline tracking.",
    benefits: ["Drafted replies", "Deadline tracker", "Section-wise guidance", "CA-reviewed"], poster: FINTECH_POSTERS[3] },
  { id: "f5", category: "fintech", price: P(299, 66, 99),
    title: "New Credit Card Eligibility Check",
    shortDesc: "Pre-check eligibility across 40+ Indian credit cards.",
    longDesc: "A pre-check eligibility framework across 40+ Indian credit cards — soft-pull tactics, bank affinity scoring and approval-probability mapping.",
    benefits: ["40+ card coverage", "Soft-pull tactics", "Bank affinity score", "Footprint guard"], poster: FINTECH_POSTERS[4] },
  { id: "f6", category: "fintech", price: P(499, 70, 149),
    title: "Emergency IT-Notice Help (SOS) — Instant Expert Guide & Critical Timeline Plan",
    shortDesc: "SOS expert guide with critical timeline for urgent IT notices.",
    longDesc: "An emergency SOS guide for critical Income Tax notices — instant expert framework, escalation matrix and a critical timeline plan to protect deadlines.",
    benefits: ["SOS framework", "Critical timeline plan", "Escalation matrix", "Expert checklists"], poster: FINTECH_POSTERS[0] },
  { id: "f7", category: "fintech", price: P(399, 62, 149),
    title: "Smart IT-Shield & Safe Rotation Limit Guide",
    shortDesc: "Safe rotation limit and IT-shield guardrails.",
    longDesc: "A Smart IT-Shield blueprint with safe rotation limits, exposure guardrails and engineered rotation cycles that stay within statutory windows.",
    benefits: ["Safe rotation limits", "Exposure guardrails", "Rotation cycles", "Statutory-safe"], poster: FINTECH_POSTERS[1] },
  { id: "f8", category: "fintech",
    price: { kind: "shield", sub: [{ label: "6-Month Shield", price: 499 }, { label: "12-Month Shield", price: 899 }], note: "Automatic monthly PDF intelligence report delivered to your inbox." },
    title: "Smart Shield — Fraud, Limit Protection & CIBIL Boost 12-Month Master Plan",
    shortDesc: "Subscription shield with fraud, limit and CIBIL boost monitoring.",
    longDesc: "A 12-month Smart Shield master plan — fraud monitoring, limit protection and CIBIL boost — delivered with an automatic monthly PDF intelligence report.",
    benefits: ["Automatic monthly PDF", "Fraud monitoring", "Limit protection", "CIBIL boost cadence"], poster: FINTECH_POSTERS[2] },
  { id: "f9", category: "fintech", price: P(499, 70, 149),
    title: "The Smart Family Wealth Transmission & Legal Heir Compliance Blueprint",
    shortDesc: "Family wealth transmission with legal heir compliance.",
    longDesc: "An end-to-end family wealth transmission and legal heir compliance blueprint covering nomination, succession, locker access and credit-card estate closure.",
    benefits: ["Succession certificate", "Nominee templates", "Bank-by-bank steps", "Notary-ready format"], poster: FINTECH_POSTERS[3] },
  { id: "f10", category: "fintech", price: P(399, 62, 149),
    title: "Banking Consumer Rights & Fraud Recovery Blueprint",
    shortDesc: "Consumer rights playbook with fraud recovery scripts.",
    longDesc: "A banking consumer rights and fraud recovery blueprint — RBI-aligned escalation matrices, ombudsman templates and chargeback recovery scripts.",
    benefits: ["RBI-aligned escalations", "Ombudsman templates", "Chargeback scripts", "Recovery cadence"], poster: FINTECH_POSTERS[4] },
  { id: "f11", category: "fintech", price: P(499, 70, 149),
    title: "Tax Saving Hacks & Income Leak Blueprint",
    shortDesc: "Legal tax saving hacks plus an income-leak audit.",
    longDesc: "A premium vault of legal tax-saving hacks and an income-leak audit blueprint — section-wise deductions, regime comparison and leakage plug-ins.",
    benefits: ["40+ legal hacks", "Income-leak audit", "Old vs new regime", "CA-vetted templates"], poster: FINTECH_POSTERS[0] },
  { id: "f12", category: "fintech", price: P(399, 62, 149),
    title: "Hidden Insurance Claims & Policy Traps Blueprint",
    shortDesc: "Decode hidden claims and policy traps across insurers.",
    longDesc: "A hidden insurance claims and policy traps blueprint — exclusions decoder, claim-drafting kit and IRDAI escalation templates for health, motor and life.",
    benefits: ["Hidden claim decoder", "Policy trap audit", "IRDAI templates", "Insurer-wise tactics"], poster: FINTECH_POSTERS[1] },
  { id: "f13", category: "fintech", price: P(499, 70, 149),
    title: "Home Loan Foreclosure & Interest Saver Blueprint",
    shortDesc: "Foreclosure math and interest-saver tactics for home loans.",
    longDesc: "A home loan foreclosure and interest-saver blueprint — rate-benchmark sheets, balance-transfer math, prepayment cadence and processing-fee waiver scripts.",
    benefits: ["Foreclosure math", "BT model", "Prepayment cadence", "Fee waiver scripts"], poster: FINTECH_POSTERS[2] },
  { id: "f14", category: "fintech", price: P(299, 66, 99),
    title: "Credit Card Reward Points & Air Miles Blueprint",
    shortDesc: "Decode reward points and air-mile conversions on 40+ cards.",
    longDesc: "A credit card reward points and air miles blueprint — conversion ratios, partner programs and milestone bonuses across 40+ Indian credit cards.",
    benefits: ["40+ card decode", "Air-mile conversions", "Milestone tracker", "Renewal logic"], poster: FINTECH_POSTERS[3] },
  { id: "f15", category: "fintech", price: P(399, 62, 149),
    title: "CIBIL Score Repair Blueprint",
    shortDesc: "Engineered repair workflow to rebuild damaged CIBIL.",
    longDesc: "A CIBIL score repair blueprint with dispute kits, utilisation re-shaping and age-of-credit recovery — built for damaged or stalled bureau profiles.",
    benefits: ["Dispute templates", "Utilisation reshape", "Recovery roadmap", "Monthly tracking"], poster: FINTECH_POSTERS[4] },
  { id: "f16", category: "fintech", price: P(299, 66, 99),
    title: "MSME Subsidy Directory",
    shortDesc: "Directory of MSME subsidies, schemes and eligibility maps.",
    longDesc: "A curated MSME subsidy directory — central and state schemes, eligibility maps, application checklists and disbursement timelines.",
    benefits: ["Central & state schemes", "Eligibility maps", "Application checklist", "Disbursement timeline"], poster: FINTECH_POSTERS[0] },
  { id: "f17", category: "fintech", price: P(499, 70, 149),
    title: "Corporate & Business Banking Mastery Blueprint",
    shortDesc: "Mastery blueprint for corporate and business banking stacks.",
    longDesc: "A corporate and business banking mastery blueprint — current-account selection, cash management, trade finance and treasury optimisation.",
    benefits: ["Current account picks", "Cash management", "Trade finance", "Treasury optimisation"], poster: FINTECH_POSTERS[1] },
  { id: "f18", category: "fintech", price: P(399, 62, 149),
    title: "Crypto & Digital Assets Tax & Profit Booking Guide",
    shortDesc: "Crypto VDA tax and profit-booking framework.",
    longDesc: "A crypto and digital assets tax and profit booking guide — VDA tax math, exchange-side reporting and profit-booking schedules tuned for Indian rules.",
    benefits: ["VDA tax math", "Exchange reporting", "Profit booking schedule", "FY-aligned"], poster: FINTECH_POSTERS[2] },
  { id: "f19", category: "fintech", price: P(499, 70, 149),
    title: "Personal & Business Tax Saving Blueprints",
    shortDesc: "Dual blueprints covering personal and business tax saving.",
    longDesc: "Personal and business tax saving blueprints — section-wise deductions, regime decision frameworks and entity-side optimisation for salaried and SMB founders.",
    benefits: ["Personal optimisation", "Business optimisation", "Entity-side tactics", "CA-vetted"], poster: FINTECH_POSTERS[3] },
  { id: "f20", category: "fintech", price: P(299, 66, 99),
    title: "Settelement Guidence",
    shortDesc: "Negotiation scripts and closure formats for settlements.",
    longDesc: "A settlement guidance pack with negotiation scripts, recovery-agent etiquette rules and bank-side closure letter formats for credit cards and loans.",
    benefits: ["Negotiation scripts", "Closure letter format", "Recovery rights", "Bank-wise tactics"], poster: FINTECH_POSTERS[4] },
  { id: "f21", category: "fintech", price: P(299, 66, 99),
    title: "BASIC AUDIT CHECK",
    shortDesc: "Lightweight self-audit toolkit for small businesses.",
    longDesc: "A basic audit check toolkit with a 60-point checklist and reconciliation worksheets for SMBs preparing for statutory or internal audit.",
    benefits: ["60-point checklist", "Reconciliation sheets", "Audit prep timeline", "SMB-tuned"], poster: FINTECH_POSTERS[0] },
];

// 18 Smart AI Money Hub products — hardcoded master config
const AI_RAW: { title: string; mrp: number; discount: number }[] = [
  { title: "AI SEO MASTERY & GOOGLE RANKING ENGINEERING", mrp: 399, discount: 70 },
  { title: "AI Business Growth Secrets", mrp: 399, discount: 70 },
  { title: "AI Mobile Secrets", mrp: 399, discount: 70 },
  { title: "Content Marketing Mastery & Brand Voice Architecture", mrp: 299, discount: 60 },
  { title: "AI-Driven Email & Automation Marketing", mrp: 299, discount: 60 },
  { title: "AI SMM Mastery & Social Media Automation", mrp: 399, discount: 70 },
  { title: "Faceless YouTube Automation AI Blueprint", mrp: 399, discount: 70 },
  { title: "AI Copywriting High-Converting Sales Content Masterclass", mrp: 399, discount: 70 },
  { title: "AI Digital Logo Making & Premium Branding Agency Secrets", mrp: 399, discount: 70 },
  { title: "AI Blogging & Google AdSense Revenue Engine", mrp: 399, discount: 70 },
  { title: "Faceless Facebook Pages Traffic & Monetization Strategy", mrp: 399, discount: 70 },
  { title: "AI Instagram Theme Pages Growth & Reels Automation Blueprint", mrp: 399, discount: 70 },
  { title: "Advanced ChatGPT Mastery for Personal & Business Scaling", mrp: 399, discount: 70 },
  { title: "AI Website Designing & No-Code High-Converting Landing Pages", mrp: 399, discount: 70 },
  { title: "AI Video Editing & YouTube Growth Money Hacks", mrp: 399, discount: 70 },
  { title: "Global Freelancing Secrets & Dollar Revenue AI Kit", mrp: 399, discount: 70 },
  { title: "AI Financial Management & Smart Wealth Creation Engine", mrp: 399, discount: 70 },
  { title: "AI Social Media & Marketing Revolution Model", mrp: 399, discount: 70 },
];

const AI_ITEMS: CatalogItem[] = AI_RAW.map((r, idx) => ({
  id: `a${idx + 1}`,
  category: "ai",
  title: r.title,
  shortDesc: `${r.title} — autonomous AI blueprint with agentic execution.`,
  longDesc: `${r.title} is a hardcoded Smart AI Money Hub blueprint — agentic playbooks, automation templates and growth math packaged for immediate execution.`,
  benefits: ["Agentic execution", "Automation templates", "Growth math", "PCI-DSS encrypted"],
  poster: AI_POSTERS[idx % AI_POSTERS.length],
  price: P(r.mrp, r.discount, 119),
}));

export function LuxuryCatalog({
  category,
  title,
  subtitle,
  count,
}: {
  category: "fintech" | "ai";
  title: string;
  subtitle: string;
  count: number;
}) {
  const items = useMemo(() => {
    const base = category === "fintech" ? FINTECH : AI_ITEMS;
    return base.slice(0, count);
  }, [category, count]);

  const [open, setOpen] = useState<CatalogItem | null>(null);

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Sparkles className="h-3 w-3" /> Luxury Blueprint Catalog · {items.length} modules
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">{title}</h1>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">{subtitle}</p>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => (
          <CatalogCard key={it.id} item={it} onOpen={() => setOpen(it)} />
        ))}
      </div>

      {open && <BlueprintModal item={open} onClose={() => setOpen(null)} />}
    </section>
  );
}

function PriceTag({ price }: { price: PriceBlock }) {
  if (price.kind === "shield") {
    return (
      <div className="space-y-1.5">
        {price.sub.map((s) => (
          <div key={s.label} className="flex items-center justify-between gap-3 rounded-lg border border-mint/25 bg-slate-deep/60 px-3 py-1.5 text-xs">
            <span className="font-semibold text-foreground/90">{s.label}</span>
            <span className="font-display text-base font-black text-mint">₹{s.price}</span>
          </div>
        ))}
        <div className="flex items-start gap-1.5 pt-1 text-[10px] text-foreground/70">
          <CalendarClock className="mt-0.5 h-3 w-3 text-mint" /> {price.note}
        </div>
      </div>
    );
  }
  return (
    <div>
      <div className="flex items-baseline gap-2">
        <span className="text-xs text-muted-foreground line-through">MRP ₹{price.mrp}</span>
        <span className="inline-flex items-center gap-1 rounded-full bg-burnt/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-burnt">
          <BadgePercent className="h-3 w-3" /> {price.discount}% OFF
        </span>
      </div>
      <div className="font-display text-2xl font-black text-mint">
        ₹{price.intro} <span className="text-xs font-semibold text-foreground/70">+ GST</span>
      </div>
      <div className="text-[10px] uppercase tracking-widest text-foreground/60">Introductory Offer</div>
    </div>
  );
}

function CatalogCard({ item, onOpen }: { item: CatalogItem; onOpen: () => void }) {
  const [playing, setPlaying] = useState(false);
  const tagLabel = item.price.kind === "shield"
    ? "Subscription Module"
    : item.category === "ai" ? "AI Money Blueprint" : "FinTech Blueprint";
  return (
    <article
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-mint/20 shadow-elevated transition hover:-translate-y-1 hover:border-mint hover:shadow-mint"
      style={{
        background:
          "linear-gradient(160deg, color-mix(in oklab, var(--card) 85%, transparent) 0%, color-mix(in oklab, var(--card) 60%, transparent) 100%)",
        backdropFilter: "blur(18px) saturate(140%)",
      }}
    >
      <header className="border-b border-mint/15 p-5">
        <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">{tagLabel}</div>
        <h3 className="mt-1 font-display text-base font-black leading-snug sm:text-lg">{item.title}</h3>
        <p className="mt-1 line-clamp-2 text-xs text-foreground/80">{item.shortDesc}</p>
      </header>

      <div className="relative aspect-video w-full bg-black">
        {playing ? (
          <iframe
            className="absolute inset-0 h-full w-full"
            src="https://www.youtube-nocookie.com/embed/aqz-KE-bpKQ?autoplay=1&mute=1&rel=0"
            title={`${item.title} walkthrough`}
            loading="lazy"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <button
            onClick={() => setPlaying(true)}
            className="press press-on absolute inset-0 grid place-items-center"
            aria-label={`Play ${item.title} walkthrough`}
          >
            <img
              src={item.poster}
              alt=""
              aria-hidden="true"
              loading="lazy"
              decoding="async"
              className="absolute inset-0 h-full w-full object-cover opacity-90 transition group-hover:scale-[1.02]"
              style={{ transform: "translateZ(0)" }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-deep/85 via-slate-deep/20 to-transparent" />
            <div className="relative grid h-16 w-16 place-items-center rounded-full bg-mint text-mint-foreground shadow-mint transition group-hover:scale-110">
              <Play className="h-7 w-7 fill-current" />
            </div>
            <div className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-slate-deep/85 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-mint backdrop-blur">
              ▶ HD Walkthrough
            </div>
          </button>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div className="flex items-start justify-between gap-3">
          <PriceTag price={item.price} />
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-mint/40 bg-mint/10 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
            <ShieldCheck className="h-3 w-3" /> PCI-DSS
          </span>
        </div>

        <button
          onClick={onOpen}
          className="press press-on mt-auto inline-flex items-center justify-center gap-2 rounded-xl gradient-mint px-4 py-3 font-display text-sm font-bold text-primary-foreground shadow-mint"
        >
          <FileText className="h-4 w-4" /> View Blueprint Summary
        </button>
      </div>
    </article>
  );
}

function BlueprintModal({ item, onClose }: { item: CatalogItem; onClose: () => void }) {
  const [checkout, setCheckout] = useState<{ label: string; amount: number } | null>(null);
  const descriptionBullets = [
    item.longDesc,
    ...item.benefits,
    "PCI-DSS bank-grade encryption end-to-end.",
    "Activates instantly after secure onboarding.",
  ];
  return (
    <div
      className="fixed inset-0 z-[120] grid place-items-center bg-slate-deep/85 p-4 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-mint/40 bg-slate-elevated shadow-mint"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close blueprint"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-mint/40 bg-slate-deep/80 text-mint hover:bg-mint hover:text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="max-h-[85vh] overflow-y-auto p-6 sm:p-8">
          <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">Blueprint Summary</div>
          <h3 className="mt-2 font-display text-xl font-black leading-snug sm:text-2xl">{item.title}</h3>

          <ul className="mt-5 space-y-2.5 text-sm leading-relaxed text-foreground/90">
            {descriptionBullets.map((b, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-mint" />
                <span>{b}</span>
              </li>
            ))}
          </ul>

          <div className="mt-6 rounded-2xl border border-mint/25 bg-slate-deep/50 p-5">
            <div className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-mint">
              <Gift className="h-3 w-3" /> Pricing
            </div>
            <div className="mt-3">
              <PriceTag price={item.price} />
            </div>
          </div>

          {item.price.kind === "shield" ? (
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {item.price.sub.map((s) => (
                <button
                  key={s.label}
                  onClick={() => setCheckout({ label: s.label, amount: s.price })}
                  className="press press-on inline-flex items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-display font-bold text-primary-foreground shadow-mint"
                >
                  <CreditCard className="h-4 w-4" /> Subscribe {s.label} · ₹{s.price}
                </button>
              ))}
            </div>
          ) : (
            <button
              onClick={() => setCheckout({ label: item.title, amount: (item.price as Extract<PriceBlock, { kind: "standard" }>).intro })}
              className="press press-on mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-display font-bold text-primary-foreground shadow-mint"
            >
              <CreditCard className="h-4 w-4" /> Proceed to Secure Checkout · ₹{(item.price as Extract<PriceBlock, { kind: "standard" }>).intro} + GST
            </button>
          )}
        </div>
      </div>

      {checkout && (
        <CheckoutGatewayModal
          title={item.title}
          tierLabel={checkout.label}
          amount={checkout.amount}
          onClose={() => setCheckout(null)}
        />
      )}
    </div>
  );
}

function CheckoutGatewayModal({
  title,
  tierLabel,
  amount,
  onClose,
}: {
  title: string;
  tierLabel: string;
  amount: number;
  onClose: () => void;
}) {
  const [card, setCard] = useState("");
  const [exp, setExp] = useState("");
  const [cvv, setCvv] = useState("");
  const [name, setName] = useState("");
  const [processing, setProcessing] = useState(false);

  const formatCard = (v: string) =>
    v.replace(/\D/g, "").slice(0, 16).replace(/(\d{4})(?=\d)/g, "$1 ").trim();
  const formatExp = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
  };

  const valid =
    name.trim().length > 1 &&
    card.replace(/\s/g, "").length === 16 &&
    /^\d{2}\/\d{2}$/.test(exp) &&
    cvv.length === 3;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!valid) {
      toast.error("Please complete every payment field correctly.");
      return;
    }
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      toast.success(`Secure payment of ₹${amount} initiated for ${tierLabel}.`);
      onClose();
    }, 1600);
  };

  return (
    <div
      className="fixed inset-0 z-[130] grid place-items-center bg-slate-deep/90 p-4 backdrop-blur-lg animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md overflow-hidden rounded-3xl border border-mint/50 bg-slate-elevated shadow-mint"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close checkout"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-mint/40 bg-slate-deep/80 text-mint hover:bg-mint hover:text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="p-6 sm:p-7">
          <div className="inline-flex items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
            <Lock className="h-3 w-3" /> Secure Payment Gateway
          </div>
          <h3 className="mt-3 font-display text-lg font-black leading-snug">{title}</h3>
          <p className="mt-1 text-xs text-foreground/70">{tierLabel}</p>
          <div className="mt-3 inline-flex items-baseline gap-2">
            <span className="font-display text-3xl font-black text-mint">₹{amount}</span>
            <span className="text-xs font-semibold text-foreground/70">+ GST</span>
          </div>

          <form onSubmit={submit} className="mt-5 space-y-3">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Cardholder Full Name"
              className="w-full rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2.5 text-sm outline-none focus:border-mint"
            />
            <div className="relative">
              <input
                value={card}
                onChange={(e) => setCard(formatCard(e.target.value))}
                placeholder="1111 2222 3333 4444"
                inputMode="numeric"
                className="w-full rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2.5 pr-10 text-sm tracking-widest outline-none focus:border-mint"
              />
              <CreditCard className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mint" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input
                value={exp}
                onChange={(e) => setExp(formatExp(e.target.value))}
                placeholder="MM/YY"
                inputMode="numeric"
                className="rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2.5 text-sm outline-none focus:border-mint"
              />
              <input
                value={cvv}
                onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                placeholder="CVV"
                inputMode="numeric"
                type="password"
                className="rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2.5 text-sm outline-none focus:border-mint"
              />
            </div>

            <button
              type="submit"
              disabled={processing}
              className="press press-on inline-flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-display text-sm font-bold text-primary-foreground shadow-mint disabled:opacity-60"
            >
              <Lock className="h-4 w-4" />
              {processing ? "Processing Securely…" : `Pay ₹${amount} Now`}
            </button>

            <div className="flex items-center justify-between rounded-xl border border-mint/20 bg-slate-deep/50 px-3 py-2 text-[10px] font-semibold uppercase tracking-widest text-foreground/70">
              <span className="inline-flex items-center gap-1.5"><QrCode className="h-3 w-3 text-mint" /> UPI / QR Available</span>
              <span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-3 w-3 text-mint" /> PCI-DSS</span>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

