import { jsPDF } from "jspdf";
import { FileText, ShieldCheck } from "lucide-react";

type LedgerRow = {
  id: string;
  bank: string;
  last4: string;
  withdrawals: string;
  paid: string;
  statement: string;
  due: string;
};

const ROWS: LedgerRow[] = [
  { id: "r1", bank: "SBI Elite", last4: "8851", withdrawals: "₹1,42,500", paid: "₹85,000", statement: "₹1,18,420", due: "27 Jun 2026" },
  { id: "r2", bank: "HDFC Diners Black", last4: "2204", withdrawals: "₹2,18,900", paid: "₹2,18,900", statement: "₹2,42,110", due: "02 Jul 2026" },
  { id: "r3", bank: "ICICI Sapphiro", last4: "7710", withdrawals: "₹78,300", paid: "₹40,000", statement: "₹84,560", due: "11 Jul 2026" },
  { id: "r4", bank: "Axis Magnus", last4: "3382", withdrawals: "₹3,02,750", paid: "₹1,50,000", statement: "₹3,15,990", due: "18 Jul 2026" },
];

function downloadInvoice(row: LedgerRow) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const now = new Date();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("Smart Pay — Official Tax Invoice", 40, 60);
  doc.setDrawColor(50, 200, 160);
  doc.setLineWidth(1.2);
  doc.line(40, 72, 555, 72);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(`Invoice No: SMP-${Date.now()}`, 40, 96);
  doc.text(`Generated: ${now.toLocaleString("en-IN")}`, 40, 112);
  doc.text("Powered by Smart Fintech Solutions", 40, 128);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Card Statement Summary", 40, 168);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  const lines = [
    ["Masked Bank Card Profile", `${row.bank} — **** ${row.last4}`],
    ["Current Month Withdrawals", row.withdrawals],
    ["Current Month Paid Status", row.paid],
    ["Total Monthly Statement Bill", row.statement],
    ["Official Calendar Due Date", row.due],
    ["Transaction Scope", "FinTech Blueprints / AI Money Hub / Affiliate / Card Payout"],
  ];
  let y = 196;
  lines.forEach(([k, v]) => {
    doc.setFont("helvetica", "bold");
    doc.text(`${k}:`, 40, y);
    doc.setFont("helvetica", "normal");
    doc.text(String(v), 240, y);
    y += 22;
  });

  doc.setDrawColor(180);
  doc.line(40, y + 10, 555, y + 10);
  doc.setFontSize(9);
  doc.setTextColor(110);
  doc.text(
    "Automation Protocol: Auto-generated post-transaction and at month-end midnight cycle.",
    40,
    y + 30,
  );
  doc.text("Dispatched securely via encrypted WhatsApp / Email channels.", 40, y + 44);

  doc.save(`SmartPay-Invoice-${row.bank.replace(/\s+/g, "")}-${row.last4}.pdf`);
}

export function CardLedgerTable() {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-12 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          Unified Credit Card Multi-Ledger
        </div>
        <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">
          Universal Auto-Invoice Matrix
        </h2>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground">
          One consolidated view across every card · Instant PDF invoices for FinTech Blueprints,
          AI Money Hub, Affiliate routing and Credit Card payouts.
        </p>
      </div>

      <div className="mt-6 overflow-hidden rounded-3xl border border-mint/30 bg-slate-elevated shadow-elevated">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead className="bg-slate-deep text-[10px] font-bold uppercase tracking-widest text-mint">
              <tr>
                <th className="px-4 py-3">Masked Card Profile</th>
                <th className="px-4 py-3">Month Withdrawals</th>
                <th className="px-4 py-3">Month Paid</th>
                <th className="px-4 py-3">Statement Bill</th>
                <th className="px-4 py-3">Due Date</th>
                <th className="px-4 py-3 text-right">Invoice</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {ROWS.map((r) => (
                <tr key={r.id} className="hover:bg-slate-deep/40">
                  <td className="px-4 py-3">
                    <div className="font-semibold">{r.bank}</div>
                    <div className="font-mono text-xs text-muted-foreground">**** {r.last4}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">{r.withdrawals}</td>
                  <td className="px-4 py-3 font-mono text-mint">{r.paid}</td>
                  <td className="px-4 py-3 font-mono">{r.statement}</td>
                  <td className="px-4 py-3 font-mono text-burnt">{r.due}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => downloadInvoice(r)}
                      className="press press-on inline-flex items-center gap-1.5 rounded-lg border border-mint/40 bg-mint/10 px-3 py-1.5 text-xs font-bold text-mint hover:bg-mint hover:text-mint-foreground"
                    >
                      <FileText className="h-3.5 w-3.5" /> Download Invoice
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-4 flex items-start gap-2 rounded-2xl border border-mint/40 bg-mint/5 p-4 text-xs leading-relaxed text-foreground/90">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-mint" />
        <span>
          <span className="font-bold text-mint">🔒 Automation Protocol:</span> Full breakdown PDF
          invoices are automatically generated instantly post-transaction and at midnight on every
          month-end cycle, dispatched securely via encrypted WhatsApp / Email channels.
        </span>
      </div>
    </section>
  );
}
