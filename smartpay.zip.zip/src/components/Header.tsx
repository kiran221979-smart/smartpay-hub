import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { MarketTicker } from "./MarketTicker";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/automation", label: "Automation Portal" },
  { to: "/products", label: "Fintech Products" },
  { to: "/ai-hub", label: "AI Money Hub" },
  { to: "/smart-ai-tools", label: "Smart AI Tools" },
  { to: "/smart-alliance-network", label: "Smart Alliance Network" },
  { to: "/alliances", label: "Smart Business Services" },
  { to: "/support", label: "Support" },
] as const;

export function Header() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 backdrop-blur-xl bg-slate-deep/75">
      <div className="mx-auto flex w-full max-w-7xl items-center gap-4 px-4 py-3 sm:px-6 lg:px-10">
        {/* LEFT: brand — locked far-left, never shifts when drawer toggles */}
        <Link to="/" className="press press-on mr-auto flex shrink-0 items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl gradient-mint shadow-mint">
            <span className="font-display text-base font-bold text-primary-foreground">S</span>
          </div>
          <div className="min-w-0 leading-tight">
            <div className="font-display text-sm font-bold sm:text-base">Smart Pay</div>
            <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-mint">Agentic AI</div>
          </div>
        </Link>

        {/* RIGHT: hamburger trigger (all viewports) */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="press press-on inline-flex h-10 shrink-0 items-center justify-center gap-2 self-center rounded-lg border border-mint/40 bg-mint/10 px-3 leading-none text-mint shadow-mint hover:bg-mint/15"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          <span className="hidden text-[11px] font-bold uppercase leading-none tracking-widest sm:inline">Menu</span>
        </button>

      </div>

      {/* Translucent ticker bar */}
      <div className="border-t border-mint/15 bg-slate-deep/40">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-10">
          <MarketTicker />
        </div>
      </div>

      {/* Right-side drawer */}
      {open && (
        <>
          <div
            className="fixed inset-0 z-40 bg-slate-deep/70 backdrop-blur-sm animate-in fade-in duration-200"
            onClick={() => setOpen(false)}
            aria-hidden
          />
          <aside className="fixed right-0 top-0 z-50 flex h-screen min-h-[100dvh] w-[92%] max-w-md flex-col border-l border-mint/30 bg-slate-deep shadow-[0_0_60px_-10px_color-mix(in_oklab,var(--color-mint)_50%,transparent)] animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between border-b border-mint/20 px-5 py-5">
              <div>
                <div className="font-display text-base font-black">Navigation</div>
                <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-mint">Smart Pay · Agentic</div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="press press-on grid h-10 w-10 place-items-center rounded-lg border border-mint/40 bg-mint/10 text-mint"
                aria-label="Close menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex flex-1 flex-col gap-2 overflow-y-auto px-4 py-6">
              {links.map((l, index) => {
                const active = pathname === l.to;
                return (
                  <Link
                    key={l.to}
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className={`press press-on animate-menu-item flex w-full items-center justify-between rounded-xl px-5 py-4 text-base font-bold transition ${
                      active
                        ? "border border-mint/50 bg-mint/10 text-mint shadow-mint"
                        : "border border-transparent text-foreground/85 hover:border-mint/30 hover:bg-secondary"
                    }`}
                    style={{ animationDelay: `${index * 35}ms` }}
                  >
                    <span>{l.label}</span>
                    <span className={`text-[10px] uppercase tracking-widest ${active ? "text-mint" : "text-muted-foreground/60"}`}>
                      {active ? "● Active" : "→"}
                    </span>
                  </Link>
                );
              })}
            </nav>
          </aside>
        </>
      )}
    </header>
  );
}
