import { useEffect, useMemo, useState } from "react";
import { CreditCard, Plus, Trash2, Globe, ShieldCheck, Bell, Wallet } from "lucide-react";

type PayChannel = "smartpay" | "external";
export type ManagedCard = {
  id: string;
  bank: string;
  last4: string;
  holder: string;
  dueDate: string; // YYYY-MM-DD
  amount: number;
  channel: PayChannel;
};

const STORAGE_KEY = "smartpay.managed_cards.v1";

const SEED: ManagedCard[] = [
  { id: "c1", bank: "HDFC Diners Black", last4: "2204", holder: "Ravi Kumar", dueDate: isoOffset(2), amount: 48650, channel: "smartpay" },
  { id: "c2", bank: "ICICI Sapphiro", last4: "7710", holder: "Ravi Kumar", dueDate: isoOffset(4), amount: 19840, channel: "external" },
  { id: "c3", bank: "SBI Elite", last4: "8851", holder: "Ravi Kumar", dueDate: isoOffset(1), amount: 7390, channel: "smartpay" },
  { id: "c4", bank: "Axis Magnus", last4: "3382", holder: "Ravi Kumar", dueDate: isoOffset(5), amount: 92510, channel: "external" },
];

function isoOffset(days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function daysUntil(iso: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const t = new Date(iso);
  t.setHours(0, 0, 0, 0);
  return Math.round((t.getTime() - today.getTime()) / 86400000);
}

const EN = (bank: string, amount: number, d: number) =>
  `🚨 Payment Alert: Your Credit Card Bill ${bank} of ₹${amount.toLocaleString("en-IN")} is due in ${d} day${d === 1 ? "" : "s"}. Please settle via Smart Pay. (If already paid, please ignore this message.)`;
const TE = (bank: string, amount: number, d: number) =>
  `🚨 పేమెంట్ అలర్ట్: మీ ${bank} క్రెడిట్ కార్డ్ బిల్లు ₹${amount.toLocaleString("en-IN")} కట్టడానికి ఇంకా ${d} రోజుల${d === 1 ? "ే" : "ే"} ఉన్నది. దయచేసి Smart Pay ద్వారా మీ బిల్లును చెల్లించండి. (ఒకవేళ మీరు ఆల్రెడీ బిల్లు కట్టేసి ఉంటే, ఈ మెసేజ్‌ను వదిలేయండి).`;

function toneFor(d: number) {
  if (d <= 1) return "border-mint/70 bg-mint/15";
  if (d <= 2) return "border-mint/50 bg-mint/10";
  if (d <= 4) return "border-mint/30 bg-mint/5";
  return "border-border bg-slate-elevated";
}

function AlertRow({ card }: { card: ManagedCard }) {
  const [lang, setLang] = useState<"en" | "te">("en");
  const d = daysUntil(card.dueDate);
  const text = lang === "en" ? EN(card.bank, card.amount, d) : TE(card.bank, card.amount, d);
  const toggleLabel = lang === "en" ? "🌐 Translate to Telugu" : "🌐 Translate to English";
  return (
    <div className={`rounded-xl border p-3.5 ${toneFor(d)}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-widest">
            <span className="rounded-full border border-mint/40 bg-slate-deep px-2 py-0.5 text-mint">
              {card.bank} · **** {card.last4}
            </span>
            <span className="rounded-full border border-border bg-slate-deep px-2 py-0.5 text-foreground/70">
              Due in {d} {d === 1 ? "day" : "days"}
            </span>
            <span className={`rounded-full px-2 py-0.5 ${card.channel === "smartpay" ? "border border-mint/40 bg-mint/10 text-mint" : "border border-burnt/40 bg-burnt/10 text-burnt"}`}>
              {card.channel === "smartpay" ? "Pays via SmartPay" : "External Pay"}
            </span>
          </div>
          <p className="mt-2 text-[12.5px] leading-relaxed text-foreground/90" lang={lang === "te" ? "te" : "en"}>
            {text}
          </p>
        </div>
      </div>
      <button
        onClick={() => setLang((l) => (l === "en" ? "te" : "en"))}
        className="press press-on mt-2 inline-flex items-center gap-1 rounded-md border border-mint/40 bg-slate-deep px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-mint hover:bg-mint/10"
      >
        {toggleLabel}
      </button>
    </div>
  );
}

export function SavedCardVault() {
  const [cards, setCards] = useState<ManagedCard[]>(SEED);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ bank: "", last4: "", amount: "", dueDate: isoOffset(3), channel: "smartpay" as PayChannel });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setCards(JSON.parse(raw));
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cards));
    } catch {}
  }, [cards]);

  const dueSoon = useMemo(
    () => cards.filter((c) => daysUntil(c.dueDate) <= 5 && daysUntil(c.dueDate) >= 1).sort((a, b) => daysUntil(a.dueDate) - daysUntil(b.dueDate)),
    [cards],
  );
  const totalDue = useMemo(() => cards.reduce((s, c) => s + c.amount, 0), [cards]);

  const addCard = () => {
    if (!form.bank || form.last4.length !== 4 || !form.amount) return;
    setCards((cs) => [
      ...cs,
      { id: `c${Date.now()}`, bank: form.bank, last4: form.last4, holder: "Account Holder", dueDate: form.dueDate, amount: Number(form.amount), channel: form.channel },
    ]);
    setForm({ bank: "", last4: "", amount: "", dueDate: isoOffset(3), channel: "smartpay" });
    setAdding(false);
  };

  return (
    <section className="mx-auto mt-12 w-full max-w-7xl px-4 sm:px-6">
      {/* VAULT */}
      <div className="rounded-3xl border-2 border-mint/50 bg-slate-elevated p-6 shadow-elevated">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-mint">
            <Wallet className="h-5 w-5" />
            <div>
              <div className="font-display text-lg font-black">Saved Vault · Manage My Cards</div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-mint/80">
                Tracks every saved card — SmartPay or External billing
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <span className="rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 font-bold uppercase tracking-widest text-mint">
              {cards.length} Cards Tracked
            </span>
            <span className="rounded-full border border-burnt/40 bg-burnt/10 px-2.5 py-1 font-bold uppercase tracking-widest text-burnt">
              ₹{totalDue.toLocaleString("en-IN")} Outstanding
            </span>
            <button
              onClick={() => setAdding((a) => !a)}
              className="press press-on inline-flex items-center gap-1 rounded-full gradient-mint px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-primary-foreground shadow-mint"
            >
              <Plus className="h-3.5 w-3.5" /> Add Card
            </button>
          </div>
        </div>

        <div className="mt-4 flex items-start gap-2 rounded-xl border border-mint/30 bg-mint/[0.06] px-3.5 py-2.5 text-[12px] leading-relaxed text-foreground/90">
          <Bell className="mt-0.5 h-4 w-4 shrink-0 text-mint" />
          <p>
            <span className="font-bold text-mint">ℹ️ Manage ALL your Credit Cards centrally.</span>{" "}
            To activate automated <span className="font-semibold text-mint">5, 4, 3, 2, 1-day</span> decrementing alerts,
            kindly add ALL your card details and due dates here, whether you settle via Smart Pay or externally.
          </p>
        </div>


        {adding && (
          <div className="mt-4 grid gap-2 rounded-2xl border border-mint/40 bg-slate-deep p-4 sm:grid-cols-5">
            <input className="input sm:col-span-2" placeholder="Bank / Card Name" value={form.bank} onChange={(e) => setForm({ ...form, bank: e.target.value })} />
            <input className="input" placeholder="Last 4" maxLength={4} value={form.last4} onChange={(e) => setForm({ ...form, last4: e.target.value.replace(/\D/g, "").slice(0, 4) })} />
            <input className="input" placeholder="Bill ₹" inputMode="numeric" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value.replace(/\D/g, "") })} />
            <input className="input" type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
            <select className="input sm:col-span-2" value={form.channel} onChange={(e) => setForm({ ...form, channel: e.target.value as PayChannel })}>
              <option value="smartpay">Pays via SmartPay</option>
              <option value="external">External Pay (we still alert)</option>
            </select>
            <button onClick={addCard} className="press press-on rounded-xl gradient-mint py-2 text-sm font-bold text-primary-foreground shadow-mint sm:col-span-3">
              Save to Vault
            </button>
          </div>
        )}

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => {
            const d = daysUntil(c.dueDate);
            return (
              <div key={c.id} className="group relative rounded-2xl border border-mint/30 bg-slate-deep p-4 transition hover:border-mint">
                <button
                  onClick={() => setCards((cs) => cs.filter((x) => x.id !== c.id))}
                  className="press absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-full border border-border bg-slate-elevated text-muted-foreground opacity-0 transition group-hover:opacity-100 hover:text-red-400"
                  aria-label="Remove card"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
                <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-mint">
                  <CreditCard className="h-3.5 w-3.5" /> {c.bank}
                </div>
                <div className="mt-2 font-mono text-sm tracking-widest text-foreground/80">
                  •••• •••• •••• {c.last4}
                </div>
                <div className="mt-3 flex items-end justify-between">
                  <div>
                    <div className="text-[9px] uppercase tracking-widest text-muted-foreground">Bill Amount</div>
                    <div className="font-display text-lg font-black">₹{c.amount.toLocaleString("en-IN")}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] uppercase tracking-widest text-muted-foreground">Due In</div>
                    <div className={`font-display text-lg font-black ${d <= 2 ? "text-mint" : d <= 4 ? "text-mint/80" : "text-mint/60"}`}>
                      {d}d
                    </div>
                  </div>
                </div>
                <div className={`mt-3 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest ${c.channel === "smartpay" ? "border border-mint/40 bg-mint/10 text-mint" : "border border-burnt/40 bg-burnt/10 text-burnt"}`}>
                  <Globe className="h-3 w-3" /> {c.channel === "smartpay" ? "SmartPay Channel" : "External Payer"}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ALERT ENGINE */}
      <div className="mt-6 rounded-3xl border-2 border-mint/40 bg-slate-deep p-6 shadow-elevated">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-mint">
            <Bell className="h-5 w-5 animate-pulse" />
            <div>
              <div className="font-display text-lg font-black">Multi-Card Alert Engine · 5-Day Decrementing Notifier</div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-mint/80">
                Auto-scans every saved card · WhatsApp · SMS · Email · Push
              </div>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
            <ShieldCheck className="h-3 w-3" /> {dueSoon.length} Alerts Armed
          </span>
        </div>

        {dueSoon.length === 0 ? (
          <div className="mt-4 rounded-xl border border-border bg-slate-elevated p-4 text-center text-xs text-muted-foreground">
            No cards due in the next 5 days. You're clear.
          </div>
        ) : (
          <div className="mt-4 grid gap-2.5">
            {dueSoon.map((c) => (
              <AlertRow key={c.id} card={c} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
