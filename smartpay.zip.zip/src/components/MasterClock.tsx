import { useEffect, useState } from "react";
import { Cpu, ShieldCheck, Zap, Activity, Gauge, Waves, Radio } from "lucide-react";

function useTicker(initial: number, range: [number, number], step: number, interval = 900) {
  const [v, setV] = useState(initial);
  useEffect(() => {
    const id = window.setInterval(() => {
      setV((prev) => {
        const delta = (Math.random() * 2 - 1) * step;
        let next = prev + delta;
        if (next < range[0]) next = range[0] + Math.random() * step;
        if (next > range[1]) next = range[1] - Math.random() * step;
        return Number(next.toFixed(2));
      });
    }, interval);
    return () => window.clearInterval(id);
  }, [range, step, interval]);
  return v;
}

function Spark() {
  const [points, setPoints] = useState<number[]>(
    Array.from({ length: 28 }, () => 30 + Math.random() * 40),
  );
  useEffect(() => {
    const id = window.setInterval(() => {
      setPoints((p) => [...p.slice(1), 20 + Math.random() * 60]);
    }, 320);
    return () => window.clearInterval(id);
  }, []);
  const w = 200,
    h = 56;
  const step = w / (points.length - 1);
  const path = points
    .map((y, i) => `${i === 0 ? "M" : "L"} ${(i * step).toFixed(1)} ${(h - y).toFixed(1)}`)
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-14 w-full">
      <defs>
        <linearGradient id="spkFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--color-mint)" stopOpacity="0.45" />
          <stop offset="100%" stopColor="var(--color-mint)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${path} L ${w} ${h} L 0 ${h} Z`} fill="url(#spkFill)" />
      <path d={path} fill="none" stroke="var(--color-mint)" strokeWidth="1.6" />
    </svg>
  );
}

export function MasterClock() {
  const load = useTicker(62.4, [38, 88], 6, 700);
  const throughput = useTicker(8420, [6200, 11800], 480, 850);
  const latency = useTicker(41, [28, 58], 5, 900);
  const nodes = useTicker(184, [140, 220], 7, 1100);
  const queue = useTicker(312, [180, 540], 32, 800);
  const trust = useTicker(99.42, [98.6, 99.95], 0.18, 1000);

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Cpu className="h-3 w-3" /> Agentic Payout Matrix Core · Live
        </div>
        <h2 className="mt-3 font-display text-3xl font-black sm:text-4xl">
          The <span className="text-mint">Neural Core</span> behind India's 45-Second Payout Grid
        </h2>
      </div>

      <div
        className="relative mt-10 overflow-hidden rounded-[2rem] border-2 border-mint/50 bg-slate-deep p-6 sm:p-10"
        style={{
          boxShadow:
            "0 0 60px -12px color-mix(in oklab, var(--color-mint) 55%, transparent), inset 0 0 60px -25px color-mix(in oklab, var(--color-mint) 50%, transparent)",
        }}
      >
        <style>{`
          @keyframes mtxScan { 0%{transform:translateY(-100%)} 100%{transform:translateY(100%)} }
          @keyframes mtxGlow { 0%,100%{opacity:.7} 50%{opacity:1} }
          @keyframes mtxRing { 0%{transform:rotate(0)} 100%{transform:rotate(360deg)} }
          @keyframes mtxRingRev { 0%{transform:rotate(0)} 100%{transform:rotate(-360deg)} }
          @keyframes mtxBar { 0%,100%{transform:scaleY(.35)} 50%{transform:scaleY(1)} }
          @keyframes mtxFlicker { 0%,92%,100%{opacity:1} 95%{opacity:.4} }
          .mtx-scan { animation: mtxScan 4.5s linear infinite; }
          .mtx-glow { animation: mtxGlow 2.4s ease-in-out infinite; }
          .mtx-ring { animation: mtxRing 18s linear infinite; transform-origin:center; }
          .mtx-ring-rev { animation: mtxRingRev 26s linear infinite; transform-origin:center; }
          .mtx-bar { animation: mtxBar 1.1s ease-in-out infinite; transform-origin:bottom; }
          .mtx-flicker { animation: mtxFlicker 3.4s ease-in-out infinite; }
        `}</style>

        <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(var(--color-mint) 1px, transparent 1px), linear-gradient(90deg, var(--color-mint) 1px, transparent 1px)",
            backgroundSize: "34px 34px",
          }}
        />
        <div
          className="mtx-scan pointer-events-none absolute left-0 right-0 h-24"
          style={{
            background:
              "linear-gradient(to bottom, transparent, color-mix(in oklab, var(--color-mint) 22%, transparent), transparent)",
          }}
        />

        <div className="relative grid grid-cols-1 items-stretch gap-6 lg:grid-cols-[1fr_1.1fr_1fr]">
          {/* LEFT: live metrics */}
          <div className="grid content-center gap-4">
            {[
              { icon: Gauge, k: "Processing Load", v: `${load.toFixed(1)}%`, hint: "Adaptive AI" },
              { icon: Activity, k: "Throughput", v: `${Math.round(throughput).toLocaleString("en-IN")} tps`, hint: "Live" },
              { icon: Waves, k: "P95 Latency", v: `${Math.round(latency)} ms`, hint: "Sub-45s SLA" },
            ].map(({ icon: Icon, k, v, hint }) => (
              <div
                key={k}
                className="rounded-2xl border border-mint/30 bg-slate-elevated/70 p-3 backdrop-blur"
              >
                <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-mint">
                  <span className="inline-flex items-center gap-1.5">
                    <Icon className="h-3 w-3" /> {k}
                  </span>
                  <span className="rounded-full border border-mint/30 px-1.5 py-px text-[9px]">
                    {hint}
                  </span>
                </div>
                <div className="mt-1 flex items-end justify-between gap-3">
                  <div className="mtx-flicker font-display text-2xl font-black tabular-nums text-mint">
                    {v}
                  </div>
                  <div className="flex h-8 items-end gap-[3px]">
                    {Array.from({ length: 12 }).map((_, i) => (
                      <span
                        key={i}
                        className="mtx-bar block w-[3px] rounded-sm bg-mint/80"
                        style={{ height: "100%", animationDelay: `${(i % 6) * 0.12}s` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* CENTER: Core ring */}
          <div className="relative grid place-items-center">
            <div className="relative h-[320px] w-[320px] sm:h-[360px] sm:w-[360px]">
              <svg viewBox="0 0 360 360" className="absolute inset-0">
                <defs>
                  <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="var(--color-mint)" stopOpacity="0.35" />
                    <stop offset="70%" stopColor="var(--color-mint)" stopOpacity="0.05" />
                    <stop offset="100%" stopColor="transparent" />
                  </radialGradient>
                </defs>
                <circle cx="180" cy="180" r="160" fill="url(#coreGlow)" />
                <g className="mtx-ring">
                  <circle cx="180" cy="180" r="148" fill="none" stroke="color-mix(in oklab, var(--color-mint) 35%, transparent)" strokeWidth="1" strokeDasharray="2 8" />
                </g>
                <g className="mtx-ring-rev">
                  <circle cx="180" cy="180" r="126" fill="none" stroke="color-mix(in oklab, var(--color-mint) 50%, transparent)" strokeWidth="1.4" strokeDasharray="14 6" />
                </g>
                <g className="mtx-ring">
                  <circle cx="180" cy="180" r="104" fill="none" stroke="color-mix(in oklab, var(--color-mint) 70%, transparent)" strokeWidth="2" strokeDasharray="40 12 6 12" />
                </g>
                <circle cx="180" cy="180" r="82" fill="#000" opacity="0.65" />
                <circle cx="180" cy="180" r="82" fill="none" stroke="var(--color-mint)" strokeWidth="2"
                  style={{ filter: "drop-shadow(0 0 10px var(--color-mint))" }} />
                {/* tick marks */}
                {Array.from({ length: 24 }).map((_, i) => {
                  const a = (i * 360) / 24;
                  const r1 = 88;
                  const r2 = i % 6 === 0 ? 98 : 93;
                  const x1 = 180 + r1 * Math.cos((a * Math.PI) / 180);
                  const y1 = 180 + r1 * Math.sin((a * Math.PI) / 180);
                  const x2 = 180 + r2 * Math.cos((a * Math.PI) / 180);
                  const y2 = 180 + r2 * Math.sin((a * Math.PI) / 180);
                  return (
                    <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                      stroke="var(--color-mint)" strokeWidth={i % 6 === 0 ? 1.6 : 0.8}
                      opacity={i % 6 === 0 ? 0.9 : 0.5} />
                  );
                })}
              </svg>

              <div className="absolute inset-0 grid place-items-center text-center">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-[0.35em] text-mint/80">
                    Agentic Core
                  </div>
                  <div className="mtx-glow mt-1 font-display text-5xl font-black tabular-nums text-mint sm:text-6xl"
                    style={{ textShadow: "0 0 18px color-mix(in oklab, var(--color-mint) 75%, transparent)" }}>
                    {load.toFixed(1)}<span className="text-2xl">%</span>
                  </div>
                  <div className="mt-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                    Neural Load
                  </div>
                  <div className="mx-auto mt-3 h-px w-24 bg-mint/40" />
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
                    <Zap className="h-3 w-3" /> 45s SLA · Online
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: live metrics */}
          <div className="grid content-center gap-4">
            {[
              { icon: Radio, k: "Active Nodes", v: `${Math.round(nodes)}`, hint: "Mesh" },
              { icon: Activity, k: "Queue Depth", v: `${Math.round(queue)}`, hint: "Drain · 0.4s" },
              { icon: ShieldCheck, k: "Trust Score", v: `${trust.toFixed(2)}%`, hint: "PCI-DSS" },
            ].map(({ icon: Icon, k, v, hint }) => (
              <div
                key={k}
                className="rounded-2xl border border-mint/30 bg-slate-elevated/70 p-3 backdrop-blur"
              >
                <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-mint">
                  <span className="inline-flex items-center gap-1.5">
                    <Icon className="h-3 w-3" /> {k}
                  </span>
                  <span className="rounded-full border border-mint/30 px-1.5 py-px text-[9px]">
                    {hint}
                  </span>
                </div>
                <div className="mt-1 flex items-end justify-between gap-3">
                  <div className="mtx-flicker font-display text-2xl font-black tabular-nums text-mint">
                    {v}
                  </div>
                  <Spark />
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="relative mx-auto mt-10 max-w-4xl text-center text-sm leading-7 text-foreground/90 sm:text-base sm:leading-8">
          ⚡ <span className="font-bold text-mint">Experience India's first fully automated, military-grade secure card processing channel.</span>{" "}
          Zero manual delays, absolute privacy, and instant payouts settled directly into your account in under 45 seconds.
        </p>
      </div>
    </section>
  );
}
