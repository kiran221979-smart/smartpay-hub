import { useEffect, useState, type ReactNode } from "react";
import { X } from "lucide-react";

type Pair = { en: ReactNode; te: ReactNode };
type Section = { heading?: string; subheading?: string; pairs: Pair[] };

export type LegalDoc = {
  emoji: string;
  title: string;
  titleTe: string;
  effective?: string;
  sections: Section[];
};

export const PRIVACY_DOC: LegalDoc = {
  emoji: "📄",
  title: "Privacy Policy",
  titleTe: "ప్రైవసీ పాలసీ",
  effective: "Effective Date: June 14, 2026",
  sections: [
    {
      pairs: [
        {
          en: "Welcome to Smart Pay (incorporating Smart Fintech Products and Smart AI Money Hub). We are committed to protecting your personal data and ensuring 100% financial confidentiality.",
          te: "Smart Pay (Smart Fintech Products మరియు Smart AI Money Hub తో కూడినది) కు స్వాగతం. మీ వ్యక్తిగత డేటాను రక్షించడానికి మరియు 100% ఆర్థిక గోప్యతను నిర్వహించడానికి మేము కట్టుబడి ఉన్నాము.",
        },
      ],
    },
    {
      heading: "1. Information We Collect",
      subheading: "మేము సేకరించే సమాచారం",
      pairs: [
        {
          en: "Personal Identifiers: Name, Email Address, and Phone Number captured during secure account registration.",
          te: "వ్యక్తిగత గుర్తింపులు: ఖాతా రిజిస్ట్రేషన్ సమయంలో పేరు, ఈమెయిల్ ఐడి మరియు ఫోన్ నంబర్.",
        },
        {
          en: "Transaction Data: Encrypted routing parameters only. We never store full card numbers or CVVs — every operation runs on bank-grade encrypted tokens.",
          te: "లావాదేవీల డేటా: ఎన్‌క్రిప్ట్ చేయబడిన రూటింగ్ డేటా మాత్రమే. మేము మీ పూర్తి కార్డ్ నంబర్లు లేదా CVV లను ఎప్పటికీ సేవ్ చేయము.",
        },
      ],
    },
    {
      heading: "2. Data Protection & Security",
      subheading: "డేటా రక్షణ & భద్రత",
      pairs: [
        {
          en: "We utilize state-of-the-art PCI-DSS compliant bank-grade encryption frameworks. Every server token exchange is structured under advanced confidentiality layers.",
          te: "మేము అత్యాధునిక PCI-DSS కంప్లైంట్ బ్యాంక్-గ్రేడ్ ఎన్‌క్రిప్షన్ ఫ్రేమ్‌వర్క్‌లను ఉపయోగిస్తాము. మీ డ్యాష్‌బోర్డ్ మరియు మా నెట్‌వర్క్ రూటింగ్ సర్వర్‌ల మధ్య జరిగే ప్రతి కమ్యూనికేషన్ పూర్తిగా లాక్ చేయబడి సురక్షితంగా ఉంచబడుతుంది.",
        },
      ],
    },
    {
      heading: "3. Third-Party Sharing",
      subheading: "థర్డ్-పార్టీ షేరింగ్",
      pairs: [
        {
          en: "Smart Pay never sells or shares personal data with third-party marketers. Limited data is shared only with regulated banking partners strictly to complete settlements you initiate.",
          te: "Smart Pay మీ వ్యక్తిగత డేటాను థర్డ్-పార్టీ మార్కెటర్‌లకు ఎప్పటికీ అమ్మదు లేదా పంచుకోదు. మీరు ప్రారంభించిన సెటిల్‌మెంట్‌లను పూర్తి చేయడానికి మాత్రమే నియంత్రిత బ్యాంకింగ్ భాగస్వాములతో పరిమిత డేటా పంచుకోబడుతుంది.",
        },
      ],
    },
  ],
};

export const REFUND_DOC: LegalDoc = {
  emoji: "💳",
  title: "Refund & Cancellation Policy",
  titleTe: "రిఫండ్ & క్యాన్సిలేషన్ పాలసీ",
  effective: "Effective Date: June 14, 2026",
  sections: [
    {
      pairs: [
        {
          en: "Thank you for choosing Smart Pay. Please review our refund guidelines thoroughly before finalizing any gateway purchase.",
          te: "Smart Pay ని ఎంచుకున్నందుకు ధన్యవాదాలు. ఏదైనా పేమెంట్ చేసే ముందు దయచేసి మా రిఫండ్ నిబంధనలను జాగ్రత్తగా చదవండి.",
        },
      ],
    },
    {
      heading: "1. Digital Products Marketplace",
      subheading: "డిజిటల్ ప్రొడక్ట్స్ మార్కెట్‌ప్లేస్",
      pairs: [
        {
          en: "Zero-Refund Policy: All Smart AI Money Hub products (Cinematic Magazines, Prompt Libraries, Masterclass Blueprints) are instantly downloadable digital assets and are deemed permanently consumed upon delivery. We maintain a strict NO REFUNDS, NO RETURNS, NO EXCHANGES policy.",
          te: "జీరో-రిఫండ్ పాలసీ: Smart AI Money Hub లోపల ఉండే ప్రొడక్ట్స్ అన్నీ ఇన్‌స్టంట్‌గా డౌన్‌లోడ్ చేసుకునే డిజిటల్ అసెట్స్ కావడం వల్ల, పేమెంట్ విజయవంతం కాగానే అవి కస్టమర్‌కు అందినట్లుగా పరిగణించబడుతుంది. ఎట్టి పరిస్థితుల్లోనూ రిఫండ్లు, రిటర్న్లు లేదా ఎక్స్ఛేంజ్‌లు ఇవ్వబడవు.",
        },
      ],
    },
    {
      heading: "2. Failed Gateway Routing Recoveries",
      subheading: "విఫలమైన లావాదేవీల రికవరీ",
      pairs: [
        {
          en: "If an automated micro-settlement experiences upstream banking network drops, funds are intercepted by our autonomous recovery loop and auto-reversed to the source credit card within 2 to 5 standard banking business days.",
          te: "బ్యాంకింగ్ సర్వర్ల డౌన్‌టైమ్ కారణంగా ఏదైనా ఆటోమేటెడ్ మైక్రో-సెటిల్‌మెంట్ విఫలమైతే, ఆ అమౌంట్ మా అటానమస్ రికవరీ లూప్ ద్వారా సురక్షితంగా నిలిపివేయబడి, 2 నుండి 5 బ్యాంకింగ్ పని దినాలలో కస్టమర్ యొక్క అసలు క్రెడిట్ కార్డ్ ఖాతాకే ఆటోమేటిక్‌గా రీవర్స్ చేయబడుతుంది.",
        },
      ],
    },
    {
      heading: "3. Customer Dispute Resolution",
      subheading: "కస్టమర్ వివాద పరిష్కారం",
      pairs: [
        {
          en: "If a customer is charged but a digital product is not delivered due to a network glitch, our Autonomous Fraud & Recovery Engine instantly audits the ledger. If verified, the system force-delivers the product or initiates a complete refund to the user's wallet within 24 hours.",
          te: "ఒక కస్టమర్‌కు చార్జీ అయినా ప్రొడక్ట్ డెలివర్ కాకపోతే, మా అటానమస్ ఫ్రాడ్ & రికవరీ ఇంజిన్ లెడ్జర్‌ను తక్షణమే ఆడిట్ చేస్తుంది. ధృవీకరణ తర్వాత, సిస్టమ్ ప్రొడక్ట్‌ను బలవంతంగా డెలివర్ చేస్తుంది లేదా 24 గంటల్లో పూర్తి రిఫండ్ ప్రాసెస్ చేస్తుంది.",
        },
      ],
    },
  ],
};

export function LegalModal({ doc, onClose }: { doc: LegalDoc; onClose: () => void }) {
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6">
      <div
        className="absolute inset-0 bg-slate-deep/70 backdrop-blur-xl"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl border border-mint/30 bg-slate-elevated/80 shadow-elevated backdrop-blur-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-mint/20 px-6 py-5 sm:px-10 sm:py-7">
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-mint">
              Official Legal Document
            </p>
            <h2 className="mt-2 truncate font-display text-3xl font-black tracking-tight sm:text-4xl">
              {doc.emoji} {doc.title}
            </h2>
            <p className="mt-1 text-base font-medium text-muted-foreground">({doc.titleTe})</p>
            {doc.effective && (
              <p className="mt-2 text-xs text-muted-foreground">{doc.effective}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="press press-on grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border bg-slate-deep/60 hover:border-mint"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </header>
        <div className="space-y-7 overflow-y-auto px-6 py-7 sm:px-10 sm:py-9">
          {doc.sections.map((s, i) => (
            <section key={i} className="space-y-4">
              {s.heading && (
                <h3 className="font-display text-xl font-bold text-mint sm:text-2xl">
                  {s.heading}
                  {s.subheading && (
                    <span className="ml-2 block text-sm font-medium text-muted-foreground sm:inline">
                      ({s.subheading})
                    </span>
                  )}
                </h3>
              )}
              {s.pairs.map((p, j) => (
                <div key={j} className="space-y-2">
                  <p className="text-[15px] leading-relaxed text-foreground/95">{p.en}</p>
                  <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/50 p-3 text-[14px] leading-relaxed text-muted-foreground">
                    {p.te}
                  </p>
                </div>
              ))}
            </section>
          ))}
        </div>
        <footer className="border-t border-mint/20 bg-slate-deep/40 px-6 py-4 text-center text-[11px] uppercase tracking-widest text-muted-foreground sm:px-10">
          🛡️ PCI-DSS Bank-Grade Encryption · © 2026 Smart Pay
        </footer>
      </div>
    </div>
  );
}

export function useLegalModal() {
  const [doc, setDoc] = useState<LegalDoc | null>(null);
  return {
    open: (d: LegalDoc) => setDoc(d),
    close: () => setDoc(null),
    node: doc ? <LegalModal doc={doc} onClose={() => setDoc(null)} /> : null,
  };
}
