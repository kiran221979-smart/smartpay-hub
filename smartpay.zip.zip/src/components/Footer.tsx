import { Link } from "@tanstack/react-router";
import { useLegalModal, PRIVACY_DOC, REFUND_DOC } from "./LegalModal";
import { SupportBanner } from "./SupportBanner";

export function Footer() {
  const legal = useLegalModal();

  return (
    <footer className="mt-24 border-t border-border/60 bg-slate-deep">
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-6 py-12 md:grid-cols-4 lg:px-10">
        <div>
          <div className="font-display text-lg font-bold">Smart Pay</div>
          <p className="mt-2 text-sm text-muted-foreground">
            India's first fully autonomous Agentic AI Payout System delivering credit-to-bank
            settlements in under 45 seconds.
          </p>
        </div>
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-mint">Platform</div>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/services" className="press press-on inline-block hover:text-mint">Services</Link></li>
            <li><Link to="/automation" className="press press-on inline-block hover:text-mint">Automation Portal</Link></li>
            <li><Link to="/products" className="press press-on inline-block hover:text-mint">FinTech Products</Link></li>
            <li><Link to="/ai-hub" className="press press-on inline-block hover:text-mint">AI Money Hub</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-mint">Company</div>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/about" className="press press-on inline-block hover:text-mint">About Us</Link></li>
            <li><Link to="/support" className="press press-on inline-block hover:text-mint">Customer Support</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-mint">Legal</div>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <button
                onClick={() => legal.open(PRIVACY_DOC)}
                className="press press-on inline-block text-left hover:text-mint"
              >
                Privacy Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => legal.open(REFUND_DOC)}
                className="press press-on inline-block text-left hover:text-mint"
              >
                Refund Policy
              </button>
            </li>
            <li><Link to="/disclaimer" className="press press-on inline-block hover:text-mint">Disclaimers</Link></li>
          </ul>
        </div>
      </div>
      <SupportBanner />
      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © 2026 Smart Pay. All Rights Reserved. · Privacy Policy · Refund Policy · Disclaimers ·
        Withdrawal: 24/7 Support · Bill Pay: 09:00 AM – 09:00 PM
      </div>
      <div className="border-t border-mint/20 bg-slate-deep py-4 text-center">
        <span
          className="font-display text-sm font-black uppercase tracking-[0.35em]"
          style={{
            backgroundImage:
              "linear-gradient(92deg,#c8d4dc 0%,#ffffff 25%,#7fe3c4 50%,#ffffff 75%,#c8d4dc 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
            textShadow: "0 0 18px color-mix(in oklab, var(--color-mint) 25%, transparent)",
          }}
        >
          Powered by Smart Fintech Solutions
        </span>
      </div>
      {legal.node}
    </footer>
  );
}
