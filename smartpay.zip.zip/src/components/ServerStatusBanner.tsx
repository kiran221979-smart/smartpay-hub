import { AlertTriangle } from "lucide-react";
import { useAdmin } from "@/lib/admin-store";

export function ServerStatusBanner() {
  const { serverDown } = useAdmin();
  if (!serverDown) return null;
  return (
    <div className="sticky top-[64px] z-30 animate-blink-warn border-y-2 border-burnt bg-burnt/95 text-burnt-foreground">
      <div className="mx-auto flex max-w-7xl items-start gap-3 px-4 py-3 sm:px-6">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
        <p className="text-sm font-semibold leading-snug">
          ⚠️ We apologize! Bank servers are currently busy. For your financial security, this service is temporarily paused. Please try again after a few moments.
        </p>
      </div>
    </div>
  );
}

export function ServerDownGate({ children }: { children: React.ReactNode }) {
  const { serverDown } = useAdmin();
  if (serverDown) {
    return (
      <div className="rounded-2xl border-2 border-burnt bg-burnt/10 p-6 text-center animate-blink-warn">
        <AlertTriangle className="mx-auto h-8 w-8 text-burnt" />
        <p className="mt-3 text-sm font-semibold text-burnt">
          ⚠️ Bank servers are currently busy. This form is temporarily paused for your financial security. Please try again shortly.
        </p>
      </div>
    );
  }
  return <>{children}</>;
}
