import { useState } from "react";
import { Sparkles } from "lucide-react";
import { useAdmin } from "@/lib/admin-store";

type Filter = "all" | "fintech" | "ai";

export function DigitalMoneyHub() {
  const { products } = useAdmin();
  const [filter, setFilter] = useState<Filter>("all");

  const items = products.filter((p) => filter === "all" || p.category === filter);
  const filters: { id: Filter; label: string }[] = [
    { id: "all", label: "All Bundles" },
    { id: "fintech", label: "Fintech Blueprints" },
    { id: "ai", label: "AI Money Hub" },
  ];



  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-10">
      <div className="mx-auto max-w-3xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Sparkles className="h-3 w-3" /> Unified Marketplace
        </div>
        <h2 className="mt-4 font-display text-3xl font-black tracking-tight sm:text-4xl">
          SMART DIGITAL MONEY HUB
          <span className="block text-mint">— Launch-Edition Bundles —</span>
        </h2>
        <p className="mt-3 text-sm text-muted-foreground sm:text-base">
          Smart Fintech Blueprints + Smart AI Money Hub Cinematic Magazines — unified in
          one centralized launch grid.
        </p>
      </div>

      <div className="mx-auto mt-7 flex max-w-md items-center justify-center gap-1 rounded-full border border-border bg-slate-elevated p-1">
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`press press-on flex-1 rounded-full px-3 py-2 text-[11px] font-bold uppercase tracking-wider transition ${
              filter === f.id
                ? "bg-mint text-mint-foreground shadow-mint"
                : "text-foreground/70 hover:text-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <div
            key={p.id}
            className="flex h-48 flex-col items-center justify-center rounded-3xl border border-dashed border-mint/25 bg-slate-elevated/40 p-6 text-center"
          >
            <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint/70">
              {p.category === "ai" ? "AI" : "FINTECH"} · Slot Ready
            </div>
            <div className="mt-2 font-display text-sm font-semibold text-foreground/60">
              Product grid placeholder
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">Awaiting structural routing</div>
          </div>
        ))}
      </div>

      {/* SmartLifelong Gift — Xerox & Binding */}
      <div className="mx-auto mt-14 max-w-4xl rounded-3xl border border-mint/30 bg-slate-elevated/60 p-6 text-center backdrop-blur sm:p-8">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
          📑 SmartLifelong Gift
        </div>
        <h3 className="mt-3 font-display text-2xl font-black sm:text-3xl">
          Xerox &amp; Binding Instructions
        </h3>
        <div className="mt-5 grid gap-4 text-left sm:grid-cols-2">
          <p className="rounded-xl border border-border bg-slate-deep/50 p-4 text-sm leading-relaxed text-foreground/90">
            After downloading any Smart Fintech Blueprint or AI Cinematic Magazine, take a clean
            Xerox print at any local print center and ask for premium spiral binding to preserve it
            as your lifelong reference guide.
          </p>
          <p className="rounded-xl border border-mint/40 bg-slate-deep/50 p-4 text-sm leading-relaxed text-muted-foreground">
            ఏదైనా Smart Fintech Blueprint లేదా AI Cinematic Magazine డౌన్‌లోడ్ చేసిన తర్వాత, దగ్గర
            ఉన్న జిరాక్స్ సెంటర్‌లో శుభ్రమైన ప్రింట్ తీయించుకొని ప్రీమియం స్పైరల్ బైండింగ్
            చేయించుకోండి — జీవితకాల రిఫరెన్స్ గైడ్‌గా భద్రపరుచుకోండి.
          </p>
        </div>
      </div>

    </section>
  );
}
