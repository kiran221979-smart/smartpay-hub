const tickerContent = (
  <>
    <span>⚡ <strong className="ticker-highlight">FAST-AI ROUTING</strong></span>
    <span className="ticker-sep">|</span>
    <span>⏱️ <strong className="ticker-highlight">45-SECOND</strong> SETTLEMENTS</span>
    <span className="ticker-sep">|</span>
    <span>🌐 <strong className="ticker-highlight">194+</strong> BANKING CHANNELS</span>
    <span className="ticker-sep">|</span>
    <span>💰 <strong className="ticker-highlight">₹4 Cr+</strong> SECURED PAYOUTS</span>
    <span className="ticker-sep">|</span>
    <span>🛡️ PCI-DSS <strong className="ticker-highlight">ENCRYPTED</strong></span>
    <span className="ticker-sep">|</span>
    <span>📊 <strong className="ticker-highlight">14,250+</strong> ACTIVE CUSTOMERS</span>
    <span className="ticker-sep">|</span>
  </>
);

export function MarketTicker() {
  return (
    <div className="market-ticker" aria-label="Smart Pay platform highlights">
      <div className="market-ticker-track">
        <div className="market-ticker-copy">{tickerContent}</div>
        <div className="market-ticker-copy" aria-hidden="true">
          {tickerContent}
        </div>
      </div>
    </div>
  );
}
