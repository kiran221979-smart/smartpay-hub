import { createFileRoute } from "@tanstack/react-router";
import { SmartPortal } from "@/components/SmartPortal";

export const Route = createFileRoute("/automation")({
  head: () => ({
    meta: [
      { title: "Credit Card Bill Payment — Smart Pay" },
      {
        name: "description",
        content:
          "Premium Credit Card Bill Payment portal with AI-Powered Smart Digital Ledger, automated monthly statements, and 5-day decrementing due alerts.",
      },
    ],
  }),
  component: () => (
    <>
      <header className="mx-auto max-w-7xl px-4 pt-16 sm:px-6">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
          ◈ Credit Card Bill Payment · Automation Portal
        </div>
        <h1 className="mt-3 font-display text-4xl font-black sm:text-5xl">
          Credit Card Bill Payment
        </h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Hyper-secure, AI-orchestrated bill settlement with automated digital ledger,
          month-end statements, and 5-day decrementing due alerts.
        </p>
      </header>
      <SmartPortal />
    </>
  ),
});
