import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Play, X, Landmark, ShieldCheck, FileText, Info } from "lucide-react";

export const Route = createFileRoute("/alliances")({
  head: () => ({
    meta: [
      { title: "Smart Business Services — Smart Pay" },
      {
        name: "description",
        content:
          "Six Smart Business Services blocks: GST, Udyam, Labour License, IEC, Current Account and Loan & Insurance multi-utility — each with walkthrough video, pricing and document checklist.",
      },
    ],
  }),
  component: AlliancesPage,
});

type Alliance = {
  name: string;
  tagline: string;
  poster: string;
  description: string[];
  price: string;
  docs: string;
  highlights: string[];
};

const ALLIANCES: Alliance[] = [
  {
    name: "GST Registration & Monthly Filing Suite",
    tagline: "End-to-end GST registration plus monthly return filing.",
    poster: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1200&q=70",
    description: [
      "Complete GSTIN registration with verified ARN tracking.",
      "Monthly GSTR-1 and GSTR-3B preparation and filing.",
      "Input tax credit reconciliation and mismatch flags.",
      "Compliance calendar with deadline alerts.",
    ],
    price: "₹999 one-time setup + Monthly Subscription",
    docs: "PAN, Aadhaar, Business Address Proof",
    highlights: ["GSTIN setup", "Monthly filing", "ITC recovery", "Deadline alerts"],
  },
  {
    name: "MSME / Udyam Certification Node",
    tagline: "Fast-tracked Udyam (MSME) certification.",
    poster: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1200&q=70",
    description: [
      "Single-window Udyam registration with classification.",
      "Eligibility mapping for Micro, Small and Medium tiers.",
      "Auto-generated Udyam certificate PDF.",
      "Linkage with PAN, Aadhaar and GSTIN.",
    ],
    price: "₹300 fixed fee",
    docs: "Aadhaar linked to Mobile, PAN",
    highlights: ["Udyam certificate", "Tier classification", "PAN/Aadhaar link", "Instant PDF"],
  },
  {
    name: "Labour License Compliance Portal",
    tagline: "End-to-end labour license filing per worker slots.",
    poster: "https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1200&q=70",
    description: [
      "State-wise labour license application and renewal.",
      "Worker-slot based fee computation and challan generation.",
      "Address and entity verification workflow.",
      "Compliance dashboard for ongoing labour returns.",
    ],
    price: "Variable application fee based on worker slots",
    docs: "Entity ID, Address Details",
    highlights: ["State-wise filing", "Worker slot fees", "Renewal alerts", "Returns dashboard"],
  },
  {
    name: "ICE (Import Export Code) Core",
    tagline: "Import Export Code activation for cross-border trade.",
    poster: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=1200&q=70",
    description: [
      "DGFT-aligned IEC application and approval.",
      "Bank-linked verification with cancelled cheque upload.",
      "Auto-mapped to GSTIN for export refund eligibility.",
      "Lifetime IEC certificate with renewal reminders.",
    ],
    price: "₹499 setup fee",
    docs: "Entity PAN, Cancelled Cheque",
    highlights: ["DGFT IEC", "GST linkage", "Export refunds", "Lifetime certificate"],
  },
  {
    name: "All-Bank Current Account Route",
    tagline: "Affiliate-routed current account opening across all banks.",
    poster: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?auto=format&fit=crop&w=1200&q=70",
    description: [
      "Pure affiliate redirect tracking to 34+ partner banks.",
      "Comparison of average balance, fees and free transactions.",
      "Pre-filled application package per bank.",
      "Nominal processing fee — affiliate transparent.",
    ],
    price: "Nominal Processing Fee: ₹49 (pure affiliate redirect)",
    docs: "Bank-side KYC requirements apply",
    highlights: ["34+ banks", "Pre-filled forms", "Fee comparison", "Affiliate transparent"],
  },
  {
    name: "Smart Loan & Insurance Multi-Utility",
    tagline: "Single node for loans and insurance affiliate routing.",
    poster: "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?auto=format&fit=crop&w=1200&q=70",
    description: [
      "Pure affiliate redirect node across loans and insurance.",
      "Personal, business, home and gold loan comparisons.",
      "Health, motor and life insurance partner routing.",
      "Single dashboard for all applications and renewals.",
    ],
    price: "Nominal Processing Fee: ₹99 (pure affiliate redirect)",
    docs: "Lender / insurer KYC applies per product",
    highlights: ["Loans + Insurance", "Single dashboard", "Multi-lender", "Renewal tracker"],
  },
];

function AllianceCard({ a, onOpen }: { a: Alliance; onOpen: () => void }) {
  const [playing, setPlaying] = useState(false);
  return (
    <article className="flex flex-col overflow-hidden rounded-3xl border border-mint/20 bg-slate-elevated shadow-elevated">
      <header className="border-b border-mint/15 p-5">
        <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">
          Institutional Alliance
        </div>
        <h2 className="mt-1 font-display text-lg font-black sm:text-xl">{a.name}</h2>
        <p className="mt-1 text-xs text-foreground/80">{a.tagline}</p>
      </header>

      <div className="relative aspect-video w-full bg-black">
        {playing ? (
          <iframe
            className="absolute inset-0 h-full w-full"
            src="https://www.youtube-nocookie.com/embed/aqz-KE-bpKQ?autoplay=1&mute=1&rel=0"
            title={`${a.name} walkthrough`}
            loading="lazy"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <button
            onClick={() => setPlaying(true)}
            className="press press-on group absolute inset-0 grid place-items-center"
            aria-label={`Play ${a.name} walkthrough`}
          >
            <img
              src={a.poster}
              alt=""
              aria-hidden="true"
              loading="lazy"
              decoding="async"
              className="absolute inset-0 h-full w-full object-cover opacity-90 transition group-hover:scale-[1.02]"
              style={{ transform: "translateZ(0)" }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-deep/85 via-slate-deep/20 to-transparent" />
            <div className="relative grid h-16 w-16 place-items-center rounded-full bg-mint text-mint-foreground shadow-mint transition group-hover:scale-110">
              <Play className="h-7 w-7 fill-current" />
            </div>
          </button>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        {/* Top-aligned description bullets — grow to push price/button to a shared baseline */}
        <ul className="flex-1 space-y-1.5 text-xs leading-relaxed text-foreground/85">
          {a.description.map((d, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="mt-1.5 inline-block h-1 w-1 shrink-0 rounded-full bg-mint" />
              <span>{d}</span>
            </li>
          ))}
        </ul>

        <div className="flex min-h-[88px] flex-col justify-center rounded-xl border border-mint/25 bg-slate-deep/50 p-3 text-xs">
          <div className="font-display text-base font-black leading-tight text-mint">{a.price}</div>
          <div className="mt-1 text-[11px] text-foreground/75">
            <span className="font-bold uppercase tracking-widest text-mint">Docs:</span> {a.docs}
          </div>
        </div>

        <button
          onClick={onOpen}
          className="press press-on mt-auto inline-flex items-center justify-center gap-1.5 rounded-xl gradient-mint py-2.5 font-display text-sm font-bold text-primary-foreground shadow-mint"
        >
          <Info className="h-4 w-4" /> View Full Details
        </button>
      </div>
    </article>
  );
}

function DescriptionModal({ a, onClose }: { a: Alliance; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-[120] grid place-items-center bg-slate-deep/85 p-4 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-mint/40 bg-slate-elevated shadow-mint"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-mint/40 bg-slate-deep/80 text-mint hover:bg-mint hover:text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="p-6 sm:p-8">
          <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">Alliance Detail</div>
          <h3 className="mt-2 font-display text-2xl font-black sm:text-3xl">{a.name}</h3>
          <ul className="mt-5 space-y-2.5 text-sm leading-relaxed text-foreground/90">
            {a.description.map((d, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-mint" />
                <span>{d}</span>
              </li>
            ))}
          </ul>
          <div className="mt-5 rounded-2xl border border-mint/25 bg-slate-deep/50 p-5">
            <div className="font-display text-xl font-black text-mint">{a.price}</div>
            <div className="mt-2 text-sm text-foreground/85">
              <span className="font-bold uppercase tracking-widest text-mint text-[10px]">Documents required: </span>
              {a.docs}
            </div>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {a.highlights.map((h) => (
                <li key={h} className="inline-flex items-center gap-2 rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2 text-xs text-foreground/90">
                  <ShieldCheck className="h-4 w-4 text-mint" /> {h}
                </li>
              ))}
            </ul>
          </div>
          <button className="press press-on mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-display font-bold text-primary-foreground shadow-mint">
            <FileText className="h-4 w-4" /> Begin Application
          </button>
        </div>
      </div>
    </div>
  );
}

function AlliancesPage() {
  const [active, setActive] = useState<Alliance | null>(null);
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Landmark className="h-3 w-3" /> Smart Business Services
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">
          Smart Business Services
        </h1>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">
          Six full-sized Smart Business Services blocks arranged in a stable 3-column grid — each with title,
          walkthrough video, transparent application pricing and document checklist.
        </p>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {ALLIANCES.map((a) => (
          <AllianceCard key={a.name} a={a} onOpen={() => setActive(a)} />
        ))}
      </div>

      {active && <DescriptionModal a={active} onClose={() => setActive(null)} />}
    </section>
  );
}
