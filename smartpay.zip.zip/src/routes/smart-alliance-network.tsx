import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, ExternalLink, Infinity as InfinityIcon, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/smart-alliance-network")({
  head: () => ({
    meta: [
      { title: "Smart Alliance Network — Recurring Income Assets — Smart Pay" },
      { name: "description", content: "Premium recurring monthly income assets — official AI integrations including Canva Pro, Lovable, Leonardo, and Hostinger." },
      { property: "og:title", content: "Smart Alliance Network — Smart Pay" },
      { property: "og:description", content: "Recurring monthly income assets powered by official AI integrations." },
    ],
  }),
  component: SmartAllianceNetworkPage,
});

type AllianceCard = {
  id: string;
  name: string;
  tagline: string;
  payout: string;
  cadence: string;
  href: string;
  gradient: string;
};

const ALLIANCES: AllianceCard[] = [
  {
    id: "canva",
    name: "Canva Pro Matrix",
    tagline: "Premium design engine for creators, agencies, and marketers — recurring subscription channel.",
    payout: "Up to ₹650 / activation",
    cadence: "Monthly Recurring",
    href: "https://www.canva.com/",
    gradient: "from-mint/20 via-slate-deep/40 to-slate-deep/10",
  },
  {
    id: "lovable",
    name: "Lovable AI Engine",
    tagline: "Agentic AI build platform — every signup compounds into a long-tail recurring stream.",
    payout: "Up to $20 / activation",
    cadence: "Recurring Lifetime",
    href: "https://lovable.dev/",
    gradient: "from-mint/25 via-slate-deep/40 to-slate-deep/10",
  },
  {
    id: "leonardo",
    name: "Leonardo Creative Suite",
    tagline: "Generative imaging and creative pipeline — premium subscription with high renewal velocity.",
    payout: "Up to 30% recurring",
    cadence: "Monthly Recurring",
    href: "https://leonardo.ai/",
    gradient: "from-mint/20 via-slate-deep/40 to-slate-deep/10",
  },
  {
    id: "hostinger",
    name: "Hostinger Enterprise",
    tagline: "Enterprise-grade hosting and cloud stack with one of the highest converting referral matrices.",
    payout: "Up to 60% / sale",
    cadence: "Renewal Compound",
    href: "https://www.hostinger.com/",
    gradient: "from-mint/20 via-slate-deep/40 to-slate-deep/10",
  },
];

function SmartAllianceNetworkPage() {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Sparkles className="h-3 w-3" /> Recurring Monthly Income Assets
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">Smart Alliance Network</h1>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">
          Premium official AI integrations engineered into a recurring income matrix. Activate any node to compound monthly passive cashflow.
        </p>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2">
        {ALLIANCES.map((a) => (
          <article
            key={a.id}
            className={`group relative flex flex-col overflow-hidden rounded-3xl border border-mint/25 bg-gradient-to-br ${a.gradient} p-6 shadow-elevated transition hover:-translate-y-1 hover:border-mint hover:shadow-mint`}
          >
            <header className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-mint">Official AI Integration</div>
                <h3 className="mt-1 font-display text-xl font-black leading-snug">{a.name}</h3>
              </div>
              <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-mint/40 bg-mint/10 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
                <ShieldCheck className="h-3 w-3" /> Verified
              </span>
            </header>

            <p className="mt-3 text-sm text-foreground/85">{a.tagline}</p>

            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-foreground/70">Payout</div>
                <div className="font-display text-sm font-black text-mint">{a.payout}</div>
              </div>
              <div className="rounded-xl border border-mint/25 bg-slate-deep/60 px-3 py-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-foreground/70">Cadence</div>
                <div className="inline-flex items-center gap-1 font-display text-sm font-black text-mint">
                  <InfinityIcon className="h-3.5 w-3.5" /> {a.cadence}
                </div>
              </div>
            </div>

            <a
              href={a.href}
              target="_blank"
              rel="nofollow sponsored noopener noreferrer"
              data-referral-slot={a.id}
              className="press press-on mt-6 inline-flex items-center justify-center gap-2 rounded-xl gradient-mint px-4 py-3 font-display text-sm font-bold text-primary-foreground shadow-mint"
            >
              <ExternalLink className="h-4 w-4" /> Activate Premium Access
            </a>
          </article>
        ))}
      </div>
    </section>
  );
}
