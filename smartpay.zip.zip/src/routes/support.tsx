import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Headphones, Radio, X, Video, ShieldCheck, Camera, Wifi, UserCheck } from "lucide-react";
import { SupportBanner } from "@/components/SupportBanner";
import aaravAsset from "@/assets/aarav-mehta.jpg.asset.json";
import priyaAsset from "@/assets/priya-nair.jpg.asset.json";
import arjunAsset from "@/assets/fintech-ops-head.jpg.asset.json";
import ishaAsset from "@/assets/isha-kapoor.jpg.asset.json";
import nikhilAsset from "@/assets/nikhil-verma.jpg.asset.json";
import meeraAsset from "@/assets/meera-iyer.jpg.asset.json";
import rohanAsset from "@/assets/rohan-sharma.jpg.asset.json";
import kavithaAsset from "@/assets/kavitha-reddy.jpg.asset.json";
import ananyaAsset from "@/assets/ananya-singh.jpg.asset.json";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "Customer Support — Smart Pay 9-Member Specialist Grid" },
      {
        name: "description",
        content:
          "Nine live Smart Pay specialists across Credit Card Services, FinTech Products, AI Money Hub and Smart Business Services — in a clean symmetric 3×3 grid.",
      },
      { property: "og:title", content: "Customer Support — Smart Pay" },
      {
        property: "og:description",
        content:
          "Nine live customer support specialists in a symmetric 3×3 grid across four departments.",
      },
    ],
  }),
  component: SupportPage,
});

type Agent = {
  name: string;
  role: string;
  label: string;
  duty: string;
  photo: string;
};

const AGENTS: Agent[] = [
  // Row 1
  {
    name: "Aarav Mehta",
    role: "Technical Specialist — Credit Card Services",
    label: "Credit Card Services",
    duty: "Resolves credit card module technical queries end-to-end.",
    photo: aaravAsset.url,
  },
  {
    name: "Priya Nair",
    role: "Support Specialist — Credit Card Services",
    label: "Credit Card Services",
    duty: "Guides customers through credit card service workflows.",
    photo: priyaAsset.url,
  },
  {
    name: "Arjun Pillai",
    role: "Technical Support — FinTech Products",
    label: "FinTech Products",
    duty: "Handles technical support across the FinTech digital product stack.",
    photo: arjunAsset.url,
  },
  // Row 2
  {
    name: "Isha Kapoor",
    role: "Operations Support — FinTech Products",
    label: "FinTech Products",
    duty: "Coordinates operations and onboarding for FinTech product modules.",
    photo: ishaAsset.url,
  },
  {
    name: "Nikhil Verma",
    role: "Support Analyst — AI Money Hub",
    label: "AI Money Hub",
    duty: "Analyses AI Money Hub flows and assists customers with usage.",
    photo: nikhilAsset.url,
  },
  {
    name: "Meera Iyer",
    role: "System Specialist — AI Money Hub",
    label: "AI Money Hub",
    duty: "Owns AI Money Hub system specialist support and troubleshooting.",
    photo: meeraAsset.url,
  },
  // Row 3
  {
    name: "Rohan Sharma",
    role: "Specialist — Smart Business Services",
    label: "Smart Business Services",
    duty: "Specialist guidance across GST, Udyam, IEC and current account services.",
    photo: rohanAsset.url,
  },
  {
    name: "Kavitha Reddy",
    role: "Coordinator — Smart Business Services",
    label: "Smart Business Services",
    duty: "Coordinates document collection and partner-bank routing for business services.",
    photo: kavithaAsset.url,
  },
  {
    name: "Ananya Singh",
    role: "Senior Lead Customer Interaction",
    label: "Senior Lead",
    duty: "Senior lead overseeing premium customer interaction and escalations.",
    photo: ananyaAsset.url,
  },
];

function HeadsetBadge() {
  return (
    <span
      className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full border border-mint/50 bg-slate-deep/80 px-2 py-1 text-[9px] font-bold uppercase tracking-widest text-mint backdrop-blur"
      title="Headset mic live"
    >
      <Radio className="h-3 w-3" /> Headset Live
    </span>
  );
}

function AgentCard({ agent, onOpen }: { agent: Agent; onOpen: () => void }) {
  return (
    <button
      onClick={onOpen}
      className="press press-on group relative flex h-full w-full flex-col items-center gap-4 overflow-hidden rounded-3xl border border-border bg-slate-elevated p-6 text-center shadow-elevated transition hover:border-mint hover:shadow-mint"
    >
      <span
        className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full border border-mint/50 bg-slate-deep/80 px-2 py-1 text-[9px] font-bold uppercase tracking-widest text-mint backdrop-blur"
        title="Headset mic live"
      >
        <Radio className="h-3 w-3" /> Headset Live
      </span>
      <div className="relative mt-2 h-36 w-36 shrink-0 overflow-hidden rounded-full border-2 border-mint/60 shadow-mint sm:h-40 sm:w-40">
        <img
          src={agent.photo}
          alt={`${agent.name}, ${agent.role}`}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-cover object-top transition group-hover:scale-105"
        />
      </div>
      <div className="inline-flex items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
        <Headphones className="h-3 w-3" /> {agent.label}
      </div>
      <div className="space-y-1.5">
        <div className="font-display text-lg font-black leading-tight sm:text-xl">{agent.name}</div>
        <div className="text-xs font-semibold leading-snug text-mint sm:text-sm">{agent.role}</div>
      </div>
      <div className="mt-auto inline-flex items-center gap-1.5 rounded-full bg-mint px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-mint-foreground shadow-mint">
        <Video className="h-3.5 w-3.5" /> ▶ Start Live Video Desk
      </div>
    </button>
  );
}

function LiveDialogue({ agent, onClose }: { agent: Agent; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-[120] grid place-items-center bg-slate-deep/85 p-4 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl overflow-hidden rounded-3xl border border-mint/40 bg-slate-elevated shadow-mint"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="End live dialogue"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-mint/40 bg-slate-deep/80 text-mint hover:bg-mint hover:text-mint-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="relative aspect-[4/3] w-full bg-black">
          <img
            src={agent.photo}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover object-top opacity-95"
            style={{ transform: "translateZ(0)" }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-deep/85 via-transparent to-transparent" />
          <div className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-red-400/60 bg-red-500/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-red-200 backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" /> Live · Encrypted
          </div>
          <div className="absolute inset-x-0 bottom-0 p-5">
            <div className="text-[10px] uppercase tracking-widest text-mint">{agent.label}</div>
            <div className="font-display text-2xl font-black">{agent.name}</div>
            <div className="text-sm text-foreground/85">{agent.role}</div>
          </div>
        </div>
        <div className="space-y-4 p-5 text-sm text-foreground/90">
          <div>
            <span className="mr-2 text-[10px] font-bold uppercase tracking-widest text-mint">Agent</span>
            Hello, I'm {agent.name.split(" ")[0]} from the {agent.label} desk. {agent.duty}
          </div>

          <div className="rounded-2xl border border-mint/40 bg-slate-deep p-4">
            <div className="flex items-center gap-2 text-mint">
              <Wifi className="h-4 w-4" />
              <div className="text-[11px] font-bold uppercase tracking-widest">📌 Connecting Direction Map</div>
            </div>
            <ol className="mt-3 space-y-2.5">
              {[
                { icon: <Video className="h-3.5 w-3.5" />, t: "Click the 'Start Live Video Desk' button below." },
                { icon: <Camera className="h-3.5 w-3.5" />, t: "Allow system permissions for Camera & Microphone when prompted." },
                { icon: <ShieldCheck className="h-3.5 w-3.5" />, t: "Secure encrypted bridge establishes instantly." },
                { icon: <UserCheck className="h-3.5 w-3.5" />, t: "Live face-to-face resolution begins with your assigned expert." },
              ].map((s, i) => (
                <li key={i} className="flex items-start gap-3 text-xs leading-relaxed text-foreground/90">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-mint/50 bg-mint/15 text-[10px] font-black text-mint">
                    {i + 1}
                  </span>
                  <span className="flex flex-1 items-start gap-1.5">
                    <span className="mt-0.5 text-mint">{s.icon}</span>
                    <span><span className="font-bold text-mint">Step {i + 1}:</span> {s.t}</span>
                  </span>
                </li>
              ))}
            </ol>
          </div>

          <button
            type="button"
            className="press press-on inline-flex w-full items-center justify-center gap-2 rounded-xl gradient-mint py-3 text-sm font-bold text-primary-foreground shadow-mint"
          >
            <Video className="h-4 w-4" /> ▶ Start Live Video Desk
          </button>
        </div>
      </div>
    </div>
  );
}

function SupportPage() {
  const [active, setActive] = useState<Agent | null>(null);

  return (
    <section className="mx-auto w-full max-w-7xl px-6 py-20 sm:px-8 lg:px-12">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Headphones className="h-3 w-3" /> Maa Expert Team
        </div>
        <h1 className="mt-5 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">
          Meet the Maa Expert Team
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          Nine live Maa Expert Team specialists in a clean symmetric 3 × 3 grid — across Credit Card Services,
          FinTech Products, AI Money Hub and Smart Business Services.
        </p>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {AGENTS.map((a) => (
          <AgentCard key={a.name} agent={a} onOpen={() => setActive(a)} />
        ))}
      </div>

      <div className="mt-12">
        <SupportBanner />
      </div>

      {active && <LiveDialogue agent={active} onClose={() => setActive(null)} />}
    </section>
  );
}
