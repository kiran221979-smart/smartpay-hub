import "sonner/dist/styles.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AdminProvider } from "@/lib/admin-store";
import { Toaster } from "@/components/ui/sonner";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ServerStatusBanner } from "@/components/ServerStatusBanner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-black text-mint">404</h1>
        <h2 className="mt-4 font-display text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          This route doesn't exist on the Smart Pay platform.
        </p>
        <Link
          to="/"
          className="press press-on mt-6 inline-flex rounded-xl gradient-mint px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-mint"
        >
          Go home
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-xl font-semibold">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="press press-on rounded-xl gradient-mint px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-mint"
          >
            Try again
          </button>
          <a
            href="/"
            className="press press-on rounded-xl border border-border bg-slate-elevated px-5 py-2.5 text-sm font-bold"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Smart Pay — Agentic AI for Instant Card-to-Bank Rails" },
      {
        name: "description",
        content:
          "India's first Agentic-AI fintech platform. 24/7 instant credit-to-bank withdrawals, bill autopay, and AI money tools — PCI-DSS secure.",
      },
      { property: "og:title", content: "Smart Pay" },
      {
        property: "og:description",
        content:
          "Agentic AI for instant card-to-bank rails, bill autopay, and 24/7 smart withdrawals.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700;800&display=swap",
      },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AdminProvider>
        <div className="flex min-h-screen flex-col">
          <Header />
          <ServerStatusBanner />
          <main className="flex-1">
              <Outlet />
            </main>
            <Toaster />
          <Footer />
          <Link
            to="/support"
            aria-label="Open Customer Support"
            title="Customer Support"
            className="press press-on fixed bottom-5 right-5 z-[90] grid h-14 w-14 place-items-center rounded-full gradient-mint text-primary-foreground shadow-mint ring-2 ring-mint/40 transition hover:scale-105"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6">
              <path d="M3 14a9 9 0 0 1 18 0v4a2 2 0 0 1-2 2h-1v-6h3" />
              <path d="M3 14v4a2 2 0 0 0 2 2h1v-6H3" />
            </svg>
          </Link>
        </div>
      </AdminProvider>
    </QueryClientProvider>
  );
}
