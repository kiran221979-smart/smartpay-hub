import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck, Sparkles } from "lucide-react";
import raghavanAsset from "@/assets/raghavan-chari.jpg.asset.json";
import shaliniAsset from "@/assets/shalini-sen.jpg.asset.json";
import vikramAsset from "@/assets/vikramaditya-malhotra.jpg.asset.json";
import meenakshiAsset from "@/assets/meenakshi-sundaram.jpg.asset.json";
import devendraAsset from "@/assets/devendra-shastri.jpg.asset.json";
import aniketAsset from "@/assets/aniket-vardhan.jpg.asset.json";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Smart Pay Elite Advisory Council" },
      {
        name: "description",
        content:
          "Meet the 6-member Elite Advisory Council steering Smart Pay's Agentic AI Payout System — banking security, liquidity, AI architecture, alliances, RegTech and core infrastructure.",
      },
    ],
  }),
  component: About,
});

type Advisor = {
  name: string;
  role: string;
  bio: string;
  photo: string;
};

const COUNCIL: Advisor[] = [
  {
    name: "Dr. Raghavan Chari",
    role: "Chief Banking Security & Compliance Officer",
    bio: "25+ years in institutional risk architecture and payment network protocols.",
    photo: raghavanAsset.url,
  },
  {
    name: "Shalini Sen, CFA",
    role: "Managing Director of Liquidity & Asset Strategy",
    bio: "Former capital markets head specializing in enterprise-grade settlement frameworks.",
    photo: shaliniAsset.url,
  },
  {
    name: "Vikramaditya Malhotra",
    role: "Principal AI Systems & Neural Logic Architect",
    bio: "Leads our automated money-routing engines and predictive data ledgers.",
    photo: vikramAsset.url,
  },
  {
    name: "Meenakshi Sundaram",
    role: "Chief of Corporate Alliances & Strategic Growth",
    bio: "Spearheads institutional integrations and enterprise business solutions.",
    photo: meenakshiAsset.url,
  },
  {
    name: "Devendra Nath Shastri",
    role: "Senior Financial RegTech Specialist",
    bio: "Expert in multi-jurisdictional compliance, digital invoicing systems, and ledger laws.",
    photo: devendraAsset.url,
  },
  {
    name: "Aniket Vardhan",
    role: "Head of Core Fintech Infrastructure & Security",
    bio: "Architect of our ultra-fast routing microservices and real-time ledger channels.",
    photo: aniketAsset.url,
  },
];

function About() {
  return (
    <section className="mx-auto w-full max-w-7xl px-6 py-20 sm:px-8 lg:px-12">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Sparkles className="h-3 w-3" /> Behind the Minds
        </div>
        <h1 className="mt-5 font-display text-3xl font-black sm:text-5xl">
          The <span className="shimmer-text">Elite Advisory Council</span>
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          Senior Leadership &amp; Advisory Council — six globally credentialed minds engineering India's
          first autonomous Agentic AI Payout System.
        </p>
        <div className="mx-auto mt-4 inline-flex items-center gap-1.5 rounded-full border border-burnt/40 bg-burnt/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-burnt">
          <ShieldCheck className="h-3 w-3" /> Department: Senior Leadership &amp; Advisory Council
        </div>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3 lg:gap-12">
        {COUNCIL.map((m) => (
          <article
            key={m.name}
            className="press group flex h-full flex-col items-center rounded-3xl border border-border bg-slate-elevated p-7 text-center shadow-elevated transition hover:-translate-y-1 hover:border-mint hover:shadow-mint"
          >
            <div
              className="relative h-36 w-36 shrink-0 overflow-hidden rounded-full border-2 border-mint/60 bg-slate-deep sm:h-40 sm:w-40"
              style={{
                boxShadow:
                  "0 0 22px color-mix(in oklab, var(--color-mint) 55%, transparent), inset 0 0 14px color-mix(in oklab, var(--color-mint) 25%, transparent)",
              }}
            >
              <img
                src={m.photo}
                alt={`${m.name}, ${m.role}`}
                loading="lazy"
                decoding="async"
                width={600}
                height={600}
                className="object-cover object-top w-full h-full transition group-hover:scale-105"
              />
            </div>
            <h3 className="mt-6 font-display text-xl font-black leading-tight">{m.name}</h3>
            <p className="mt-2 text-sm font-bold leading-snug text-mint">{m.role}</p>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{m.bio}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
