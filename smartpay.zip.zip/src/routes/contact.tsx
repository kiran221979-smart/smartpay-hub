import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mic, Sparkles, Video, Volume2 } from "lucide-react";
import executiveTeam from "@/assets/indian-executive-team.jpg";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Smart Pay 24/7 AI Video Assistant" },
      { name: "description", content: "Talk to a real-time AI video receptionist or our human support team — 24/7." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [language, setLanguage] = useState<"TELUGU" | "ENGLISH" | "HINDI">("ENGLISH");
  const [speaking, setSpeaking] = useState(false);
  const greetings = {
    TELUGU: "నమస్కారం, మీ స్మార్ట్ పే గేట్‌వే రూటింగ్‌ని నేను ఇప్పుడే వెరిఫై చేస్తున్నాను...",
    ENGLISH: "Hello, I’m verifying your Smart Pay gateway routing right now. Your secure path is my priority.",
    HINDI: "नमस्ते, मैं अभी आपके स्मार्ट पे गेटवे रूटिंग को सत्यापित कर रही हूँ...",
  };

  const selectLanguage = (next: typeof language) => {
    setLanguage(next);
    setSpeaking(true);
    window.setTimeout(() => setSpeaking(false), 3600);
  };

  return (
    <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-burnt/40 bg-burnt/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-burnt">
          <Sparkles className="h-3 w-3" /> Real-Time AI Concierge
        </div>
        <h1 className="mt-4 font-display text-4xl font-black sm:text-5xl">
          24/7 Real-Time Live <span className="shimmer-text">AI Video Assistant</span>
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">Connect directly with Priya Sharma for secure, multilingual gateway guidance—without chat queues, email boxes, or messaging handoffs.</p>
      </div>

      <div id="priya-live-assistant" className="mx-auto mt-10 max-w-3xl scroll-mt-28 overflow-hidden rounded-3xl border border-mint/50 bg-slate-elevated shadow-mint">
        <div className="flex items-center justify-between border-b border-border bg-slate-deep px-5 py-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-mint"><Video className="h-4 w-4" /> Secure video terminal</div>
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-mint"><span className="h-2 w-2 animate-pulse rounded-full bg-mint" /> Live 24/7</div>
        </div>
        <div className="grid md:grid-cols-[0.85fr_1.15fr]">
          <div className="relative h-80 overflow-hidden bg-slate-deep md:h-auto md:min-h-96">
            <img src={executiveTeam} alt="Priya Sharma, Smart Pay Indian AI video receptionist" className={`absolute inset-0 h-full w-full object-cover ${speaking ? "animate-avatar-talk" : ""}`} style={{ objectPosition: "10% center" }} width={1920} height={768} />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-deep via-slate-deep/80 to-transparent p-5 pt-16">
              <div className="font-display text-xl font-bold">Priya Sharma</div>
              <div className="text-xs font-semibold text-mint">AI Video Receptionist · Live</div>
            </div>
          </div>
          <div className="flex flex-col justify-center p-6">
            <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Select conversation language</div>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {(["TELUGU", "ENGLISH", "HINDI"] as const).map((item) => (
                <button key={item} onClick={() => selectLanguage(item)} className={`press press-on rounded-xl border px-3 py-3 text-xs font-black tracking-wider ${language === item ? "border-mint bg-mint text-mint-foreground shadow-mint" : "border-mint/40 bg-mint/10 text-mint"}`}>🌐 {item}</button>
              ))}
            </div>
            <div className="mt-6 rounded-2xl border border-border bg-slate-deep p-5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-mint"><Volume2 className="h-4 w-4" /> Priya is {speaking ? "speaking" : "ready"}</div>
              <p className="mt-3 min-h-20 text-sm leading-relaxed text-foreground/90">“{greetings[language]}”</p>
              <div className="mt-4 flex h-8 items-center justify-center gap-1" aria-label="Lip sync audio visualization">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((item) => <span key={item} className={`w-1 rounded-full bg-mint ${speaking ? "animate-voice-bar" : "h-1"}`} style={{ animationDelay: `${item * 70}ms` }} />)}
              </div>
            </div>
            <button onClick={() => selectLanguage(language)} className="press press-on mt-5 flex items-center justify-center gap-2 rounded-xl gradient-mint py-3.5 font-display font-bold text-primary-foreground shadow-mint"><Mic className="h-4 w-4" /> Start Live Greeting</button>
          </div>
        </div>
      </div>
    </section>
  );
}
