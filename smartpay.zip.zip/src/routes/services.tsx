import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Wallet,
  CreditCard,
  Timer,
  Activity,
  Cpu,
  Network,
  Atom,
  Hexagon,
  Layers,
  Sparkles,
  Wifi,
  Percent,
} from "lucide-react";

import { GeoTicker } from "@/components/GeoTicker";
import { INDIAN_BANKS } from "@/lib/banks";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Smart Pay" },
      {
        name: "description",
        content:
          "Withdrawal deck, 45-second settlement timer engine, 6 AI tiers, and premium card-network rails.",
      },
    ],
  }),
  component: ServicesPage,
});

/* ─────────────── helpers ─────────────── */
const formatCard = (v: string) =>
  v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
const formatExpiry = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
};

const ODD_FIGURES = [15690, 42730, 51230, 74870, 88150, 93410];

/* ─────────────── LEFT: Withdrawal Form ─────────────── */
function WithdrawalDeck({
  onCardTyping,
}: {
  onCardTyping: (v: boolean) => void;
}) {
  const [form, setForm] = useState({
    name: "",
    mobile: "",
    bank: INDIAN_BANKS[0],
    card: "",
    expiry: "",
    cvv: "",
    amount: "",
  });
  const [amountTouched, setAmountTouched] = useState(false);

  const setAmount = (raw: string) => {
    const digits = raw.replace(/\D/g, "").slice(0, 5);
    setForm((f) => ({ ...f, amount: digits }));
  };

  const validateAmount = () => {
    const n = Number(form.amount || 0);
    if (form.amount && (n < 100 || n > 99999)) {
      toast.error("Amount must be between ₹100 and ₹99,999");
      return false;
    }
    if (!amountTouched && form.amount) {
      toast("Please enter odd figure for your safety transaction", {
        description: "Pick from suggested tags below for safest routing.",
      });
      setAmountTouched(true);
    }
    return true;
  };

  const handleCardChange = (v: string) => {
    setForm((f) => ({ ...f, card: formatCard(v) }));
    onCardTyping(v.replace(/\D/g, "").length >= 4);
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!validateAmount()) return;
        toast.success("Withdrawal request queued · 45s SLA");
      }}
      className="relative overflow-hidden rounded-3xl border border-mint/40 bg-slate-deep p-5 shadow-mint sm:p-6"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-mint">
          <Wallet className="h-5 w-5" />
          <div className="text-sm font-bold uppercase tracking-widest">
            Withdrawal Form Deck
          </div>
        </div>
        <span className="rounded-full border border-mint/40 bg-mint/10 px-2.5 py-0.5 font-mono text-[9px] font-black uppercase tracking-[0.25em] text-mint">
          SECURE · v45
        </span>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <Field label="Full Name">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Ravi Kumar"
            className={inputCls}
          />
        </Field>
        <Field label="Mobile Number">
          <input
            value={form.mobile}
            onChange={(e) =>
              setForm({ ...form, mobile: e.target.value.replace(/\D/g, "").slice(0, 10) })
            }
            placeholder="9XXXXXXXXX"
            className={inputCls}
          />
        </Field>
        <Field label="Bank Name" className="sm:col-span-2">
          <select
            value={form.bank}
            onChange={(e) => setForm({ ...form, bank: e.target.value })}
            className={inputCls}
          >
            {INDIAN_BANKS.map((b) => (
              <option key={b} value={b} className="bg-slate-deep">
                {b}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Card Number" className="sm:col-span-2">
          <input
            value={form.card}
            onChange={(e) => handleCardChange(e.target.value)}
            placeholder="1111 2222 3333 4444"
            inputMode="numeric"
            className={`${inputCls} font-mono tracking-[0.2em]`}
          />
        </Field>
        <Field label="Expiry (MM/YY)">
          <input
            value={form.expiry}
            onChange={(e) => setForm({ ...form, expiry: formatExpiry(e.target.value) })}
            placeholder="11/29"
            className={`${inputCls} font-mono`}
          />
        </Field>
        <Field label="CVV">
          <input
            type="password"
            value={form.cvv}
            onChange={(e) =>
              setForm({ ...form, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })
            }
            placeholder="•••"
            className={`${inputCls} font-mono`}
          />
        </Field>

        <Field label="Settlement Amount (₹100 – ₹99,999)" className="sm:col-span-2">
          <div className="flex items-center gap-2">
            <span className="font-mono text-mint">₹</span>
            <input
              value={form.amount}
              onChange={(e) => setAmount(e.target.value)}
              onBlur={validateAmount}
              placeholder="Enter an odd figure for safety"
              inputMode="numeric"
              className={`${inputCls} font-mono`}
            />
          </div>
          {/* Neon line accent */}
          <div className="relative mt-2 h-[2px] w-full overflow-hidden rounded-full">
            <div
              className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-mint to-transparent"
              style={{
                boxShadow:
                  "0 0 10px color-mix(in oklab, var(--color-mint) 80%, transparent), 0 0 22px color-mix(in oklab, var(--color-mint) 55%, transparent)",
              }}
            />
          </div>
          <div className="mt-1.5 flex justify-between font-mono text-[8px] uppercase tracking-[0.25em] text-mint/60">
            <span>◈ secure rail</span>
            <span>neon-lock · v45</span>
          </div>
        </Field>

      </div>

      {/* Smart tags */}
      <div className="mt-3">
        <div className="text-[9px] font-bold uppercase tracking-widest text-mint/70">
          Smart Odd Figures
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {ODD_FIGURES.map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => {
                setForm((f) => ({ ...f, amount: String(n) }));
                setAmountTouched(true);
                toast.success(`Amount set to ₹${n.toLocaleString("en-IN")}`);
              }}
              className="press rounded-lg border border-mint/40 bg-slate-elevated px-2 py-2 font-mono text-[12px] font-bold text-mint transition hover:border-mint hover:bg-mint/10 hover:shadow-mint"
            >
              ₹{n.toLocaleString("en-IN")}
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className="press press-on mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-mint/60 bg-mint/15 px-4 py-3 text-sm font-black uppercase tracking-widest text-mint hover:bg-mint/25"
      >
        Select Your Tier <span aria-hidden>👇</span>
      </button>

    </form>
  );
}

const inputCls =
  "w-full rounded-lg border border-mint/30 bg-slate-elevated px-3 py-2 text-sm text-foreground outline-none transition focus:border-mint focus:shadow-mint";

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="text-[9px] font-bold uppercase tracking-widest text-mint/80">
        {label}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

/* ─────────────── RIGHT: Settlement Timer Engine ─────────────── */
function useTick(min: number, max: number, ms: number, fixed = 1) {
  const [v, setV] = useState(((min + max) / 2).toFixed(fixed));
  useEffect(() => {
    const id = window.setInterval(
      () => setV((min + Math.random() * (max - min)).toFixed(fixed)),
      ms,
    );
    return () => window.clearInterval(id);
  }, [min, max, ms, fixed]);
  return v;
}

function SettlementTimerEngine({ active }: { active: boolean }) {
  const [centi, setCenti] = useState(0);
  useEffect(() => {
    if (!active) {
      setCenti(0);
      return;
    }
    const id = window.setInterval(() => setCenti((c) => (c + 1) % 4500), 10);
    return () => window.clearInterval(id);
  }, [active]);

  const total = 4500 - centi;
  const sec = Math.floor(total / 100);
  const cs = total % 100;
  const display = `00:${String(sec).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;

  const throughput = useTick(8820, 9050, 600, 0);
  const latency = useTick(38.4, 44.8, 750, 1);
  const trust = useTick(99.31, 99.62, 900, 2);
  const nodes = useTick(178, 192, 1100, 0);
  const load = useTick(64.2, 71.6, 700, 1);

  return (
    <div
      className="relative overflow-hidden rounded-3xl border border-mint/50 bg-slate-deep"
      style={{
        boxShadow:
          "0 0 40px color-mix(in oklab, var(--color-mint) 20%, transparent), inset 0 0 60px color-mix(in oklab, #6FB7C9 8%, transparent)",
      }}
    >
      {["left-2 top-2 border-l-2 border-t-2", "right-2 top-2 border-r-2 border-t-2",
        "left-2 bottom-2 border-l-2 border-b-2", "right-2 bottom-2 border-r-2 border-b-2"].map((p, i) => (
        <div key={i} className={`pointer-events-none absolute h-5 w-5 border-mint/70 ${p}`} />
      ))}

      <div className="flex items-center justify-between border-b border-mint/25 bg-slate-deep/80 px-5 py-3">
        <div className="flex items-center gap-2 text-mint">
          <Timer className="h-4 w-4" />
          <span className="font-mono text-[10px] uppercase tracking-[0.3em]">
            SETTLEMENT TIMER ENGINE
          </span>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-mint/50 bg-mint/10 px-2.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-widest text-mint">
          <span className={`h-1.5 w-1.5 rounded-full bg-mint ${active ? "animate-pulse" : ""}`} />
          {active ? "LIVE · RUNNING" : "ARMED · 00:45.00"}
        </span>
      </div>

      <div className="relative grid gap-0 p-5">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "linear-gradient(color-mix(in oklab, var(--color-mint) 12%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in oklab, var(--color-mint) 12%, transparent) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />

        {/* Clock */}
        <div className="relative grid place-items-center py-4">
          <div
            className="relative rounded-2xl border border-mint/50 bg-slate-elevated/60 px-8 py-6"
            style={{
              boxShadow:
                "0 0 32px color-mix(in oklab, var(--color-mint) 35%, transparent), inset 0 0 24px color-mix(in oklab, var(--color-mint) 12%, transparent)",
            }}
          >
            <div className="text-center font-mono text-[10px] uppercase tracking-[0.35em] text-[#9FDCE9]">
              ATOMIC PAYOUT SLA
            </div>
            <div
              className="mt-1 font-mono text-5xl font-black tabular-nums text-mint sm:text-6xl"
              style={{
                textShadow:
                  "0 0 18px color-mix(in oklab, var(--color-mint) 80%, transparent)",
              }}
            >
              {display}
            </div>
            <div className="mt-1 text-center font-mono text-[10px] uppercase tracking-[0.3em] text-mint/70">
              {active ? "Card detected · streaming" : "Awaiting card details"}
            </div>
          </div>
        </div>

        {/* Telemetry graph */}
        <div className="relative mt-2 h-20 overflow-hidden rounded-xl border border-mint/30 bg-slate-elevated/60">
          <svg viewBox="0 0 100 40" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
            {[0, 1, 2].map((k) => (
              <FluidLine key={k} delay={k * 200} />
            ))}
          </svg>
          <div className="absolute left-2 top-1.5 font-mono text-[9px] uppercase tracking-widest text-[#9FDCE9]">
            // FLUID TELEMETRY
          </div>
        </div>

        {/* Metrics */}
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
          <Metric label="Throughput" unit="tps" value={throughput} />
          <Metric label="Latency" unit="ms" value={latency} />
          <Metric label="Trust" unit="%" value={trust} />
          <Metric label="Nodes" unit="" value={nodes} />
          <Metric label="Core Load" unit="%" value={load} />
        </div>
      </div>
    </div>
  );
}

function FluidLine({ delay }: { delay: number }) {
  const [pts, setPts] = useState("");
  useEffect(() => {
    const build = () => {
      const arr: string[] = [];
      for (let i = 0; i <= 40; i++) {
        const x = (i / 40) * 100;
        const y = 20 + Math.sin(i / 3 + Math.random() * 2) * (4 + Math.random() * 6);
        arr.push(`${x.toFixed(1)},${y.toFixed(1)}`);
      }
      setPts(arr.join(" "));
    };
    build();
    const id = window.setInterval(build, 650 + delay);
    return () => window.clearInterval(id);
  }, [delay]);
  return (
    <polyline
      points={pts}
      fill="none"
      stroke="var(--color-mint)"
      strokeWidth="0.6"
      strokeLinecap="round"
      style={{ filter: "drop-shadow(0 0 3px color-mix(in oklab, var(--color-mint) 70%, transparent))" }}
    />
  );
}

function Metric({ label, unit, value }: { label: string; unit: string; value: string }) {
  return (
    <div className="rounded-lg border border-mint/30 bg-slate-elevated/70 px-2.5 py-2">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[8px] uppercase tracking-[0.2em] text-[#9FDCE9]">
          {label}
        </span>
        <Activity className="h-2 w-2 text-mint/60" />
      </div>
      <div
        className="mt-0.5 font-mono text-sm font-black tabular-nums text-mint"
        style={{
          textShadow: "0 0 6px color-mix(in oklab, var(--color-mint) 40%, transparent)",
        }}
      >
        {value}
        <span className="ml-0.5 text-[9px] opacity-70">{unit}</span>
      </div>
    </div>
  );
}

/* ─────────────── TIER MATRIX ─────────────── */
type Tier = {
  id: string;
  name: string;
  Icon: typeof Cpu;
  badge?: string;
  logic: string;
};
const TIERS: Tier[] = [
  { id: "neural", name: "Smart Neural", Icon: Cpu, badge: "DOMESTIC",
    logic: "Engineered strictly for direct Credit Card to Bank Account money transfer only. This deployment focuses purely on speed; institutional card loyalty programs, reward miles, or bank-side benefits do not apply." },
  { id: "nexus", name: "Smart Nexus", Icon: Network, badge: "DOMESTIC",
    logic: "Performs full Credit Card to Bank Account money transfer just like the core engine, while guaranteeing that 100% of your native bank rewards, reward points, and milestone benefits remain fully applicable." },
  { id: "quantum", name: "Smart Quantum", Icon: Atom,
    logic: "Specially engineered for Corporate Credit Cards. Fully protects and activates all corporate-tier points, high-volume institutional rewards, and primary bank benefits during the settlement process." },
  { id: "vertex", name: "Smart Vertex", Icon: Hexagon,
    logic: "Designed specifically for Business Credit Cards. Optimizes commercial liquidity routing protocols while ensuring all business-class rewards, merchant perks, and bank-side cashbacks apply 100%." },
  { id: "core", name: "Smart Core", Icon: Layers,
    logic: "An isolated settlement rail built custom-tailored for Diners Club cards. Securely manages transaction logic to preserve exclusive premium lifestyle points, elite lounge accesses, and network rewards." },
  { id: "apex", name: "Smart Apex", Icon: Sparkles,
    logic: "A premium cryptographic settlement node optimized custom for American Express (AMEX). Seamlessly processes transaction payloads while ensuring 100% compliance with native Membership Rewards." },
];

const DEFAULT_FEES: Record<string, string> = {
  neural: "1.20",
  nexus: "1.45",
  quantum: "1.85",
  vertex: "1.65",
  core: "2.10",
  apex: "2.25",
};

function TierCard({ tier, blinking }: { tier: Tier; blinking: boolean }) {
  const [fee, setFee] = useState(DEFAULT_FEES[tier.id] ?? "1.50");
  const { Icon } = tier;
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-mint/40 bg-slate-deep shadow-mint transition hover:border-mint">
      <div className="flex items-start justify-between border-b border-mint/20 bg-[linear-gradient(135deg,color-mix(in_oklab,var(--color-mint)_10%,transparent),transparent)] px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="grid h-10 w-10 place-items-center rounded-lg border border-mint/50 bg-slate-elevated text-mint">
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[9px] font-bold uppercase tracking-widest text-mint/70">Tier Module</div>
            <div className="font-display text-base font-black text-foreground">{tier.name}</div>
          </div>
        </div>
        {tier.badge && (
          <span className="rounded-md border border-mint/40 bg-mint/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-widest text-mint/90">
            {tier.badge}
          </span>
        )}
      </div>
      {blinking && (
        <div className="border-b border-mint/20 bg-slate-elevated/50 px-4 py-1.5">
          <span className="inline-flex items-center gap-1.5 animate-pulse text-[10px] font-black uppercase tracking-widest text-mint">
            <span className="h-1.5 w-1.5 rounded-full bg-mint shadow-mint" />
            NO HIDDEN BANK CHARGES
          </span>
        </div>
      )}
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="text-left">
          <div className="flex items-center justify-between">
            <div className="text-[9px] font-bold uppercase tracking-widest text-mint/80">
              Service Channel Fee (%)
            </div>
            <span className="rounded-md border border-mint/30 bg-slate-elevated px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-widest text-mint/70">
              Owner · Editable
            </span>
          </div>
          <div className="mt-1.5 flex items-center gap-2">
            <Percent className="h-3.5 w-3.5 text-mint" />
            <input
              type="number"
              step="0.01"
              min={0}
              max={100}
              value={fee}
              onChange={(e) => setFee(e.target.value)}
              className="w-full rounded-lg border border-mint/40 bg-slate-elevated px-3 py-2 font-mono text-sm font-bold tabular-nums text-mint outline-none focus:border-mint focus:shadow-mint"
              style={{
                textShadow:
                  "0 0 8px color-mix(in oklab, var(--color-mint) 50%, transparent)",
              }}
            />
            <span className="font-mono text-sm font-black text-mint">%</span>
          </div>
          <div className="relative mt-2 h-[2px] w-full overflow-hidden rounded-full">
            <div
              className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-mint to-transparent"
              style={{
                boxShadow:
                  "0 0 8px color-mix(in oklab, var(--color-mint) 70%, transparent)",
              }}
            />
          </div>
        </div>
        <p className="text-[11.5px] leading-relaxed text-foreground/85">{tier.logic}</p>
      </div>
    </div>
  );
}


/* ─────────────── Card Marquee (Teal · NO RED) ─────────────── */
type NetSpec = {
  key: string;
  brand: string;
  tier: string;
  holder: string;
  pan: string;
  bgGradient: string;
  accent: string;
};

const NETWORK_SPECS: NetSpec[] = [
  {
    key: "visa",
    brand: "VISA",
    tier: "PLATINUM",
    holder: "R. KAPOOR",
    pan: "4539 •••• •••• 7821",
    bgGradient: "linear-gradient(135deg, #06121a 0%, #0a2434 50%, #0d1117 100%)",
    accent: "#9FDCE9",
  },
  {
    key: "mc",
    brand: "Mastercard",
    tier: "WORLD ELITE",
    holder: "A. MEHTA",
    pan: "5412 •••• •••• 3390",
    bgGradient: "linear-gradient(135deg, #08161e 0%, #0e2a34 50%, #0d1117 100%)",
    accent: "#7FD6E3",
  },
  {
    key: "rupay",
    brand: "RuPay",
    tier: "SELECT",
    holder: "S. IYER",
    pan: "6076 •••• •••• 1284",
    bgGradient: "linear-gradient(135deg, #07151f 0%, #0c2839 50%, #0d1117 100%)",
    accent: "#8FE0CE",
  },
  {
    key: "amex",
    brand: "AMEX",
    tier: "CENTURION",
    holder: "V. MALHOTRA",
    pan: "3782 ••••••• 54021",
    bgGradient: "linear-gradient(135deg, #0a1118 0%, #18242e 50%, #0d1117 100%)",
    accent: "#C8D6DC",
  },
  {
    key: "diners",
    brand: "Diners Club",
    tier: "INTERNATIONAL",
    holder: "P. NAIR",
    pan: "3056 •••• •• 7240",
    bgGradient: "linear-gradient(135deg, #08131c 0%, #0d2935 50%, #0d1117 100%)",
    accent: "#9FDCE9",
  },
];

function BrandMark({ spec }: { spec: NetSpec }) {
  if (spec.key === "visa")
    return (
      <div className="flex flex-col items-end">
        <span
          className="font-display text-2xl font-black italic tracking-tighter"
          style={{ color: spec.accent, textShadow: `0 0 10px ${spec.accent}80` }}
        >
          VISA
        </span>
        <span className="font-mono text-[7px] uppercase tracking-[0.35em] text-mint/70">
          Platinum
        </span>
      </div>
    );
  if (spec.key === "mc")
    return (
      <div className="flex flex-col items-end">
        <div className="flex items-center">
          <span
            className="block h-7 w-7 rounded-full"
            style={{ background: "color-mix(in oklab, var(--color-mint) 70%, #6FB7C9)" }}
          />
          <span
            className="-ml-3 block h-7 w-7 rounded-full mix-blend-screen"
            style={{ background: "color-mix(in oklab, #9FDCE9 75%, transparent)" }}
          />
        </div>
        <span className="mt-0.5 font-mono text-[7px] uppercase tracking-[0.3em] text-mint/70">
          World Elite
        </span>
      </div>
    );
  if (spec.key === "rupay")
    return (
      <div className="flex flex-col items-end">
        <div className="flex items-baseline gap-0.5 rounded-md border border-mint/40 bg-slate-elevated/60 px-2 py-0.5">
          <span className="font-display text-sm font-black text-mint">Ru</span>
          <span className="font-display text-sm font-black text-[#9FDCE9]">Pay</span>
        </div>
        <span className="mt-0.5 font-mono text-[7px] uppercase tracking-[0.3em] text-mint/70">
          Select · Secure
        </span>
      </div>
    );
  if (spec.key === "amex")
    return (
      <div className="flex flex-col items-end">
        <div
          className="rounded-sm border border-[#C8D6DC]/50 bg-[#0a1118] px-2.5 py-1"
          style={{ boxShadow: "0 0 12px color-mix(in oklab, #C8D6DC 45%, transparent)" }}
        >
          <span className="font-display text-[11px] font-black uppercase tracking-[0.25em] text-[#C8D6DC]">
            American Express
          </span>
        </div>
        <span className="mt-0.5 font-mono text-[7px] uppercase tracking-[0.3em] text-[#C8D6DC]/80">
          Centurion
        </span>
      </div>
    );
  // diners
  return (
    <div className="flex flex-col items-end">
      <div className="flex items-center gap-1">
        <div className="relative h-5 w-5">
          <span className="absolute inset-0 rounded-full border-2 border-mint/80" />
          <span className="absolute left-0 top-0 h-full w-1/2 rounded-l-full bg-mint/80" />
        </div>
        <span className="font-display text-[11px] font-black uppercase tracking-widest text-[#9FDCE9]">
          Diners Club
        </span>
      </div>
      <span className="mt-0.5 font-mono text-[7px] uppercase tracking-[0.3em] text-mint/70">
        International
      </span>
    </div>
  );
}

function NetCard({ spec }: { spec: NetSpec }) {
  return (
    <div
      className="relative h-[170px] w-[300px] shrink-0 overflow-hidden rounded-2xl p-4 ring-1 ring-mint/25"
      style={{
        background: spec.bgGradient,
        boxShadow:
          "0 18px 40px -22px rgba(0,0,0,0.9), 0 0 28px -10px color-mix(in oklab, var(--color-mint) 55%, transparent)",
      }}
    >
      {/* glowing teal overlay */}
      <div
        className="pointer-events-none absolute -left-12 -top-12 h-44 w-44 rounded-full blur-2xl"
        style={{ background: `color-mix(in oklab, ${spec.accent} 28%, transparent)` }}
      />
      <div
        className="pointer-events-none absolute -right-10 -bottom-10 h-36 w-36 rounded-full blur-2xl"
        style={{ background: "color-mix(in oklab, var(--color-mint) 22%, transparent)" }}
      />

      <div className="flex items-start justify-between">
        <div>
          <div className="text-[8px] font-bold uppercase tracking-[0.3em] text-mint/80">
            SmartPay · Premium Rail
          </div>
          <div
            className="mt-0.5 font-mono text-[10px] font-bold uppercase tracking-[0.25em]"
            style={{ color: spec.accent }}
          >
            {spec.tier} TIER
          </div>
        </div>
        <Wifi className="h-4 w-4 -rotate-90 text-mint" />
      </div>

      <div className="mt-3 flex items-center gap-3">
        <div className="grid h-8 w-11 grid-cols-3 gap-px overflow-hidden rounded-md bg-gradient-to-br from-[#a8c9d0] via-[#6FB7C9] to-[#2d6877] p-[2px]">
          {Array.from({ length: 6 }).map((_, k) => (
            <div key={k} className="bg-[#0d2530]/60" />
          ))}
        </div>
        <span className="font-mono text-[9px] font-semibold uppercase tracking-widest text-[#9FDCE9]/80">
          Silver Blue · Chip
        </span>
      </div>

      <div
        className="mt-3 font-mono text-[13px] font-semibold tracking-[0.2em] text-mint"
        style={{ textShadow: "0 0 8px color-mix(in oklab, var(--color-mint) 60%, transparent)" }}
      >
        {spec.pan}
      </div>

      <div className="mt-2 flex items-end justify-between">
        <div>
          <div className="text-[8px] uppercase tracking-widest text-[#9FDCE9]/70">Card Holder</div>
          <div className="font-display text-[11px] font-bold uppercase tracking-wide text-foreground/95">
            {spec.holder}
          </div>
        </div>
        <div className="text-right">
          <div className="text-[8px] uppercase tracking-widest text-[#9FDCE9]/70">Valid Thru</div>
          <div className="font-mono text-[11px] font-semibold text-foreground/95">11/29</div>
        </div>
        <BrandMark spec={spec} />
      </div>
    </div>
  );
}


function TealMarquee() {
  const loop = Array.from({ length: 4 }).flatMap(() => NETWORK_SPECS);
  return (
    <div className="card-marquee mt-2">
      <div className="mb-3 text-center text-[10px] font-bold uppercase tracking-[0.3em] text-mint">
        Premium Network Rails · Teal Neon · Silver Blue
      </div>
      <div className="card-marquee-mask">
        <div className="card-marquee-track">
          {loop.map((spec, i) => (
            <NetCard key={`${spec.key}-${i}`} spec={spec} />
          ))}
        </div>
      </div>
    </div>
  );
}


/* ─────────────── PAGE ─────────────── */
function ServicesPage() {
  const [cardActive, setCardActive] = useState(false);
  return (
    <>
      <header className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-10">
        <h1 className="font-display text-4xl font-black sm:text-5xl">Our Services</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Premium tiers for instant credit-to-bank transfer. Limits and charges are
          owner-editable from the Admin Registry.
        </p>
      </header>

      <div className="mt-6">
        <GeoTicker />
      </div>

      {/* HERO SPLIT */}
      <section className="mx-auto mt-10 grid w-full max-w-7xl gap-6 px-4 sm:px-6 lg:grid-cols-2 lg:px-10">
        <WithdrawalDeck onCardTyping={setCardActive} />
        <SettlementTimerEngine active={cardActive} />
      </section>

      {/* TIER MATRIX */}
      <section className="mx-auto mt-16 w-full max-w-7xl px-4 sm:px-6 lg:px-10">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
            ◈ Dynamic AI Tier Matrix · 6 Engines
          </div>
          <h2 className="mt-3 font-display text-2xl font-black sm:text-3xl">
            Choose Your <span className="text-mint">Settlement Engine</span>
          </h2>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TIERS.map((t) => (
            <TierCard
              key={t.id}
              tier={t}
              blinking={["neural", "nexus", "quantum", "vertex"].includes(t.id)}
            />
          ))}
        </div>
      </section>

      {/* MARQUEE */}
      <section className="mx-auto mt-16 mb-20 w-full max-w-7xl px-4 sm:px-6 lg:px-10">
        <div className="flex items-center justify-center gap-2 text-mint">
          <CreditCard className="h-4 w-4" />
          <div className="text-[10px] font-bold uppercase tracking-[0.3em]">
            Supported Networks
          </div>
        </div>
        <TealMarquee />
      </section>
    </>
  );
}
