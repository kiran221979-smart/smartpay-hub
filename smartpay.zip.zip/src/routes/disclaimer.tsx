import { createFileRoute } from "@tanstack/react-router";

const Page = ({ title, body }: { title: string; body: string }) => (
  <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
    <h1 className="font-display text-4xl font-black sm:text-5xl">{title}</h1>
    <p className="mt-5 whitespace-pre-line text-foreground/85">{body}</p>
  </section>
);

export const Route = createFileRoute("/disclaimer")({
  head: () => ({ meta: [{ title: "Disclaimers — Smart Pay" }] }),
  component: () => <Page title="Disclaimers" body={"Smart Pay is a technology routing platform. We are not a bank. Service availability is subject to upstream bank network uptime. All transaction times are best-effort estimates. AI score predictions are advisory only."} />,
});
