import { createFileRoute } from "@tanstack/react-router";

const Page = ({ title, body }: { title: string; body: string }) => (
  <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
    <h1 className="font-display text-4xl font-black sm:text-5xl">{title}</h1>
    <p className="mt-5 whitespace-pre-line text-foreground/85">{body}</p>
  </section>
);

export const Route = createFileRoute("/refund")({
  head: () => ({ meta: [{ title: "Refund Policy — Smart Pay" }] }),
  component: () => <Page title="Refund Policy" body={"Refunds for failed transactions are auto-initiated within 5–7 business days. For digital products, refunds are processed within 24 hours if no value was consumed. Contact care@smartfintech.app for disputes."} />,
});
