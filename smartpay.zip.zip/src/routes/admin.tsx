import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useAdmin, type Product } from "@/lib/admin-store";
import { Lock, Plus, Trash2, ShieldAlert, Bot, Phone, Package, SlidersHorizontal } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Registry — Smart Pay" }] }),
  component: AdminPage,
});

const tabs = [
  { id: "ops", label: "Operations", icon: ShieldAlert },
  { id: "tiers", label: "Service Tiers", icon: SlidersHorizontal },
  { id: "products", label: "Inventory", icon: Package },
  { id: "agent", label: "Agent Mode", icon: Bot },
] as const;

function AdminPage() {
  const { unlocked, unlock, lock, serverDown, setServerDown, agentMode, setAgentMode, tiers, updateTier, products, upsertProduct, removeProduct } = useAdmin();
  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("ops");
  const [pin, setPin] = useState("");

  if (!unlocked) {
    return (
      <section className="mx-auto grid min-h-[70vh] max-w-md place-items-center px-4">
        <div className="w-full rounded-3xl border border-border bg-slate-elevated p-8 shadow-elevated">
          <div className="grid h-14 w-14 place-items-center rounded-full gradient-mint shadow-mint">
            <Lock className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-bold">Admin Registry</h1>
          <p className="mt-1 text-sm text-muted-foreground">Enter the access PIN to unlock the dashboard.</p>
          <input value={pin} onChange={(e) => setPin(e.target.value)} placeholder="••••" type="password" className="input mt-5 text-center text-lg tracking-widest" />
          <button onClick={() => { if (pin.length >= 1) unlock(); }} className="press press-on mt-3 w-full rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint">
            Unlock
          </button>
          <Link to="/" className="press press-on mt-3 block text-center text-xs text-muted-foreground hover:text-mint">← Back to site</Link>
        </div>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-widest text-mint">Admin Registry</div>
          <h1 className="font-display text-3xl font-black sm:text-4xl">Dashboard</h1>
        </div>
        <button onClick={lock} className="press press-on rounded-xl border border-border bg-slate-elevated px-4 py-2 text-sm font-semibold hover:border-burnt hover:text-burnt">
          Lock
        </button>
      </div>

      <div className="mt-6 grid gap-2 sm:grid-cols-4">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`press press-on flex items-center gap-2 rounded-xl border px-4 py-3 text-sm font-semibold ${tab === id ? "border-mint bg-mint/10 text-mint" : "border-border bg-slate-elevated text-foreground/80 hover:border-mint"}`}
          >
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </div>

      <div className="mt-8">
        {tab === "ops" && (
          <div className="rounded-2xl border border-border bg-slate-elevated p-6">
            <h2 className="font-display text-xl font-bold">Smart-Ping Server Monitor</h2>
            <p className="mt-1 text-sm text-muted-foreground">Toggle bank server status. When DOWN, every form on the site is blocked and a blinking banner is shown.</p>
            <div className="mt-5 flex items-center gap-3">
              <button
                onClick={() => setServerDown(!serverDown)}
                className={`press press-on rounded-xl px-5 py-3 font-bold ${serverDown ? "gradient-burnt text-burnt-foreground shadow-burnt animate-blink-warn" : "gradient-mint text-primary-foreground shadow-mint"}`}
              >
                {serverDown ? "Servers DOWN — Click to Restore" : "Servers UP — Simulate Downtime"}
              </button>
              <div className="text-sm text-muted-foreground">Status: <span className={serverDown ? "text-burnt font-bold" : "text-mint font-bold"}>{serverDown ? "OFFLINE" : "LIVE"}</span></div>
            </div>
          </div>
        )}

        {tab === "tiers" && (
          <div className="grid gap-4 sm:grid-cols-2">
            {tiers.map((t) => (
              <div key={t.id} className="rounded-2xl border border-border bg-slate-elevated p-5">
                <div className="font-display text-lg font-bold">{t.name}</div>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <Field label="Min ₹"><input type="number" className="input" value={t.min} onChange={(e) => updateTier(t.id, { min: Number(e.target.value) })} /></Field>
                  <Field label="Max ₹"><input type="number" className="input" value={t.max} onChange={(e) => updateTier(t.id, { max: Number(e.target.value) })} /></Field>
                  <Field label="Charge"><input className="input" value={t.charge} onChange={(e) => updateTier(t.id, { charge: e.target.value })} /></Field>
                  <Field label="Loyalty">
                    <select className="input" value={String(t.loyalty)} onChange={(e) => updateTier(t.id, { loyalty: e.target.value === "true" })}>
                      <option value="true">Yes</option>
                      <option value="false">No</option>
                    </select>
                  </Field>
                </div>
                <Field label="Highlight">
                  <textarea className="input min-h-20" value={t.highlight} onChange={(e) => updateTier(t.id, { highlight: e.target.value })} />
                </Field>
              </div>
            ))}
          </div>
        )}

        {tab === "products" && (
          <ProductsAdmin products={products} upsert={upsertProduct} remove={removeProduct} />
        )}

        {tab === "agent" && (
          <div className="rounded-2xl border border-border bg-slate-elevated p-6">
            <h2 className="font-display text-xl font-bold">Bill Pay Agent Mode</h2>
            <p className="mt-1 text-sm text-muted-foreground">Choose how OTP verification is handled.</p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <button
                onClick={() => setAgentMode("lady-ai")}
                className={`press press-on rounded-2xl border p-5 text-left ${agentMode === "lady-ai" ? "border-mint bg-mint/10" : "border-border bg-slate-deep"}`}
              >
                <Bot className="h-6 w-6 text-mint" />
                <div className="mt-2 font-display font-bold">Lady AI Agent Mode</div>
                <div className="text-sm text-muted-foreground">Animated female voice avatar handles OTP and credits wallet instantly.</div>
              </button>
              <button
                onClick={() => setAgentMode("manual")}
                className={`press press-on rounded-2xl border p-5 text-left ${agentMode === "manual" ? "border-burnt bg-burnt/10" : "border-border bg-slate-deep"}`}
              >
                <Phone className="h-6 w-6 text-burnt" />
                <div className="mt-2 font-display font-bold">Manual Call Mode</div>
                <div className="text-sm text-muted-foreground">Human agent calls the customer to capture OTP.</div>
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">{label}</div>
      {children}
    </label>
  );
}

function ProductsAdmin({ products, upsert, remove }: { products: Product[]; upsert: (p: Product) => void; remove: (id: string) => void }) {
  const [draft, setDraft] = useState<Product>({ id: "", title: "", price: 0, category: "fintech", shortDesc: "", longDesc: "", cover: "", benefits: [] });

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
      <div className="rounded-2xl border border-border bg-slate-elevated p-5">
        <h2 className="font-display text-lg font-bold">Add / Edit Product</h2>
        <div className="mt-4 grid gap-3">
          <input className="input" placeholder="ID (slug)" value={draft.id} onChange={(e) => setDraft({ ...draft, id: e.target.value })} />
          <input className="input" placeholder="Title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <input className="input" type="number" placeholder="Price" value={draft.price || ""} onChange={(e) => setDraft({ ...draft, price: Number(e.target.value) })} />
            <select className="input" value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value as Product["category"] })}>
              <option value="fintech">Fintech</option>
              <option value="ai">AI Hub</option>
            </select>
          </div>
          <input className="input" placeholder="Cover image URL" value={draft.cover} onChange={(e) => setDraft({ ...draft, cover: e.target.value })} />
          <textarea className="input min-h-16" placeholder="Short description" value={draft.shortDesc} onChange={(e) => setDraft({ ...draft, shortDesc: e.target.value })} />
          <textarea className="input min-h-24" placeholder="Long description (15-page blueprint summary)" value={draft.longDesc} onChange={(e) => setDraft({ ...draft, longDesc: e.target.value })} />
          <textarea className="input min-h-16" placeholder="Benefits (comma separated)" value={draft.benefits.join(", ")} onChange={(e) => setDraft({ ...draft, benefits: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })} />
          <button
            onClick={() => { if (draft.id && draft.title) { upsert(draft); setDraft({ id: "", title: "", price: 0, category: "fintech", shortDesc: "", longDesc: "", cover: "", benefits: [] }); } }}
            className="press press-on inline-flex items-center justify-center gap-2 rounded-xl gradient-mint py-3 font-bold text-primary-foreground shadow-mint"
          >
            <Plus className="h-4 w-4" /> Save Product
          </button>
        </div>
      </div>

      <div>
        <h2 className="font-display text-lg font-bold">Inventory ({products.length})</h2>
        <div className="mt-4 grid gap-3">
          {products.map((p) => (
            <div key={p.id} className="press flex items-center gap-3 rounded-xl border border-border bg-slate-elevated p-3">
              <img src={p.cover} alt="" className="h-16 w-16 rounded-lg object-cover" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-bold">{p.title}</div>
                <div className="text-xs text-muted-foreground">₹{p.price.toLocaleString()} · {p.category}</div>
              </div>
              <button onClick={() => setDraft(p)} className="press press-on rounded-lg border border-border bg-slate-deep px-3 py-2 text-xs font-semibold hover:border-mint">Edit</button>
              <button onClick={() => remove(p.id)} className="press press-on grid h-9 w-9 place-items-center rounded-lg border border-border bg-slate-deep hover:border-burnt hover:text-burnt">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
