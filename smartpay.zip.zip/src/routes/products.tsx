import { createFileRoute } from "@tanstack/react-router";
import { LuxuryCatalog } from "@/components/LuxuryCatalog";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "FinTech Products — Digital Technical Modules — Smart Pay" },
      { name: "description", content: "21 digital technical FinTech products & modules only. Walkthrough videos, transparent pricing and clear summaries — no money transfer or payment processing." },
    ],
  }),
  component: () => (
    <LuxuryCatalog
      category="fintech"
      title="FinTech Products"
      subtitle="Digital Technical Products & Modules Only — 21 premium FinTech blueprints with HD walkthroughs, simplified intro pricing and a clean bulleted summary. No money transfers or payment processing."
      count={21}
    />
  ),
});
