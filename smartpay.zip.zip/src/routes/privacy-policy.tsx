import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Smart Pay" },
      {
        name: "description",
        content: "Official Smart Pay privacy policy, effective June 14, 2026.",
      },
      { property: "og:title", content: "Privacy Policy — Smart Pay" },
      {
        property: "og:description",
        content: "How Smart Pay collects, uses, and protects personal and transaction data.",
      },
    ],
  }),
  component: PrivacyPolicy,
});

function PrivacyPolicy() {
  return (
    <article className="mx-auto w-full max-w-3xl break-words px-4 py-12 font-sans sm:px-6 lg:py-16">
      <header className="border-b border-border pb-6">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-mint">
          Official Legal Policy
        </p>
        <h1 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
          📄 1. PRIVACY POLICY <span className="block text-xl font-semibold text-muted-foreground sm:text-2xl">(ప్రైవసీ పాలసీ)</span>
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">
          Effective Date: June 14, 2026 &nbsp;|&nbsp; Last Updated: June 14, 2026
        </p>
      </header>

      <div className="mt-8 space-y-8 text-[15px] leading-relaxed text-foreground/90">
        <section className="space-y-3">
          <p>
            Welcome to Smart Pay (incorporating Smart Fintech Products and Smart AI Money Hub). We
            are committed to protecting your personal data and ensuring 100% financial
            confidentiality.
          </p>
          <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            Smart Pay (Smart Fintech Products మరియు Smart AI Money Hub తో కూడినది) కు స్వాగతం. మీ
            వ్యక్తిగత డేటాను రక్షించడానికి మరియు 100% ఆర్థిక గోప్యతను నిర్వహించడానికి మేము కట్టుబడి
            ఉన్నాము. ఈ ప్రైవసీ పాలసీ మా ప్లాట్‌ఫారమ్‌ను మీరు ఉపయోగించినప్పుడు మీ సమాచారాన్ని మేము
            ఎలా సేకరిస్తాము, ఉపయోగిస్తాము మరియు భద్రపరుస్తాము అనే విషయాలను వివరిస్తుంది.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold sm:text-2xl">
            1. Information We Collect{" "}
            <span className="text-base font-medium text-muted-foreground">(మేము సేకరించే సమాచారం)</span>
          </h2>
          <p>
            <strong className="text-mint">Personal Identifiers:</strong> Name, Email Address, and
            Phone Number during account registration.
          </p>
          <p>
            <strong className="text-mint">Transaction Data:</strong> Encrypted parameters regarding
            transaction routing metrics. We do NOT store full card numbers or CVVs. All operations
            run via bank-grade encrypted tokens.
          </p>
          <div className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            <p>
              <strong>వ్యక్తిగత గుర్తింపులు:</strong> ఖాతా రిజిస్ట్రేషన్ సమయంలో పేరు, ఈమెయిల్ ఐడి
              మరియు ఫోన్ నంబర్.
            </p>
            <p className="mt-2">
              <strong>లావాదేవీల డేటా:</strong> ట్రాన్సాక్షన్ రూటింగ్ కొరకు ఎన్‌క్రిప్ట్ చేయబడిన డేటా
              మాత్రమే సేకరించబడుతుంది. మేము మీ పూర్తి కార్డ్ నంబర్లు లేదా CVV లను ఎప్పటికీ సేవ్ చేయము.
              ప్రతి ప్రక్రియ బ్యాంక్-గ్రేడ్ ఎన్‌క్రిప్షన్ టోకెన్స్ ద్వారానే జరుగుతుంది.
            </p>
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold sm:text-2xl">
            2. Data Protection &amp; Security{" "}
            <span className="text-base font-medium text-muted-foreground">(డేటా రక్షణ &amp; భద్రత)</span>
          </h2>
          <p>
            We utilize state-of-the-art PCI-DSS compliant bank-grade encryption frameworks. All
            server token exchanges are strictly structured under advanced confidentiality layers.
          </p>
          <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            మేము అత్యాధునిక PCI-DSS కంప్లైంట్ బ్యాంక్-గ్రేడ్ ఎన్‌క్రిప్షన్ ఫ్రేమ్‌వర్క్‌లను
            ఉపయోగిస్తాము. మీ డ్యాష్‌బోర్డ్ మరియు మా నెట్‌వర్క్ రూటింగ్ సర్వర్‌ల మధ్య జరిగే ప్రతి
            కమ్యూనికేషన్ పూర్తిగా లాక్ చేయబడి సురక్షితంగా ఉంచబడుతుంది.
          </p>
        </section>
      </div>
    </article>
  );
}
