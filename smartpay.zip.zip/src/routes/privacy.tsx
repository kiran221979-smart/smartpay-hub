import { createFileRoute } from "@tanstack/react-router";

const Page = ({ title, body }: { title: string; body: string }) => (
  <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
    <h1 className="font-display text-4xl font-black sm:text-5xl">{title}</h1>
    <p className="mt-5 whitespace-pre-line text-foreground/85">{body}</p>
  </section>
);

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Privacy Policy — Smart Pay" }] }),
  component: () => <Page title="Privacy Policy" body={"We collect minimal data required to process your transactions. Card details are encrypted at rest and in transit using PCI-DSS bank-grade standards. We never store CVV. We do not sell or share PII with third parties."} />,
});
