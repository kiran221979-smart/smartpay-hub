import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/refund-policy")({
  head: () => ({
    meta: [
      { title: "Refund & Cancellation Policy — Smart Pay" },
      {
        name: "description",
        content: "Official Smart Pay refund and cancellation policy, effective June 14, 2026.",
      },
      { property: "og:title", content: "Refund & Cancellation Policy — Smart Pay" },
      {
        property: "og:description",
        content: "Refund rules for Smart Pay digital products and transaction routing.",
      },
    ],
  }),
  component: RefundPolicy,
});

function RefundPolicy() {
  return (
    <article className="mx-auto w-full max-w-3xl break-words px-4 py-12 font-sans sm:px-6 lg:py-16">
      <header className="border-b border-border pb-6">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-mint">
          Official Legal Policy
        </p>
        <h1 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
          💳 2. REFUND &amp; CANCELLATION POLICY{" "}
          <span className="block text-xl font-semibold text-muted-foreground sm:text-2xl">
            (రిఫండ్ &amp; క్యాన్సిలేషన్ పాలసీ)
          </span>
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">Effective Date: June 14, 2026</p>
      </header>

      <div className="mt-8 space-y-8 text-[15px] leading-relaxed text-foreground/90">
        <section className="space-y-3">
          <p>
            Thank you for choosing Smart Pay and investing in our digital suites. Please review our
            mandatory operational refund guidelines thoroughly before finalizing any gateway purchase
            execution.
          </p>
          <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            Smart Pay ని ఎంచుకున్నందుకు మరియు మా డిజిటల్ ప్రొడక్ట్స్ పై ఇన్వెస్ట్ చేసినందుకు
            ధన్యవాదాలు. ఏదైనా పేమెంట్ చేసే ముందు దయచేసి మా రిఫండ్ మరియు క్యాన్సిలేషన్ నిబంధనలను
            జాగ్రత్తగా చదవండి.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold sm:text-2xl">
            1. Digital Products MarketPlace{" "}
            <span className="text-base font-medium text-muted-foreground">
              (డిజిటల్ ప్రొడక్ట్స్ మార్కెట్‌ప్లేస్)
            </span>
          </h2>
          <p>
            <strong className="text-mint">Zero-Refund Policy:</strong> Since all products inside the
            Smart AI Money Hub (Cinematic Magazines, Prompt Libraries, Masterclass Blueprints) are
            instantly downloadable high-IQ digital assets, they are deemed permanently consumed upon
            purchase delivery. Consequently, we maintain a strict NO REFUNDS, NO RETURNS, and NO
            EXCHANGES execution policy.
          </p>
          <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            <strong>జీరో-రిఫండ్ పాలసీ:</strong> Smart AI Money Hub లోపల ఉండే ప్రొడక్ట్స్ (సినిమాటిక్
            డిజిటల్ మ్యాగజైన్‌లు, ప్రాంప్ట్ లైబ్రరీలు, మాస్టర్‌క్లాస్ బ్లూప్రింట్లు) అన్నీ
            ఇన్‌స్టంట్‌గా డౌన్‌లోడ్ చేసుకునే డిజిటల్ అసెట్స్ కావడం వల్ల, పేమెంట్ విజయవంతం కాగానే అవి
            కస్టమర్‌కు అందినట్లుగా పరిగణించబడుతుంది. అందువల్ల, ఒకసారి కొనుగోలు చేసిన తర్వాత ఎట్టి
            పరిస్థితుల్లోనూ ఎలాంటి రిఫండ్లు, రిటర్న్లు లేదా ఎక్స్ఛేంజ్‌లు ఇవ్వబడవు.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold sm:text-2xl">
            2. Failed Gateway Routing Recoveries{" "}
            <span className="text-base font-medium text-muted-foreground">
              (విఫలమైన లావాదేవీల రికవరీ)
            </span>
          </h2>
          <p>
            In instances where an automated micro-settlement path experiences upstream banking
            network drops, the funds are securely intercepted by our autonomous recovery loop and
            auto-reversed to the source credit card within 2 to 5 standard banking business days.
          </p>
          <p className="rounded-md border-l-2 border-mint/60 bg-slate-deep/40 p-3 text-muted-foreground">
            బ్యాంకింగ్ సర్వర్ల డౌన్‌టైమ్ కారణంగా ఏదైనా ఆటోమేటెడ్ మైక్రో-సెటిల్‌మెంట్ విఫలమైతే, ఆ
            అమౌంట్ మా అటానమస్ రికవరీ లూప్ ద్వారా సురక్షితంగా నిలిపివేయబడి, 2 నుండి 5 బ్యాంకింగ్ పని
            దినాలలో కస్టమర్ యొక్క అసలు క్రెడిట్ కార్డ్ ఖాతాకే ఆటోమేటిక్‌గా రీవర్స్ (రిఫండ్)
            చేయబడుతుంది.
          </p>
        </section>
      </div>
    </article>
  );
}
