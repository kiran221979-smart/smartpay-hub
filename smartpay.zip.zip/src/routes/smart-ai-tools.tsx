import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, Cpu } from "lucide-react";

export const Route = createFileRoute("/smart-ai-tools")({
  head: () => ({
    meta: [
      { title: "Smart AI Tools — Productivity Module Index — Smart Pay" },
      { name: "description", content: "Indexing grid for advanced productivity AI application modules. Premium Deep Teal Neon catalog scaffold." },
      { property: "og:title", content: "Smart AI Tools — Smart Pay" },
      { property: "og:description", content: "Advanced productivity AI application module index." },
    ],
  }),
  component: SmartAiToolsPage,
});

const SLOTS = Array.from({ length: 12 }).map((_, i) => i + 1);

function SmartAiToolsPage() {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-10">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
          <Sparkles className="h-3 w-3" /> Productivity Matrix · Indexing
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">Smart AI Tools</h1>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">
          Empty structural grid for advanced productivity AI application modules. Cards activate as new tools are indexed into the Smart Pay matrix.
        </p>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {SLOTS.map((n) => (
          <article
            key={n}
            className="group relative flex aspect-[5/4] flex-col items-center justify-center overflow-hidden rounded-3xl border border-dashed border-mint/30 bg-slate-deep/40 p-6 text-center shadow-elevated transition hover:border-mint hover:shadow-mint"
          >
            <div className="grid h-14 w-14 place-items-center rounded-2xl border border-mint/30 bg-slate-deep/70 text-mint">
              <Cpu className="h-6 w-6" />
            </div>
            <div className="mt-4 text-[10px] font-bold uppercase tracking-[0.3em] text-mint">Module Slot · {String(n).padStart(2, "0")}</div>
            <h3 className="mt-1 font-display text-base font-black">Awaiting AI Tool Indexing</h3>
            <p className="mt-1 text-xs text-foreground/70">Reserved cell for the next productivity AI module deployment.</p>
          </article>
        ))}
      </div>
    </section>
  );
}
