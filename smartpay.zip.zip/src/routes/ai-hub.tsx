import { createFileRoute } from "@tanstack/react-router";
import { LuxuryCatalog } from "@/components/LuxuryCatalog";

export const Route = createFileRoute("/ai-hub")({
  head: () => ({
    meta: [
      { title: "AI Money Hub Blueprint Catalog — Smart Pay" },
      { name: "description", content: "19 luxury AI Money blueprints with HD walkthroughs, transparent pricing, discounts and intro offers." },
    ],
  }),
  component: () => (
    <LuxuryCatalog
      category="ai"
      title="Smart AI Money Hub Catalog"
      subtitle="18 elite AI money modules — each with an HD walkthrough, simplified intro pricing and a clean bulleted summary."
      count={18}
    />
  ),
});
