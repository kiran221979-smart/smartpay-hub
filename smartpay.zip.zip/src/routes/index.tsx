import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  Sparkles,
  Zap,
  ShieldCheck,
  TrendingUp,
  Activity,
  Radio,
  Landmark,
  CircleDollarSign,
  Globe2,
  Clock,
} from "lucide-react";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { MasterClock } from "@/components/MasterClock";


import { VideoDemoHub } from "@/components/VideoDemoHub";

import { GeoTicker } from "@/components/GeoTicker";
import { SettlementConsole } from "@/components/SettlementConsole";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Pay — Agentic AI Credit-to-Bank in 45 Seconds" },
      {
        name: "description",
        content:
          "India's first Agentic-AI payout system: 24/7 instant credit-to-bank settlement, bill autopay, AI CIBIL boosters, PCI-DSS encrypted.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const launch = () => navigate({ to: "/automation" });

  return (
    <>
      <section className="relative overflow-hidden gradient-hero">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,var(--color-mint)/0.08,transparent_45%),radial-gradient(circle_at_50%_70%,var(--color-burnt)/0.08,transparent_45%)]" />
        <div className="relative mx-auto w-full max-w-6xl px-4 pt-10 sm:px-6 lg:px-10 lg:pt-14">
          <SettlementConsole onLaunch={launch} />
        </div>
        <div className="relative mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-6 lg:px-10 lg:pb-24 lg:pt-10">
          <div className="mx-auto max-w-3xl text-center animate-fade-up">
            <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-mint">
              <Zap className="h-3 w-3" /> Agentic AI · 45s Settlement
            </div>
            <h1 className="mt-5 font-display text-4xl font-black leading-[1.05] sm:text-6xl">
              <span className="shimmer-text">Smart Pay</span> intelligence,
              <br />
              bank-speed settlement.
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base text-foreground/85 sm:text-lg">
              India's first fully autonomous Agentic AI Payout System. Zero third-party
              intervention. 100% bank loyalty retention. Ultimate data privacy.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <button
                onClick={launch}
                className="press press-on inline-flex items-center gap-2 rounded-xl gradient-mint px-6 py-3.5 font-display text-base font-bold text-primary-foreground shadow-mint"
              >
                Launch Smart Portal <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="/support"
                className="press press-on inline-flex items-center gap-2 rounded-xl border border-border bg-slate-elevated px-6 py-3.5 font-display text-base font-bold hover:border-mint"
              >
                Talk to an Agent <Sparkles className="h-4 w-4 text-mint" />
              </a>
          </div>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5 text-mint" /> PCI-DSS Encrypted</span>
              <span className="flex items-center gap-1.5"><Activity className="h-3.5 w-3.5 text-mint" /> Sub-45s Settlement</span>
              <span className="flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5 text-mint" /> Lady AI OTP Agent</span>
            </div>
          </div>

          {/* Centered, symmetric 3-column dashboard grid */}
          <div className="mx-auto mt-12 max-w-6xl rounded-3xl border border-border bg-slate-deep shadow-elevated">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-4 sm:px-7">
              <div className="text-center sm:text-left">
                <div className="text-[10px] uppercase tracking-[0.25em] text-mint">
                  Smart Pay / Command Center
                </div>
                <div className="mt-1 font-display text-lg font-bold">Settlement Intelligence</div>
              </div>
              <div className="flex items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-mint">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" /> Live · Online
              </div>
            </div>

            <ThreeColumnDashboard />
          </div>
        </div>
      </section>

      <GeoTicker />

      <MasterClock />

      <VideoDemoHub />
      <WhyChooseUs />
    </>
  );
}



const BANK_REGISTRY = [
  "HDFC", "ICICI", "SBI", "AXIS", "KOTAK", "INDUSIND",
  "YES BANK", "RBL", "IDFC FIRST", "BOB", "PNB", "CANARA", "UNION", "BOI",
];

function nextSettlement(prevBank: string, prevAmount: number) {
  let bank = prevBank;
  while (bank === prevBank) {
    bank = BANK_REGISTRY[Math.floor(Math.random() * BANK_REGISTRY.length)];
  }
  let amount = prevAmount;
  // strictly above ₹50,000 and below ₹1,00,000
  while (amount === prevAmount) {
    amount = 50000 + Math.floor(Math.random() * 49999) + 1;
  }
  return { bank, amount };
}

function ThreeColumnDashboard() {
  const [volume, setVolume] = useState(42876520);
  const [routeIndex, setRouteIndex] = useState(3);
  const [success, setSuccess] = useState(99.2);
  const [relays, setRelays] = useState(16);
  const [banks, setBanks] = useState(34);
  const [settlement, setSettlement] = useState<{ bank: string; amount: number }>({
    bank: "HDFC",
    amount: 78420,
  });
  const routing = [24, 29, 34, 27];

  useEffect(() => {
    const t1 = window.setInterval(
      () => setVolume((v) => v + Math.floor(1240 + Math.random() * 8760)),
      1000,
    );
    const t2 = window.setInterval(
      () => setRouteIndex((v) => (v + 1) % routing.length),
      2600,
    );
    const t3 = window.setInterval(
      () => setSuccess(Number((98 + Math.random() * 1.9).toFixed(1))),
      1800,
    );
    const t4 = window.setInterval(() => {
      setRelays((prev) => {
        let n = prev;
        while (n === prev) n = 14 + Math.floor(Math.random() * 9);
        return n;
      });
    }, 4000);
    const t5 = window.setInterval(() => {
      setBanks((prev) => {
        let n = prev;
        while (n === prev) n = 32 + Math.floor(Math.random() * 14);
        return n;
      });
    }, 6000);
    const t6 = window.setInterval(() => {
      setSettlement((cur) => nextSettlement(cur.bank, cur.amount));
    }, 1400);
    return () => [t1, t2, t3, t4, t5, t6].forEach(window.clearInterval);
  }, []);

  const columns = [
    {
      icon: CircleDollarSign,
      label: "Volumes",
      tag: "Live national inflow",
      primary: { k: "Today Payout", v: `₹${volume.toLocaleString("en-IN")}`, key: volume },
      stats: [
        { k: "Success Rate", v: `${success.toFixed(1)}%`, note: "+0.3%" },
        { k: "Cumulative", v: "₹4.12 Cr", note: "All-time" },
      ],
    },
    {
      icon: Clock,
      label: "Time / Relays",
      tag: "AI pathfinding",
      primary: { k: "Avg Routing", v: `${routing[routeIndex]}s`, key: routing[routeIndex] },
      stats: [
        { k: "AI Relays", v: `${relays}`, note: "Active" },
        { k: "P95 Latency", v: "41s", note: "Sub-45" },
      ],
    },
    {
      icon: Globe2,
      label: "Channels",
      tag: "Nationalized banking",
      primary: { k: "Banks Live", v: `${banks}`, key: banks },
      stats: [
        { k: "Total Channels", v: "194+", note: "PCI-DSS" },
        { k: "Last Settled", v: settlement.bank, note: `₹${settlement.amount.toLocaleString("en-IN")}` },
      ],
    },
  ];

  return (
    <div className="p-5 sm:p-7" aria-live="polite">
      <div className="grid grid-cols-1 divide-y divide-mint/15 lg:grid-cols-3 lg:divide-x lg:divide-y-0">
        {columns.map(({ icon: Icon, label, tag, primary, stats }, i) => (
          <div
            key={label}
            className={`flex flex-col items-center px-2 py-6 text-center ${
              i === 0 ? "lg:pl-2 lg:pr-6" : i === 2 ? "lg:pl-6 lg:pr-2" : "lg:px-6"
            }`}
            style={{
              boxShadow:
                i !== 2
                  ? "inset -1px 0 0 color-mix(in oklab, var(--color-mint) 25%, transparent)"
                  : undefined,
            }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-mint/40 bg-mint/10 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest text-mint">
              <Icon className="h-3 w-3" /> {label}
            </div>
            <div className="mt-3 text-[10px] uppercase tracking-widest text-muted-foreground">
              {primary.k}
            </div>
            <div
              key={String(primary.key)}
              className="mt-1 font-display text-3xl font-black tabular-nums text-mint animate-fade-in sm:text-4xl"
            >
              {primary.v}
            </div>
            <div className="mt-1 flex items-center justify-center gap-1 text-[10px] text-mint">
              <TrendingUp className="h-3 w-3" /> {tag}
            </div>
            <div className="mt-5 grid w-full max-w-xs grid-cols-2 gap-2">
              {stats.map((s) => (
                <div
                  key={s.k}
                  className="rounded-xl border border-border bg-slate-elevated px-3 py-2 text-center"
                >
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">
                    {s.k}
                  </div>
                  <div className="mt-1 font-display text-sm font-black tabular-nums">{s.v}</div>
                  <div className="text-[9px] text-mint">{s.note}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Centered live rolling settlement strip */}
      <div className="mt-6 flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-mint/25 bg-slate-elevated px-4 py-3 text-center">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <Radio className="h-3 w-3 text-mint" /> Rolling Last Settlement
        </span>
        <span
          key={`${settlement.bank}-${settlement.amount}`}
          className="font-display text-sm font-black tabular-nums text-mint animate-fade-in sm:text-base"
        >
          <Landmark className="-mt-0.5 mr-1 inline h-3.5 w-3.5" />
          {settlement.bank} — ₹{settlement.amount.toLocaleString("en-IN")}
        </span>
      </div>
    </div>
  );
}
