import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type ServiceTier = {
  id: string;
  name: string;
  min: number;
  max: number;
  charge: string;
  loyalty: boolean;
  highlight: string;
  comingSoon?: boolean;
  cardLabel?: string;
};

export type Product = {
  id: string;
  title: string;
  price: number;
  category: "fintech" | "ai";
  shortDesc: string;
  longDesc: string;
  cover: string;
  benefits: string[];
};

type AdminState = {
  unlocked: boolean;
  serverDown: boolean;
  agentMode: "lady-ai" | "manual";
  tiers: ServiceTier[];
  products: Product[];
};

type Ctx = AdminState & {
  unlock: () => void;
  lock: () => void;
  setServerDown: (v: boolean) => void;
  setAgentMode: (m: "lady-ai" | "manual") => void;
  updateTier: (id: string, patch: Partial<ServiceTier>) => void;
  upsertProduct: (p: Product) => void;
  removeProduct: (id: string) => void;
};

const defaultTiers: ServiceTier[] = [
  { id: "neural", name: "Smart Neural", min: 1000, max: 25000, charge: "2.5%", loyalty: false, cardLabel: "Domestic Card", highlight: "NO BANK SIDE LOYALTY AND REWARDS. Core credit card to bank routing only." },
  { id: "matrix", name: "Smart Matrix", min: 5000, max: 75000, charge: "2.2%", loyalty: true, cardLabel: "Domestic Card", highlight: "Credit card TO bank Faster routing, priority queue. 100% BANK LOYALTY AND REWARDS." },
  { id: "quantum", name: "Smart Quantum", min: 25000, max: 500000, charge: "1.5%", loyalty: true, cardLabel: "Corporate Card", highlight: "Specially for corporate cards. ✅ 100% BANK LOYALTY AND REWARDS APPLIED." },
  { id: "tensor", name: "Smart Tensor", min: 10000, max: 200000, charge: "1.9%", loyalty: true, cardLabel: "Business Card", highlight: "Specially for business cards. Loyalty partially applied + dedicated relay." },
  { id: "vector", name: "Smart Vector", min: 50000, max: 1000000, charge: "1.3%", loyalty: true, cardLabel: "Diners Card", highlight: "High-velocity node routing optimized for Diners Club premium networks. Synchronized clearing channels for high-value corporate limits with sub-second processing speed.", comingSoon: true },
  { id: "vortex", name: "Smart Vortex", min: 100000, max: 2500000, charge: "1.1%", loyalty: true, cardLabel: "Amex Card", highlight: "Elite multi-stream architecture tailored for American Express Platinum & Centurion credentials. Automated smart-agent liquidity paths for instant institutional-grade settlement.", comingSoon: true },
];


const defaultProducts: Product[] = [
  { id: "p1", title: "Wallet OS", price: 1499, category: "fintech", shortDesc: "An intelligent treasury layer for modern operators.", longDesc: "A human-led, AI-accelerated wallet operating system that unifies cash visibility, policy controls, and intelligent routing in one decision layer.", cover: "", benefits: ["Unified liquidity view", "Policy-aware automation", "Human approval controls", "Real-time ledger intelligence"] },
  { id: "p2", title: "Ledger Core", price: 2999, category: "fintech", shortDesc: "Enterprise-grade financial truth in real time.", longDesc: "A resilient double-entry ledger architecture engineered for high-volume fintech teams that require explainability, audit depth, and confident reconciliation.", cover: "", benefits: ["Immutable audit trail", "Real-time reconciliation", "Multi-entity accounting", "Explainable AI controls"] },
  { id: "p3", title: "Payout Rails", price: 999, category: "fintech", shortDesc: "Adaptive, secure routing across Indian banking rails.", longDesc: "A professional payout orchestration blueprint with intelligent fallback paths, bank-aware routing, and continuously monitored settlement performance.", cover: "", benefits: ["Adaptive bank routing", "Continuous rail monitoring", "Fallback orchestration", "Settlement analytics"] },
  { id: "p4", title: "Agentic Money Bot", price: 4999, category: "ai", shortDesc: "24/7 autonomous agent for withdrawals.", longDesc: "An Agentic AI that performs end-to-end withdrawals from card to bank without human intervention. Built on the latest agent runtimes with full guardrails.", cover: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800", benefits: ["Hands-free withdrawals", "Agentic decisioning", "Multi-bank support", "24/7 uptime"] },
  { id: "p5", title: "AI Wealth Compass", price: 1999, category: "ai", shortDesc: "Personalized AI money plan engine.", longDesc: "Generates a 15-step wealth blueprint tailored to your income, spend, and credit. Updated monthly with macro overlays.", cover: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800", benefits: ["Custom 15-step plan", "Monthly macro update", "Goal tracker", "Tax-aware routing"] },
  { id: "p6", title: "Lady AI Voice Agent", price: 2499, category: "ai", shortDesc: "Female-voice OTP & verification avatar.", longDesc: "An interactive female-voice avatar that handles OTP verification, customer reassurance, and credit confirmation, ending in a clean success invoice popup.", cover: "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=800", benefits: ["Animated avatar UI", "OTP capture flow", "Success invoice", "Multi-language"] },
];

const STORAGE_KEY = "smartpay-admin-state-v5";

const AdminContext = createContext<Ctx | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AdminState>(() => {
    if (typeof window === "undefined") {
      return { unlocked: false, serverDown: false, agentMode: "lady-ai", tiers: defaultTiers, products: defaultProducts };
    }
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<AdminState>;
        return {
          unlocked: false,
          serverDown: parsed.serverDown ?? false,
          agentMode: parsed.agentMode ?? "lady-ai",
          tiers: parsed.tiers ?? defaultTiers,
          products: parsed.products ?? defaultProducts,
        };
      }
    } catch {}
    return { unlocked: false, serverDown: false, agentMode: "lady-ai", tiers: defaultTiers, products: defaultProducts };
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    const { unlocked: _u, ...persist } = state;
    void _u;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(persist));
  }, [state]);

  const ctx: Ctx = {
    ...state,
    unlock: () => setState((s) => ({ ...s, unlocked: true })),
    lock: () => setState((s) => ({ ...s, unlocked: false })),
    setServerDown: (v) => setState((s) => ({ ...s, serverDown: v })),
    setAgentMode: (m) => setState((s) => ({ ...s, agentMode: m })),
    updateTier: (id, patch) => setState((s) => ({ ...s, tiers: s.tiers.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
    upsertProduct: (p) => setState((s) => {
      const exists = s.products.some((x) => x.id === p.id);
      return { ...s, products: exists ? s.products.map((x) => (x.id === p.id ? p : x)) : [p, ...s.products] };
    }),
    removeProduct: (id) => setState((s) => ({ ...s, products: s.products.filter((p) => p.id !== id) })),
  };

  return <AdminContext.Provider value={ctx}>{children}</AdminContext.Provider>;
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin must be used within AdminProvider");
  return ctx;
}
